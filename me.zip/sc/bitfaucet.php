<?php
//print " 404  Scrypt Maintenis".n;die; 
error_reporting(0);
define('host',['bitfaucet','bitfaucet.net','']);
define('version','1.0.2');
define('cok','cookie.'.host[0]);
define('uag','user_agent');
define('web','https://'.host[1]);
Del_Cok();
Function h(){
    $h[] = "Host: ".host[1];
    if($data)$h[] = "Content-Length: ".strlen($data);
    $h[] = "cookie: ".file_get_contents(Data.cok);
    $h[] = "user-agent: ".file_get_contents(Data.uag);
    return $h;
}
Function balance(){
    $r = get(web."/dashboard");
    $b = trim(explode('<',explode('<h3 class="card-title" style="margin-bottom: 0; color: var(--text-primary);">', $r)[1])[0]);
    $e = explode('</h3>', explode('<h3 style="color: var(--text-primary);font-weight: bold">',explode('Available Balance</p>', $r)[1])[1])[0];
    return ["b"=>$b,"e"=>$e];
}
Awal:
SaveCokUa();
ban();
$r = get(web."/dashboard");
$lg = Ambil($r,'<span>','</span>',2);
if(!$lg){print Error("Cookie Experied").n;Del();die;}
else{echo " ".p." Login success."; echo r;sleep(2);}
$r = balance();
echo rr;
echo line_at();
echo line_tg().msg(2,"Balance").panah.p.$r["b"].n;
echo line_tg().msg(3,"Energy ").panah.p.$r["e"].n;
echo line_bw();

Faucet:
$a = 0;
while(true){
    echo rr;
    $r = get(web."/faucet");
    if(preg_match("/Daily limit reached/",$r)){
        echo Error("Daily limit reached").n;die;
    }
    $c_t = Ambil($r,'name="csrf_token_name" id="token" value="','">',1);
    $tok = Ambil($r,'name="token" value="','">',1);
    if($atb = atb_3($r)){
        $data ="$atb&csrf_token_name=$c_t&token=$tok";}
        goto exekusi;
    if(!$atb){
        $data ="csrf_token_name=$c_t&token=$tok";
    }
    exekusi:
    $post = post(web."/faucet/verify",$data);
    if(preg_match("/Just a moment/",$post)){
        echo msg(4,"Cloudflare!").n;sleep(1);del();del_cok();die;
    }elseif(preg_match("/Invalid Anti-Bot Links/",$post)){
        echo Error("Invalid Antibot! ").p."[".k.$a = $a + 1 .p."]";sleep(2);echo r;goto en;
    }elseif(preg_match("/title: 'Good job!'/",$post)){
        $r = balance(); 
        $hasil = Ambil($post,"text: '"," coins has been added to your balance",1);
        echo line_at();
        echo line_tg().msg(1,"Username").panah.p.$r["b"].n;
        echo line_tg().msg(2,"Balance ").panah.p.$r["e"].n;
        echo line_tg().msg(3,"Reward ").panah.p.$hasil.n;
        echo line_bw();
        tim(13);
        $a = 0;
        goto en;
    }
    en:
}