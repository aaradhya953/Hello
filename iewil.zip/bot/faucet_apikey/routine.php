<?php

const
versi = "0.0.1",
host = "https://routinefaucet.net/",
refflink = "https://routinefaucet.net/?r=zvGZlK9TWL",
youtube = "https://youtube.com/@iewil";

class Bot {
	function __construct(){
		Display::Ban(title, versi);
		
		cookie:
		Display::Cetak("Register",refflink);
		Display::Line();
			
		$this->cookie = Functions::setConfig("cookie");
		$this->uagent = Functions::setConfig("user_agent");
		Functions::view();
		
		$this->scrap = new HtmlScrap();
		
		Display::Ban(title, versi);
		$r = $this->dashboard();
		if(!$r["username"]){
			print Display::Error("Cookie expired\n");
			Functions::removeConfig("cookie");
			Display::Line();
			goto cookie;
		}
		Display::Cetak("Username",$r["username"]);
		Display::Line();
	}
	private function headers($data=0){
		$h[] = "Host: ".parse_url(host)['host'];
		$h[] = "x-requested-with: XMLHttpRequest";
		if($data)$h[] = "Content-Length: ".strlen($data);
		$h[] = "User-Agent: ".$this->uagent;
		$h[] = "Cookie: ".$this->cookie;
		return $h;
	}
	private function dashboard(){
		$r = Requests::get(host."/",$this->headers())[1];
		$data["username"] = explode('</a>',explode('<a href="page/dashboard" class="text-success">',$r)[1])[0];
		return $data;
	}
	private function claim(){
		while(true){
			$r = Requests::get(host."roll.html", $this->headers())[1];
			if(preg_match('/You have to wait/', $r)){
				$minutes = explode(',',explode('claim_countdown("claim_again", ', $r)[1])[0];//4, 54);
				$seconds = explode(')', explode(',',explode('claim_countdown("claim_again", ', $r)[1])[1])[0];
				Functions::Tmr($minutes*60 + $seconds);
				continue;
			}
			
			$token = Ambil($r,"var token = '","';",1);
    $data  = "a=getFaucet&token=$token&challenge=false&response=false";
    $postCsrf = json_decode(Requests::post("https://routinefaucet.net/requestHandler/ajax/verify", $this->headers(), $data)[1],1);
			if($postCsrf["status"] == "success"){
				print Display::Sukses(strip_tags($postCsrf["message"]));
				print Display::Line();
			}elseif(preg_match('/Please try again/', $postCsrf["message"])){
				continue;
			}elseif(preg_match('/security step!/', $postCsrf["message"])){
				continue;
			}else{
				print_r($postCsrf);
				exit;
			}
		}
	}
}

new Bot();