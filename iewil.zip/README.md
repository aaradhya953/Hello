# Script_Library
### Here I will create more than hundreds of scripts
I may not be able to check the scripts one by one, so if you experience an error, you can enter my group on Telegram and tell me about the problem that occurred and don't forget to screenshot the error to make it easier to check.

[![Youtube](https://img.shields.io/youtube/channel/subscribers/UCvBSqRaT6nsPvtl8m6GaQpg?style=social)](https://youtube.com/c/iewil)
[![Github](https://img.shields.io/github/followers/iewilmaestro?style=social)](https://github.com/iewilmaestro)
[![Telegram](https://img.shields.io/badge/fat9ght-green?style=social&logo=Telegram)](https://t.me/fat9ght)
[![Instagram](https://img.shields.io/badge/Iewil_13-green?style=social&logo=Instagram)](https://www.instagram.com/iewil_13/)
[![Facebook](https://img.shields.io/badge/Iewilmaestro-blue?style=social&logo=Facebook)](https://www.facebook.com/iewil.maestro)
[![Twitter](https://img.shields.io/badge/iewil1-green?style=social&logo=X)](https://x.com/iewil1)
[![Greasyfork](https://img.shields.io/badge/iewilofficial-green?style=social&logo=GreasyFork)](https://greasyfork.org/en/users/1391260-iewil-official)

[![paypal](https://ionicabizau.github.io/badges/paypal.svg)](https://www.paypal.com/paypalme/iewil)
[![Dana](https://img.shields.io/badge/Dana-Idr-blue.svg?logo=data:image/svg%2bxml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIFVwbG9hZGVkIHRvOiBTVkcgUmVwbywgd3d3LnN2Z3JlcG8uY29tLCBHZW5lcmF0b3I6IFNWRyBSZXBvIE1peGVyIFRvb2xzIC0tPg0KPHN2ZyB3aWR0aD0iODAwcHgiIGhlaWdodD0iODAwcHgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgaWQ9ImEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHN0eWxlPi5ie2ZpbGw6bm9uZTtzdHJva2U6IzAwMDAwMDtzdHJva2UtbGluZWNhcDpyb3VuZDtzdHJva2UtbGluZWpvaW46cm91bmQ7fTwvc3R5bGU+PC9kZWZzPjxwYXRoIGNsYXNzPSJiIiBkPSJtMzUuNSwxNy44MTIxYy03LjY2NjctNS40NDUzLTE1LjMzMzQsNS40NDUzLTIzLDB2MTIuMzc1N2M3LjY2NjYsNS40NDUzLDE1LjMzMzMtNS40NDUzLDIzLDB2LTEyLjM3NTdaIi8+PGNpcmNsZSBjbGFzcz0iYiIgY3g9IjI0IiBjeT0iMjQiIHI9IjIxLjUiLz48L3N2Zz4=)](https://link.dana.id/qr/39zejqet)
# Installation
```
pkg update -y && pkg update -y
```
```
pkg install php -y
```
```
pkg install git -y
```
```
git clone https://github.com/iewilmaestro/Script_Library
```
# Run script
```
cd Script_Library
```
```
php run.php
```
# About Script_Library
- automatically perform tasks that are possible
- Special free captcha bypass Antibotlinks, Gp recaptcha, hash icon, icon coordinates, Alt captcha
- apikey is used to bypass Recaptcha, Hcaptcha, Turnstile
- bypass firewall using apikey

# Apikey
- xevil
- multibot


