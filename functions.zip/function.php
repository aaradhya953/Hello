
<?php
define("RED", "\033[1;31;40m");
define("GREEN", "\033[1;32;40m");
define("YELLOW", "\033[1;33;40m");
define("BLUE", "\033[1;34;40m");
define("PURPLE", "\033[1;35;40m");
define("CYAN", "\033[1;36;40m");
define("GREY", "\033[1;30;40m");
define("MONO", "\033[2;37;40m");
define("EMONO", "\033[0;37;40m");
define("ITALIC", "\033[3;37;40m");
define("NEWLINE", "\n");
define("WHITE", "\033[1;37m");
define("UNDERLINE_CYAN", "\033[4;36m");  
define("BLINKING_GREEN", "\033[5;32m");  
define("GLOWING_PURPLE", "\033[1;35;5m"); 
define("GLOWING_WHITE", "\033[1;37;5m"); 
define("BOLD_YELLOW", "\033[1;33m");
define("RESET", WHITE);
define("BG_RED", "\033[41m");  // Red background
define("BG_GREEN", "\033[42m");  // Green background
define("BG_BLUE", "\033[44m");  // Blue background
define("BG_END", "\033[0m");   // Reset background color


function saveData($filename) {
    if (file_exists($filename)) {
        $data = file_get_contents($filename);
    } else {
        $data = readline(WHITE . "Input " . $filename . RED . " : " . WHITE);
        file_put_contents($filename, $data);
    }
    return $data;
}

function banner($sc){
    global $l;
    print GREEN; fast($l);
echo YELLOW . "                    〔 ". GREEN . $sc . YELLOW . " 〕           \n";
print GREEN; fast($l);

}


//system('clear');
$l = str_repeat("━", 60) . GLOWING_WHITE . NEWLINE;

function fast($arr){
    $char = str_split($arr);
    foreach($char as $animated){
        echo $animated;
        usleep(5000);
    }
}




function first_part($message, $width, $wait) {
    // Pad the message to center it
    $animated_message = str_pad($message, $width, ' ', STR_PAD_BOTH);
    $msg_effect = "";
    
    // Create the animated effect
    for ($i = 0; $i < strlen($animated_message) - 1; $i++) {
        $msg_effect .= $animated_message[$i];
        // Output the current state of the animation
        echo "\r" . $msg_effect;
        flush(); // Force output to be displayed immediately
        usleep(30000); // 0.03 seconds
    }

    if ($wait) {
        sleep(1); // Wait for 1 second if the message is short
    }
}

function animation($message) {
    // Define the number of characters to display at once
    $width = 50;
    // Determine if the message fits within the width
    $msg_effect = substr($message, 0, $width);
    $wait = strlen($message) <= $width;

    // Print the first part of the message
    first_part($msg_effect, $width, $wait);

    // If the message is longer, scroll it horizontally
    if (strlen($message) > $width) {
        for ($i = $width; $i < strlen($message); $i++) {
            // Shift the message by removing the first character and adding the next
            $msg_effect = substr($msg_effect, 1) . $message[$i];
            echo "\r" . $msg_effect;
            flush(); // Ensure the updated message is printed immediately
            usleep(100000); // 0.1 seconds delay between scrolls
        }
    }
    sleep(1);
    echo "\r" . str_repeat(' ', $width) . "\r";
    flush();
 

}







function action($action) {
    // Define date and time in the required format
    $now = date("d/M/Y H:i:s");

    // Calculate the total length for spacing
    $total_length = strlen($action) + strlen($now) + 5;
    $space_count = 50 - $total_length;

    // Format the message
    $msg = strtoupper($action) . " " . $now . str_repeat(" ", max(0, $space_count));

    // Define color codes (these may vary based on the environment)
    $bg_red = "\033[41m";
    $white = "\033[97m";
    $res = "\033[0m";
    $red = "\033[31m";
    $end = "\033[0m";

    // Print the message with colors
    echo "{$bg_red} {$white}{$msg}  {$res}{$red}⫸{$res}{$end}\n";
}
function Run($url, $head = 0, $post = 0, $data = "data") {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_COOKIEJAR , "cookie.txt");
    curl_setopt($ch,CURLOPT_COOKIEFILE , "cookie.txt");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);

    if ($post) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }

    if ($head && is_array($head)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    }

    curl_setopt($ch, CURLOPT_HEADER, true);
    $r = curl_exec($ch);
    $info = curl_getinfo($ch);
    if($data == "info"){
        $info = curl_getinfo($ch);
        return $info;
    }
    if(!$r){
        return "Curl error: " . curl_error($ch);
    } else {
        $header = substr($r, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        $body = substr($r, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        curl_close($ch);
        return $body;
    }
}

function clear() {
    // Check if the PHP script is running on a Windows system
    if (stripos(PHP_OS, 'WIN') === 0) {
        // Clear the screen on Windows CMD
        pclose(popen('cls', 'w'));
    } else {
        // Use 'clear' command to clear the screen on Termux or other Unix-based terminals
        passthru('clear');
    }
}

function Run1($url, $head = 0, $post = 0) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_COOKIEJAR , "cookie.txt");
    curl_setopt($ch,CURLOPT_COOKIEFILE , "cookie.txt");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);

    if ($post) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }

    if ($head && is_array($head)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    }

    curl_setopt($ch, CURLOPT_HEADER, true); // This line enables response headers
    $r = curl_exec($ch);

    if (!$r) {
        return "Curl error: " . curl_error($ch);
    } else {
        $info = curl_getinfo($ch);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($r, 0, $headerSize);
        $body = substr($r, $headerSize);
        curl_close($ch);
        return ['header' => $header, 'body' => $body, 'info' => $info];
    }
}


function countdown($duration, $message) {
    $colors = [GREEN, WHITE, YELLOW, BLUE, PURPLE, CYAN];
    $colorIndex = 0;
    
    for ($j = $duration; $j > 0; $j--) {
        $hours = floor($j / 3600);
        $minutes = floor(($j % 3600) / 60);
        $seconds = $j % 60;
              
        // Generate the dot sequence with changing colors
        $dots = $colors[$colorIndex % count($colors)] . str_repeat('>', ($duration - $j) % 5 + 1) . WHITE;
        
        // Print the message, time, and colored dots
        printf(
            $message . ' ' . 
            WHITE . "%02d:%02d:%02d " . $dots,
            $hours, $minutes, $seconds
        );
        
        sleep(1);
        
        $colorIndex++;
        
        // Clear the line and reset dot sequence
        if (($duration - $j) % 5 === 4) {
            $colorIndex = 0;
            print "\r                                               \r";
        } else {
            print "\r                                            \r";
        }
    }
}

function api_link($url_id, $api) {
    $url = 'https://tertuyul.my.id/apikey/';
    $pos = json_encode([
        "request" => "api_linkglitch",
        "apikey"  => $api,
        "url"     => $url_id
    ]);
    $r = json_decode(Run($url, 0, $pos), true);
    if (isset($r["error"]) && $r["error"]) {
        exit($r["error"] . "\n");
    }
    if (isset($r["fail"]) && $r["fail"]) {
        return ["fail" => $r["fail"]];
    }
    if (isset($r["msg"]) && $r["msg"]) {
        return ["error" => $r["msg"]];
    }
    $result = [];
    if (isset($r["url"])) {
        $result["url"] = $r["url"];
    }
    if (isset($r["balance"])) {
        $result["balance"] = $r["balance"];
    }
    return $result;
}


