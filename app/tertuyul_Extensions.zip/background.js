chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "postToAPI") {
    fetch("https://tertuyul.my.id/apikey/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request.payload)
    })
    .then(res => res.json())
    .then(data => sendResponse({ success: true, data }))
    .catch(error => sendResponse({ success: false, error: error.toString() }));

    return true; // penting: buat async response tetap hidup
  }
});
