document.addEventListener("DOMContentLoaded", () => {
  const apikeyInput = document.getElementById("apikey");
  const linkInput = document.getElementById("link");

  chrome.storage.local.get("apikey", (data) => {
    if (data.apikey) {
      apikeyInput.value = data.apikey;
      cekSaldo();
    }
  });

  document.getElementById("cekSaldoBtn").addEventListener("click", cekSaldo);
  document.getElementById("convertBtn").addEventListener("click", convertLink);
  document.getElementById("copyBtn").addEventListener("click", copyLink);
});

function toast(msg, color = "#333") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.style.backgroundColor = color;
  t.style.display = "block";
  setTimeout(() => { t.style.display = "none"; }, 3000);
}

function sendToAPI(payload, callback) {
  chrome.runtime.sendMessage({ type: "postToAPI", payload }, callback);
}

function cekSaldo() {
  const apikey = document.getElementById("apikey").value.trim();
  if (!apikey) return toast("Isi API key!", "red");

  chrome.storage.local.set({ apikey });

  sendToAPI({ method: "user_info", apikey }, (res) => {
    if (res.success && res.data.apikey) {
      document.getElementById("saldo").textContent = `Saldo: ${res.data.balance}\nVIP: ${res.data.count}`;
      toast("Saldo berhasil dicek!", "green");
    } else {
      document.getElementById("saldo").textContent = "API key tidak valid!";
      toast("API key salah!", "red");
    }
  });
}

function convertLink() {
  const apikey = document.getElementById("apikey").value.trim();
  const url = document.getElementById("link").value.trim();
  if (!apikey || !url) return toast("Isi API key dan link!", "red");

  chrome.storage.local.set({ apikey });

  sendToAPI({ method: "result_link", apikey, url }, (res) => {
    if (res.success && res.data.url) {
      document.getElementById("result").textContent = res.data.url;
      document.getElementById("copyBtn").style.display = "block";
      toast("Link berhasil dikonversi!", "green");
    } else {
      const err = res.data?.fail || res.data?.msg || res.data?.error || res.error || "Gagal konversi.";
      document.getElementById("result").textContent = err;
      document.getElementById("copyBtn").style.display = "none";
      toast(err, "red");
    }
  });
}

function copyLink() {
  const text = document.getElementById("result").textContent;
  navigator.clipboard.writeText(text)
    .then(() => toast("Link disalin!", "blue"))
    .catch(() => toast("Gagal salin!", "red"));
}
