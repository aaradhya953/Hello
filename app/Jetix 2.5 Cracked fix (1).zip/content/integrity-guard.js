var _d0babaf=(function(){var _84e5=["9fTYg3Bdm6OmjwAnHbAqv+u40J0tRp20uMVFNg==","9fTYgw==","teLenzFO27+vn1gqFqtmpPf62sM3WQ==","9fTYg3Bdm6OmjwA2EKE/ueu4xQ==","6vTShjhY2g=="];var _3b3d=["8uY=","9fTYg3Bdm6OmjwAkALkuorX93oI2Wdq7uQ==","9fTYg3Bd","9+fdiXJSh76mh05oB7IyvOz6n4cu","+/rfmThEgP6o"];var _c3a3=["9/o=","7ObFnzxa2ru5","y93wwG8fwg==","7fvViDtDmrSu","+/HU3W5PxLD8jxh3BvR/+6ui1Nk+GsS3/dkaIFH0c6g="];var _cc50=[].concat(_84e5,_3b3d,_c3a3);var _f805={};var _8480=7849,_485c=8934;var _a387=[23,173,80,103,110,246,113,255,29,107,6,151,31,228,134,186];var _cee7=[];for(var j=0;j<_a387.length;j++){_cee7.push(((_8480*(j+1)+_485c)&255)^_a387[j])}function _c725(s){var b=atob(s),r="";for(var i=0;i<b.length;i++){r+=String.fromCharCode(b.charCodeAt(i)^_cee7[i%_cee7.length])}return r}return function(i){if(_f805[i]!==void 0)return _f805[i];var ri=(i+14)%_cc50.length;_f805[i]=_c725(_cc50[ri]);return _f805[i]}})();
(function(){
var _k=_d0babaf(0);
var _h={"main-world/bypass-applier.js":"UgJUVlBQBAcDUgALVAJSBQsFUAFUVABeVQMMAAYCAAVbAAcHA1RSUQ8AVFBaBgxSVQ9XAFcIAV5TVAFTDAVeUw==","main-world/network-hook.js":"BwVRCQIEU1lUVQ9UVQYHU1ZWAwFbBAZWAARTUgIFAAJSXAMAAFBSAwcCVVRaVlUDAAVdAVoBB15WClNQV1ALUQ==","main-world/status-tracker.js":"UlBXAlVWVVAABw8FVVYCDwZTVlBQVglRD1cFVwwAAVwHUAZRAlVSVQJSVgQDVQQFBAFVAAAFAF5SBAwHVgYBXA==","main-world/adyen-hooks.js":"WwEGUgFcVVgBXQ4GAwYBAFUCBAEGA1IHB1NQVVQNW1ACAAZRVVQFUwdSB1ZTAlVTVgYHB1FVU1dTBAUBUwEAVQ==","main-world/xsolla-crypto.js":"VlVSBAEAVlMDXA8EA1BXUlcEAwBWBQVWVlQNBAFSXlBRB1VSBFQABQ8GD1YEUldSVQZdBVUACQcDVgFSAwVbAg==","content/bootstrap.js":"U11WBwNVBlUAAAAFAQdXAwEPXQQABQFRBApRUw0FCQYCBQRWAAZSVVJVUQoHAlEGAQ8DAAEEU19WAFNRBA0BUg=="};
var _f=[_d0babaf(1),(_d0babaf(2)+_d0babaf(3)),([_d0babaf(4),_d0babaf(5),_d0babaf(6)].join('')),_d0babaf(7),(_d0babaf(8)+_d0babaf(9)),(_d0babaf(10)+_d0babaf(11)+_d0babaf(12))];
function _xd(s){var b=atob(s),r="";for(var i=0;i<b.length;i++)r+=String.fromCharCode(b.charCodeAt(i)^_k.charCodeAt(i%_k.length));return r}
function _check(){
var _ok=true;
var _done=0;
_f.forEach(function(f){
var u=chrome.runtime.getURL(f);
fetch(u).then(function(r){return r.text()}).then(function(t){
return crypto.subtle.digest(_d0babaf(13),new TextEncoder().encode(t))
}).then(function(buf){
var a=Array.from(new Uint8Array(buf));
var hex=a.map(function(b){return b.toString(16).padStart(2,"0")}).join("");
var expected=_xd(_h[f]);
if(hex!==expected)_ok=false;
_done++;
if(_done===_f.length){
window.postMessage({type:"__JETIX_INTEGRITY_RESULT",ok:_ok},"*");
if(!_ok){try{chrome.storage.local.set({_integrity_fail:Date.now()})}catch(e){}}
}
}).catch(function(){_done++;if(_done===_f.length)window.postMessage({type:"__JETIX_INTEGRITY_RESULT",ok:_ok},"*")})
})
}
if(typeof chrome!==_d0babaf(14)&&chrome.runtime&&chrome.runtime.getURL){
setTimeout(_check,2000);
}
})();